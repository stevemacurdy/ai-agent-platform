export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { withTierEnforcement } from '@/lib/usage-enforcement';
import { trackUsage } from '@/lib/usage-tracker';
import { getLegalData } from '@/lib/legal-data';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function _GET(request: NextRequest) {
  trackUsage(request, 'legal');
  try {
    const { data, error } = await supabase.from('agent_legal_data').select('*').limit(100);
    if (error || !data?.length) {
      const demoData = await getLegalData('_default');
      return NextResponse.json({ ...demoData, source: 'demo' });
    }
    return NextResponse.json({ items: data, source: 'live' });
  } catch {
    const demoData = await getLegalData('_default');
    return NextResponse.json({ ...demoData, source: 'demo' });
  }
}
export const GET = withTierEnforcement(_GET);

export async function POST(request: NextRequest) {
  trackUsage(request, 'legal', 'action');
  const body = await request.json();
  const { action } = body;
  switch (action) {
    case 'add-contract': {
      const { title, counterparty, contractType, value, startDate, endDate, autoRenew } = body;
      const { data, error } = await supabase.from('agent_legal_data').insert({
        title, counterparty, contract_type: contractType, value, start_date: startDate,
        end_date: endDate, auto_renew: autoRenew, status: 'draft',
      }).select().single();
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ result: 'Contract added', data });
    }
    case 'update-status': {
      const { id, status, notes } = body;
      const updates: Record<string, unknown> = { updated_at: new Date().toISOString() };
      if (status) updates.status = status;
      if (notes) updates.notes = notes;
      const { error } = await supabase.from('agent_legal_data').update(updates).eq('id', id);
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ result: 'Status updated' });
    }
    case 'summarize': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const { title, counterparty, contractType, keyTerms } = body;
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a legal AI assistant. Generate plain-English contract summaries. Use clear business language, not legalese.' },
          { role: 'user', content: `Summarize: Title: ${title}, Counterparty: ${counterparty}, Type: ${contractType}, Terms: ${JSON.stringify(keyTerms || {})}. Include: 1) What it covers, 2) Key obligations, 3) Financial terms, 4) Duration/renewal, 5) Termination conditions, 6) Notable clauses.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to summarize.' });
    }
    case 'risk-review': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const { title, counterparty, contractType, keyTerms } = body;
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a legal risk analysis AI for a warehouse systems integration company.' },
          { role: 'user', content: `Risk review: Title: ${title}, Counterparty: ${counterparty}, Type: ${contractType}, Terms: ${JSON.stringify(keyTerms || {})}. Flag: 1) Non-standard liability clauses, 2) Missing indemnification, 3) Unfavorable termination terms, 4) IP concerns, 5) Data protection gaps, 6) Auto-renewal traps. Rate each Critical/High/Medium/Low.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to review risk.' });
    }
    case 'renewal-alert': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const contracts = JSON.stringify(body.contracts || []);
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a contract management AI.' },
          { role: 'user', content: `Expiring contracts: ${contracts}\n\nGenerate renewal recommendations: 1) Priority order, 2) Renegotiation opportunities, 3) Contracts to let expire, 4) Auto-renewal risks, 5) Budget impact of renewals.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to generate renewal alerts.' });
    }
    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
