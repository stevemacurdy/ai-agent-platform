export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { withTierEnforcement } from '@/lib/usage-enforcement';
import { trackUsage } from '@/lib/usage-tracker';
import { getSupportData } from '@/lib/support-data';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function _GET(request: NextRequest) {
  trackUsage(request, 'support');
  try {
    const { data, error } = await supabase.from('agent_support_data').select('*').limit(100);
    if (error || !data?.length) {
      const demoData = await getSupportData('_default');
      return NextResponse.json({ ...demoData, source: 'demo' });
    }
    return NextResponse.json({ items: data, source: 'live' });
  } catch {
    const demoData = await getSupportData('_default');
    return NextResponse.json({ ...demoData, source: 'demo' });
  }
}
export const GET = withTierEnforcement(_GET);

export async function POST(request: NextRequest) {
  trackUsage(request, 'support', 'action');
  const body = await request.json();
  const { action } = body;
  switch (action) {
    case 'create-ticket': {
      const { subject, customer, category, priority } = body;
      const { data, error } = await supabase.from('agent_support_data').insert({ subject, customer, category, priority, status: 'new' }).select().single();
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ result: 'Ticket created', data });
    }
    case 'assign': {
      const { id, assignee } = body;
      const { error } = await supabase.from('agent_support_data').update({ assignee, status: 'open', updated_at: new Date().toISOString() }).eq('id', id);
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ result: `Assigned to ${assignee}` });
    }
    case 'resolve': {
      const { id, satisfaction } = body;
      const { error } = await supabase.from('agent_support_data').update({ status: 'resolved', satisfaction, updated_at: new Date().toISOString() }).eq('id', id);
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ result: 'Ticket resolved' });
    }
    case 'draft-response': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const { subject, customerName, issue } = body;
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a customer support AI for a B2B warehouse systems company. Draft a professional, empathetic response. Include: 1) Acknowledge the issue, 2) Explain what you are doing to help, 3) Clear next steps, 4) Expected timeline. Tone: professional, empathetic, solution-focused.' },
          { role: 'user', content: `Customer: ${customerName}\nSubject: ${subject}\nIssue: ${issue}\n\nDraft a professional support response.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to draft response.' });
    }
    case 'analyze-trends': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const tickets = JSON.stringify(body.tickets || []);
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a support analytics AI for a warehouse systems integration company.' },
          { role: 'user', content: `Tickets: ${tickets}\n\nIdentify: 1) Recurring issues (group similar tickets), 2) Potential bugs vs user-error patterns, 3) Customers at churn risk, 4) Knowledge base gaps, 5) Staffing recommendations.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to analyze trends.' });
    }
    case 'knowledge-article': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const { subject, resolution, category } = body;
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a technical writer AI. Generate a knowledge base article from support resolution data. Include: title, summary, step-by-step solution, related topics, and troubleshooting tips.' },
          { role: 'user', content: `Subject: ${subject}\nResolution: ${resolution || 'Resolved via standard troubleshooting'}\nCategory: ${category || 'General'}\n\nGenerate a KB article.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to generate article.' });
    }
    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
