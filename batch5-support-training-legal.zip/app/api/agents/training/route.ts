export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { withTierEnforcement } from '@/lib/usage-enforcement';
import { trackUsage } from '@/lib/usage-tracker';
import { getTrainingData } from '@/lib/training-data';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function _GET(request: NextRequest) {
  trackUsage(request, 'training');
  try {
    const { data, error } = await supabase.from('agent_training_data').select('*').limit(100);
    if (error || !data?.length) {
      const demoData = await getTrainingData('_default');
      return NextResponse.json({ ...demoData, source: 'demo' });
    }
    return NextResponse.json({ items: data, source: 'live' });
  } catch {
    const demoData = await getTrainingData('_default');
    return NextResponse.json({ ...demoData, source: 'demo' });
  }
}
export const GET = withTierEnforcement(_GET);

export async function POST(request: NextRequest) {
  trackUsage(request, 'training', 'action');
  const body = await request.json();
  const { action } = body;
  switch (action) {
    case 'create-course': {
      const { courseName, department, courseType, dueDate, instructor } = body;
      const { data, error } = await supabase.from('agent_training_data').insert({
        course_name: courseName, department, course_type: courseType, due_date: dueDate, instructor, status: 'draft',
      }).select().single();
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      return NextResponse.json({ result: 'Course created', data });
    }
    case 'assign-training': {
      const { courseId, targets } = body;
      return NextResponse.json({ result: `Training assigned to ${targets || 'all employees'} for course ${courseId}.` });
    }
    case 'generate-quiz': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const { courseName, topic, difficulty, questionCount } = body;
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a corporate training AI for a warehouse systems integration company. Generate assessment questions with multiple choice options.' },
          { role: 'user', content: `Generate ${questionCount || 10} assessment questions for "${courseName}" on "${topic || courseName}". Difficulty: ${difficulty || 'intermediate'}. For each: 1) Question, 2) 4 options A-D, 3) Correct answer, 4) Brief explanation. Mix recall, scenario, and compliance questions.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to generate quiz.' });
    }
    case 'compliance-report': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const programs = JSON.stringify(body.programs || []);
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a compliance training analyst AI for a warehouse systems integration company.' },
          { role: 'user', content: `Training data: ${programs}\n\nGenerate a compliance status report: 1) Overall compliance posture, 2) Departments at risk, 3) Overdue certifications, 4) Upcoming deadlines, 5) Recommended actions with priority.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to generate report.' });
    }
    case 'skill-gap-analysis': {
      const openai = new (await import('openai')).default({ apiKey: process.env.OPENAI_API_KEY });
      const gaps = JSON.stringify(body.gaps || []);
      const response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a workforce development AI.' },
          { role: 'user', content: `Skill data: ${gaps}\n\nIdentify: 1) Critical skill gaps by dept, 2) Compliance risks, 3) Recommended courses, 4) Priority employees needing training, 5) Budget estimate for top 3 gaps.` }
        ],
        max_tokens: 1000, temperature: 0.3,
      });
      return NextResponse.json({ result: response.choices[0]?.message?.content || 'Unable to analyze gaps.' });
    }
    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
