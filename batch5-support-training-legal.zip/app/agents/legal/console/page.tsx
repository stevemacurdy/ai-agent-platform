'use client';
import { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

const CONTRACTS = [
  { title: 'MSA - TechFlow', party: 'TechFlow', type: 'MSA', value: '$240K/yr', end: '2026-06-30', status: 'Active', risk: 'Low', autoRenew: true, reviewer: 'Legal Team', terms: 'Standard liability cap at 2x annual, 90-day termination notice, annual CPI escalator' },
  { title: 'Vendor - FastParts', party: 'FastParts', type: 'Vendor', value: '$180K/yr', end: '2026-03-21', status: 'Expiring', risk: 'Medium', autoRenew: false, reviewer: 'Steve M.', terms: 'No auto-renewal, 30-day notice required, quality SLA with rebates' },
  { title: 'NDA - BuildRight', party: 'BuildRight', type: 'NDA', value: 'N/A', end: '2026-12-31', status: 'Active', risk: 'Low', autoRenew: true, reviewer: 'Legal Team', terms: '2-year mutual NDA, standard IP protections' },
  { title: 'SOW - DC Expansion', party: 'ProBuild', type: 'SOW', value: '$450K', end: '2026-04-15', status: 'Active', risk: 'Medium', autoRenew: false, reviewer: 'Steve M.', terms: 'Fixed price, milestone payments, 10% retainage, liquidated damages $2K/day late' },
  { title: 'Vendor - DataFlow', party: 'DataFlow', type: 'Vendor', value: '$72K/yr', end: '2026-04-08', status: 'Under Review', risk: 'High', autoRenew: true, reviewer: 'Legal Team', terms: 'Missing indemnification clause, unlimited liability exposure, auto-renews in 35 days' },
  { title: 'Lease - Grantsville', party: 'Desert Peak LLC', type: 'Lease', value: '$8.2K/mo', end: '2027-12-31', status: 'Active', risk: 'Low', autoRenew: true, reviewer: 'Steve M.', terms: '3-year lease, 3% annual escalator, 180-day renewal notice' },
  { title: 'Insurance - General', party: 'Zurich', type: 'Vendor', value: '$34K/yr', end: '2026-07-01', status: 'Active', risk: 'Low', autoRenew: true, reviewer: 'Finance', terms: '$2M general liability, $1M per occurrence, workers comp included' },
];

const REVIEW_QUEUE = [
  { title: 'Vendor - DataFlow', priority: 'High', reviewer: 'Legal Team', days: 5, value: '$72K/yr' },
  { title: 'NDA - NewClient Alpha', priority: 'High', reviewer: 'Steve M.', days: 2, value: 'N/A' },
  { title: 'SOW - Rack Install Phase 2', priority: 'Medium', reviewer: 'Legal Team', days: 3, value: '$128K' },
  { title: 'Vendor - CloudSync', priority: 'Medium', reviewer: 'Legal Team', days: 4, value: '$24K/yr' },
  { title: 'Amendment - TechFlow', priority: 'Low', reviewer: 'Steve M.', days: 1, value: 'N/A' },
  { title: 'NDA - Summit Corp', priority: 'Low', reviewer: 'Legal Team', days: 1, value: 'N/A' },
  { title: 'MSA - RetailMax', priority: 'Medium', reviewer: 'Legal Team', days: 7, value: '$156K/yr' },
];

const RISK_ITEMS = [
  { contract: 'Vendor - DataFlow', clause: 'Indemnification', risk: 'Missing indemnification clause entirely', status: 'Open', severity: 'Critical' },
  { contract: 'Vendor - DataFlow', clause: 'Liability Cap', risk: 'Unlimited liability exposure — no cap defined', status: 'Open', severity: 'Critical' },
  { contract: 'SOW - DC Expansion', clause: 'Termination', risk: 'Only for-cause termination, no convenience clause', status: 'Under Review', severity: 'High' },
  { contract: 'Vendor - FastParts', clause: 'IP Ownership', risk: 'Custom tooling IP defaults to vendor', status: 'Accepted', severity: 'Medium' },
  { contract: 'MSA - TechFlow', clause: 'Data Protection', risk: 'No specific GDPR/CCPA references', status: 'Under Review', severity: 'Medium' },
  { contract: 'Lease - Grantsville', clause: 'Assignment', risk: 'No sublease rights without landlord consent', status: 'Accepted', severity: 'Low' },
];

const RISK_BY_LEVEL = [
  { level: 'Critical', count: 2 }, { level: 'High', count: 1 }, { level: 'Medium', count: 3 }, { level: 'Low', count: 2 },
];

const RENEWALS = [
  { title: 'Vendor - FastParts', party: 'FastParts', end: '2026-03-21', autoRenew: false, value: '$180K/yr', action: 'Renegotiate — performance declining' },
  { title: 'Vendor - DataFlow', party: 'DataFlow', end: '2026-04-08', autoRenew: true, value: '$72K/yr', action: 'Block auto-renewal — fix risk clauses first' },
  { title: 'SOW - DC Expansion', party: 'ProBuild', end: '2026-04-15', autoRenew: false, value: '$450K', action: 'Close out — project completion' },
  { title: 'MSA - TechFlow', party: 'TechFlow', end: '2026-06-30', autoRenew: true, value: '$240K/yr', action: 'Review terms before auto-renewal' },
  { title: 'Insurance - General', party: 'Zurich', end: '2026-07-01', autoRenew: true, value: '$34K/yr', action: 'Get competitive quotes' },
];

const RENEWAL_MONTHS = [
  { month: 'Mar', count: 1 }, { month: 'Apr', count: 2 }, { month: 'May', count: 1 }, { month: 'Jun', count: 2 },
];

const badge = (v: string) => {
  const m: Record<string, string> = {
    Active: 'bg-emerald-50 text-emerald-600', Expiring: 'bg-amber-50 text-amber-600', 'Under Review': 'bg-blue-50 text-blue-600',
    Draft: 'bg-gray-100 text-gray-500', Terminated: 'bg-rose-50 text-rose-600',
    Low: 'bg-emerald-50 text-emerald-600', Medium: 'bg-amber-50 text-amber-600', High: 'bg-rose-50 text-rose-600', Critical: 'bg-rose-50 text-rose-600',
    MSA: 'bg-blue-50 text-blue-600', Vendor: 'bg-violet-50 text-violet-600', NDA: 'bg-gray-100 text-gray-500', SOW: 'bg-amber-50 text-amber-600', Lease: 'bg-emerald-50 text-emerald-600',
    Open: 'bg-blue-50 text-blue-600', Accepted: 'bg-emerald-50 text-emerald-600',
  };
  return <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${m[v] || 'bg-gray-100 text-gray-600'}`}>{v}</span>;
};

export default function LegalConsole() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('contracts');
  const [sortKey, setSortKey] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalAction, setModalAction] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('/api/agents/legal').then(r => r.json())
      .then(d => { setData(d); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const sort = (key: string) => { setSortKey(key); setSortDir(sortKey === key && sortDir === 'asc' ? 'desc' : 'asc'); setExpandedRow(null); };
  const sorted = (rows: any[]) => { if (!sortKey) return rows; return [...rows].sort((a, b) => { const av = a[sortKey], bv = b[sortKey]; const c = typeof av === 'number' ? av - bv : String(av).localeCompare(String(bv)); return sortDir === 'asc' ? c : -c; }); };
  const arrow = (k: string) => sortKey === k ? (sortDir === 'asc' ? ' ↑' : ' ↓') : '';

  const handleAi = async (action: string, payload?: any) => {
    setAiLoading(true); setAiResult(''); setModalAction(action); setModalOpen(true);
    const res = await fetch('/api/agents/legal', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, contracts: RENEWALS, ...payload }) });
    const r = await res.json(); setAiResult(r.result || r.error || 'Complete'); setAiLoading(false);
  };

  const src = data?.source;
  const tabs = ['contracts', 'review', 'risk', 'renewals'];
  const KPI = ({ label, value, sub }: { label: string; value: string; sub?: string }) => (
    <div className="bg-white rounded-xl border border-gray-200 p-4">
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-extrabold mt-1" style={{ color: '#1B2A4A', fontFamily: "'Outfit', sans-serif" }}>{value}</p>
      {sub && <p className={`text-xs mt-1 font-medium ${sub.includes('overdue') || sub.includes('unlimited') ? 'text-rose-600' : 'text-gray-400'}`}>{sub}</p>}
    </div>
  );
  const TH = ({ k, children }: { k: string; children: React.ReactNode }) => (
    <th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400 cursor-pointer hover:text-gray-600" onClick={() => sort(k)}>{children}{arrow(k)}</th>
  );

  if (loading) return <div className="p-8 space-y-4">{[1,2,3,4].map(i => <div key={i} className="h-24 bg-gray-200 rounded-xl animate-pulse" />)}</div>;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3"><span className="text-3xl">&#x2696;</span><div><h1 className="text-2xl font-extrabold" style={{ color: '#1B2A4A', fontFamily: "'Outfit', sans-serif" }}>Legal Console</h1><p className="text-xs text-gray-400">Legal Department</p></div></div>
        {src && <span className={`px-3 py-1 rounded-full text-xs font-medium ${src === 'live' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>{src === 'live' ? 'Live Data' : 'Demo Data'}</span>}
      </div>
      <div className="flex gap-2 border-b border-gray-200">{tabs.map(t => (
        <button key={t} onClick={() => { setTab(t); setExpandedRow(null); setSortKey(''); }} className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === t ? 'border-orange-500 text-orange-600' : 'border-transparent text-gray-400 hover:text-gray-600'}`}>
          {t === 'contracts' ? 'Contracts' : t === 'review' ? 'Review Queue' : t === 'risk' ? 'Risk Register' : 'Renewals'}
        </button>
      ))}</div>

      {tab === 'contracts' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Active Contracts" value="89" /><KPI label="Pending Review" value="7" /><KPI label="Upcoming Renewals" value="12" /><KPI label="Overall Risk" value="Medium" />
        </div>
        <input className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="Search contracts..." value={search} onChange={e => setSearch(e.target.value)} />
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="title">Contract</TH><TH k="party">Counterparty</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Type</th><TH k="value">Value</TH><TH k="end">End Date</TH><TH k="status">Status</TH><TH k="risk">Risk</TH>
          </tr></thead><tbody>
            {sorted(CONTRACTS.filter(c => c.title.toLowerCase().includes(search.toLowerCase()) || c.party.toLowerCase().includes(search.toLowerCase()))).map((c, i) => (
              <tr key={i} className={`border-t border-gray-100 hover:bg-gray-50 cursor-pointer ${c.risk === 'High' ? 'bg-rose-50/30' : ''}`} onClick={() => setExpandedRow(expandedRow === i ? null : i)}>
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{c.title}</td><td className="px-4 py-3">{c.party}</td>
                <td className="px-4 py-3">{badge(c.type)}</td><td className="px-4 py-3">{c.value}</td>
                <td className="px-4 py-3">{c.end}</td><td className="px-4 py-3">{badge(c.status)}</td><td className="px-4 py-3">{badge(c.risk)}</td>
              </tr>
            ))}
          </tbody></table>
          {expandedRow !== null && (() => { const c = sorted(CONTRACTS.filter(cx => cx.title.toLowerCase().includes(search.toLowerCase()) || cx.party.toLowerCase().includes(search.toLowerCase())))[expandedRow]; if (!c) return null; return (
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-3 text-xs mb-3">
                <div><span className="text-gray-400">Auto-Renew:</span> <span className="font-medium">{c.autoRenew ? 'Yes' : 'No'}</span></div>
                <div><span className="text-gray-400">Reviewer:</span> <span className="font-medium">{c.reviewer}</span></div>
                <div className="col-span-2"><span className="text-gray-400">Key Terms:</span> <span className="font-medium">{c.terms}</span></div>
              </div>
              <div className="flex gap-2">
                <button className="px-3 py-1.5 bg-orange-500 text-white rounded-lg text-xs font-medium hover:bg-orange-600" onClick={() => handleAi('summarize', { title: c.title, counterparty: c.party, contractType: c.type, keyTerms: c.terms })}>Summarize</button>
                <button className="px-3 py-1.5 bg-rose-500 text-white rounded-lg text-xs font-medium hover:bg-rose-600" onClick={() => handleAi('risk-review', { title: c.title, counterparty: c.party, contractType: c.type, keyTerms: c.terms })}>Risk Review</button>
              </div>
            </div>
          ); })()}
        </div>
      </>}

      {tab === 'review' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="In Queue" value="7" /><KPI label="Avg Review Time" value="3.2 days" /><KPI label="High Priority" value="2" /><KPI label="Overdue Reviews" value="1" sub="overdue" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="title">Contract</TH><TH k="priority">Priority</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Reviewer</th><TH k="days">Days in Queue</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Value</th>
          </tr></thead><tbody>
            {sorted(REVIEW_QUEUE).map((r, i) => (
              <tr key={i} className={`border-t border-gray-100 hover:bg-gray-50 ${r.days > 5 ? 'bg-rose-50/30' : ''}`}>
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{r.title}</td>
                <td className="px-4 py-3">{badge(r.priority)}</td><td className="px-4 py-3 text-gray-500">{r.reviewer}</td>
                <td className="px-4 py-3 font-bold" style={{ color: r.days > 5 ? '#DC2626' : r.days > 3 ? '#F5920B' : '#059669' }}>{r.days}d</td>
                <td className="px-4 py-3">{r.value}</td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </>}

      {tab === 'risk' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="High Risk" value="3" /><KPI label="Non-Standard" value="8" /><KPI label="Missing Indemnification" value="2" /><KPI label="Unlimited Liability" value="1" sub="unlimited exposure" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <h3 className="text-sm font-bold mb-3" style={{ color: '#1B2A4A' }}>Contracts by Risk Level</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={RISK_BY_LEVEL}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="level" /><YAxis /><Tooltip />
              <Bar dataKey="count" name="Contracts" fill="#DC2626" /></BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="contract">Contract</TH><TH k="clause">Clause</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Risk</th><TH k="severity">Severity</TH><TH k="status">Status</TH>
          </tr></thead><tbody>
            {sorted(RISK_ITEMS).map((r, i) => (
              <tr key={i} className={`border-t border-gray-100 hover:bg-gray-50 ${r.severity === 'Critical' ? 'bg-rose-50/30' : ''}`}>
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{r.contract}</td>
                <td className="px-4 py-3">{r.clause}</td>
                <td className="px-4 py-3 text-xs text-gray-600">{r.risk}</td>
                <td className="px-4 py-3">{badge(r.severity)}</td><td className="px-4 py-3">{badge(r.status)}</td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </>}

      {tab === 'renewals' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Expiring 30d" value="3" /><KPI label="Expiring 60d" value="5" /><KPI label="Expiring 90d" value="4" /><KPI label="Auto-Renewing" value="7" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <h3 className="text-sm font-bold mb-3" style={{ color: '#1B2A4A' }}>Renewals by Month (Next 90 Days)</h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={RENEWAL_MONTHS}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="month" /><YAxis /><Tooltip />
              <Bar dataKey="count" name="Renewals" fill="#F5920B" /></BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="title">Contract</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Party</th><TH k="end">End Date</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Auto</th><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Value</th><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Action</th>
          </tr></thead><tbody>
            {sorted(RENEWALS).map((r, i) => (
              <tr key={i} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{r.title}</td><td className="px-4 py-3">{r.party}</td>
                <td className="px-4 py-3">{r.end}</td>
                <td className="px-4 py-3">{r.autoRenew ? <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-600">Yes</span> : <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-500">No</span>}</td>
                <td className="px-4 py-3">{r.value}</td>
                <td className="px-4 py-3 text-xs text-gray-600">{r.action}</td>
              </tr>
            ))}
          </tbody></table>
        </div>
        <button className="px-4 py-2 bg-orange-500 text-white rounded-lg text-sm font-medium hover:bg-orange-600" onClick={() => handleAi('renewal-alert')}>Generate Renewal Recommendations</button>
      </>}

      {modalOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={() => setModalOpen(false)}>
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold" style={{ color: '#1B2A4A' }}>{modalAction.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</h3>
              <button className="text-gray-400 hover:text-gray-600 text-xl" onClick={() => setModalOpen(false)}>&#x2715;</button>
            </div>
            {aiLoading ? <div className="flex items-center gap-3 py-8"><div className="w-5 h-5 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" /><span className="text-sm text-gray-500">Analyzing...</span></div>
            : <div className="text-sm text-gray-700 whitespace-pre-wrap">{aiResult}</div>}
            {!aiLoading && aiResult && <button className="mt-4 px-3 py-1.5 bg-gray-100 text-gray-600 rounded-lg text-xs font-medium hover:bg-gray-200" onClick={() => navigator.clipboard.writeText(aiResult)}>Copy to Clipboard</button>}
          </div>
        </div>
      )}
    </div>
  );
}
