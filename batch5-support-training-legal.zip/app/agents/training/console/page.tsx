'use client';
import { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

const COURSES = [
  { name: 'OSHA Safety', dept: 'All', enrolled: 127, completed: 113, rate: 89, due: 'Mar 31', status: 'Active', type: 'Compliance', modules: '8 modules, 6hr total', incomplete: 'J. Kim, R. Patel, T. Nguyen, M. Santos, K. Brown + 9 others', reminder: true },
  { name: 'Forklift Certification', dept: 'Operations', enrolled: 34, completed: 28, rate: 82, due: 'Mar 15', status: 'Active', type: 'Compliance', modules: '4 modules + practical exam', incomplete: 'D. Miller, P. Clark, A. Lewis, S. Walker, J. Martinez, B. Allen', reminder: true },
  { name: 'New Hire Onboarding', dept: 'All', enrolled: 12, completed: 7, rate: 58, due: 'Rolling', status: 'Behind', type: 'Onboarding', modules: '12 modules, 3 days total', incomplete: 'N. Chen, L. Rivera, T. Hall, M. Garcia, A. Baker', reminder: true },
  { name: 'Cybersecurity Awareness', dept: 'All', enrolled: 127, completed: 98, rate: 77, due: 'Apr 15', status: 'Active', type: 'Mandatory', modules: '6 modules, 2hr total', incomplete: '29 employees across all departments', reminder: true },
  { name: 'Leadership Development', dept: 'Management', enrolled: 18, completed: 14, rate: 78, due: 'Apr 30', status: 'Active', type: 'Elective', modules: '10 modules, 16hr total + coaching', incomplete: 'R. Johnson, K. Thomas, L. Anderson, J. White', reminder: false },
  { name: 'WMS Training', dept: 'Operations', enrolled: 45, completed: 38, rate: 84, due: 'Mar 20', status: 'Active', type: 'Mandatory', modules: '6 modules + system practicum', incomplete: 'C. Davis, M. Wilson, P. Moore, J. Taylor + 3 others', reminder: true },
];

const COMPLIANCE = [
  { cert: 'OSHA 10-Hour', required: 'All warehouse staff', rate: 89, gap: 14, deadline: 'Mar 31, 2026', risk: 'Medium' },
  { cert: 'Forklift License', required: 'Operations', rate: 82, gap: 6, deadline: 'Mar 15, 2026', risk: 'High' },
  { cert: 'Hazmat Handling', required: 'Shipping', rate: 94, gap: 2, deadline: 'Jun 30, 2026', risk: 'Low' },
  { cert: 'First Aid/CPR', required: 'All supervisors', rate: 76, gap: 4, deadline: 'Apr 30, 2026', risk: 'Medium' },
  { cert: 'Cybersecurity', required: 'All staff', rate: 77, gap: 29, deadline: 'Apr 15, 2026', risk: 'Medium' },
  { cert: 'Fire Safety', required: 'All staff', rate: 91, gap: 12, deadline: 'May 31, 2026', risk: 'Low' },
];

const COMP_BY_DEPT = [
  { dept: 'Operations', rate: 86 }, { dept: 'Engineering', rate: 78 }, { dept: 'Sales', rate: 92 },
  { dept: 'Finance', rate: 95 }, { dept: 'HR', rate: 100 }, { dept: 'Support', rate: 84 },
];

const SKILLS = [
  { skill: 'WMS Operation', Operations: 'covered', Engineering: 'partial', Sales: 'gap', Finance: 'gap', HR: 'gap', Support: 'partial' },
  { skill: 'Safety Protocols', Operations: 'covered', Engineering: 'covered', Sales: 'partial', Finance: 'partial', HR: 'covered', Support: 'covered' },
  { skill: 'Data Analytics', Operations: 'gap', Engineering: 'covered', Sales: 'partial', Finance: 'covered', HR: 'partial', Support: 'gap' },
  { skill: 'Customer Service', Operations: 'partial', Engineering: 'gap', Sales: 'covered', Finance: 'partial', HR: 'covered', Support: 'covered' },
  { skill: 'Leadership', Operations: 'partial', Engineering: 'partial', Sales: 'covered', Finance: 'covered', HR: 'covered', Support: 'partial' },
  { skill: 'Technical Writing', Operations: 'gap', Engineering: 'covered', Sales: 'gap', Finance: 'partial', HR: 'partial', Support: 'partial' },
];

const CERTS = [
  { cert: 'Forklift License', employee: 'Mike R.', status: 'Expired', issued: '2024-03-10', expiry: '2026-03-01', renewal: true },
  { cert: 'Forklift License', employee: 'Carlos M.', status: 'Expiring', issued: '2024-03-15', expiry: '2026-03-15', renewal: true },
  { cert: 'OSHA 10-Hour', employee: 'Lisa K.', status: 'Valid', issued: '2025-06-01', expiry: '2027-06-01', renewal: false },
  { cert: 'Hazmat Handling', employee: 'James T.', status: 'Valid', issued: '2025-09-10', expiry: '2027-09-10', renewal: false },
  { cert: 'First Aid/CPR', employee: 'Sarah M.', status: 'Expiring', issued: '2024-04-20', expiry: '2026-04-20', renewal: true },
  { cert: 'Forklift License', employee: 'Luis R.', status: 'Expired', issued: '2024-02-28', expiry: '2026-02-28', renewal: true },
  { cert: 'Fire Safety', employee: 'Maria L.', status: 'Valid', issued: '2025-11-01', expiry: '2027-11-01', renewal: false },
  { cert: 'Cybersecurity', employee: 'Alex P.', status: 'Pending', issued: '--', expiry: '--', renewal: true },
];

const badge = (v: string) => {
  const m: Record<string, string> = {
    Active: 'bg-emerald-50 text-emerald-600', Behind: 'bg-amber-50 text-amber-600', Overdue: 'bg-rose-50 text-rose-600',
    Compliance: 'bg-blue-50 text-blue-600', Mandatory: 'bg-violet-50 text-violet-600', Elective: 'bg-gray-100 text-gray-500', Onboarding: 'bg-amber-50 text-amber-600',
    Valid: 'bg-emerald-50 text-emerald-600', Expiring: 'bg-amber-50 text-amber-600', Expired: 'bg-rose-50 text-rose-600', Pending: 'bg-blue-50 text-blue-600',
    Low: 'bg-emerald-50 text-emerald-600', Medium: 'bg-amber-50 text-amber-600', High: 'bg-rose-50 text-rose-600',
  };
  return <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${m[v] || 'bg-gray-100 text-gray-600'}`}>{v}</span>;
};

const skillColor = (v: string) => v === 'covered' ? 'bg-emerald-100 text-emerald-700' : v === 'partial' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700';

export default function TrainingConsole() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('courses');
  const [sortKey, setSortKey] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalAction, setModalAction] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('/api/agents/training').then(r => r.json())
      .then(d => { setData(d); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const sort = (key: string) => { setSortKey(key); setSortDir(sortKey === key && sortDir === 'asc' ? 'desc' : 'asc'); setExpandedRow(null); };
  const sorted = (rows: any[]) => { if (!sortKey) return rows; return [...rows].sort((a, b) => { const av = a[sortKey], bv = b[sortKey]; const c = typeof av === 'number' ? av - bv : String(av).localeCompare(String(bv)); return sortDir === 'asc' ? c : -c; }); };
  const arrow = (k: string) => sortKey === k ? (sortDir === 'asc' ? ' ↑' : ' ↓') : '';

  const handleAi = async (action: string, payload?: any) => {
    setAiLoading(true); setAiResult(''); setModalAction(action); setModalOpen(true);
    const res = await fetch('/api/agents/training', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, programs: COURSES, gaps: SKILLS, ...payload }) });
    const r = await res.json(); setAiResult(r.result || r.error || 'Complete'); setAiLoading(false);
  };

  const src = data?.source;
  const tabs = ['courses', 'compliance', 'skills', 'certs'];
  const KPI = ({ label, value, sub }: { label: string; value: string; sub?: string }) => (
    <div className="bg-white rounded-xl border border-gray-200 p-4">
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-extrabold mt-1" style={{ color: '#1B2A4A', fontFamily: "'Outfit', sans-serif" }}>{value}</p>
      {sub && <p className={`text-xs mt-1 font-medium ${sub.includes('↑') ? 'text-emerald-600' : sub.includes('lapsed') || sub.includes('overdue') ? 'text-rose-600' : 'text-gray-400'}`}>{sub}</p>}
    </div>
  );
  const TH = ({ k, children }: { k: string; children: React.ReactNode }) => (
    <th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400 cursor-pointer hover:text-gray-600" onClick={() => sort(k)}>{children}{arrow(k)}</th>
  );

  if (loading) return <div className="p-8 space-y-4">{[1,2,3,4].map(i => <div key={i} className="h-24 bg-gray-200 rounded-xl animate-pulse" />)}</div>;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3"><span className="text-3xl">🎓</span><div><h1 className="text-2xl font-extrabold" style={{ color: '#1B2A4A', fontFamily: "'Outfit', sans-serif" }}>Training Console</h1><p className="text-xs text-gray-400">People Department</p></div></div>
        {src && <span className={`px-3 py-1 rounded-full text-xs font-medium ${src === 'live' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>{src === 'live' ? 'Live Data' : 'Demo Data'}</span>}
      </div>
      <div className="flex gap-2 border-b border-gray-200">{tabs.map(t => (
        <button key={t} onClick={() => { setTab(t); setExpandedRow(null); setSortKey(''); }} className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === t ? 'border-orange-500 text-orange-600' : 'border-transparent text-gray-400 hover:text-gray-600'}`}>
          {t === 'courses' ? 'Courses' : t === 'compliance' ? 'Compliance' : t === 'skills' ? 'Skills Matrix' : 'Certifications'}
        </button>
      ))}</div>

      {tab === 'courses' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Active Courses" value="24" /><KPI label="Completion Rate" value="73%" sub="↑ 5%" /><KPI label="Compliance Rate" value="89%" /><KPI label="Overdue Certs" value="6" sub="overdue count" />
        </div>
        <input className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="Search courses..." value={search} onChange={e => setSearch(e.target.value)} />
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="name">Course</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Dept</th><TH k="enrolled">Enrolled</TH><TH k="completed">Done</TH><TH k="rate">Rate</TH><TH k="due">Due</TH><TH k="status">Status</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Type</th>
          </tr></thead><tbody>
            {sorted(COURSES.filter(c => c.name.toLowerCase().includes(search.toLowerCase()))).map((c, i) => (
              <tr key={i} className="border-t border-gray-100 hover:bg-gray-50 cursor-pointer" onClick={() => setExpandedRow(expandedRow === i ? null : i)}>
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{c.name}</td><td className="px-4 py-3 text-gray-500">{c.dept}</td>
                <td className="px-4 py-3">{c.enrolled}</td><td className="px-4 py-3">{c.completed}</td>
                <td className="px-4 py-3"><div className="flex items-center gap-2"><div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden"><div className="h-full rounded-full" style={{ width: `${c.rate}%`, background: c.rate >= 85 ? '#059669' : c.rate >= 70 ? '#F5920B' : '#DC2626' }} /></div><span className="text-xs font-medium">{c.rate}%</span></div></td>
                <td className="px-4 py-3">{c.due}</td><td className="px-4 py-3">{badge(c.status)}</td><td className="px-4 py-3">{badge(c.type)}</td>
              </tr>
            ))}
          </tbody></table>
          {expandedRow !== null && (() => { const c = sorted(COURSES.filter(cx => cx.name.toLowerCase().includes(search.toLowerCase())))[expandedRow]; if (!c) return null; return (
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
              <div className="text-xs text-gray-600 mb-2"><span className="text-gray-400">Modules:</span> {c.modules}</div>
              <div className="text-xs text-gray-600 mb-3"><span className="text-gray-400">Incomplete:</span> {c.incomplete}</div>
              <div className="flex gap-2">
                <button className="px-3 py-1.5 bg-orange-500 text-white rounded-lg text-xs font-medium hover:bg-orange-600" onClick={() => handleAi('generate-quiz', { courseName: c.name, topic: c.name, questionCount: 10 })}>Generate Quiz</button>
                <button className="px-3 py-1.5 bg-blue-500 text-white rounded-lg text-xs font-medium hover:bg-blue-600" onClick={() => handleAi('assign-training', { courseId: c.name, targets: c.dept })}>Send Reminder</button>
              </div>
            </div>
          ); })()}
        </div>
      </>}

      {tab === 'compliance' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Overall Compliance" value="89%" /><KPI label="Expiring This Month" value="8" /><KPI label="Non-Compliant Depts" value="2" /><KPI label="Audit Risk" value="Medium" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <h3 className="text-sm font-bold mb-3" style={{ color: '#1B2A4A' }}>Compliance Rate by Department</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={COMP_BY_DEPT}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="dept" tick={{ fontSize: 11 }} /><YAxis domain={[60, 100]} /><Tooltip />
              <Bar dataKey="rate" name="Compliance %" fill="#2A9D8F" /></BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="cert">Cert/Regulation</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Required By</th><TH k="rate">Rate</TH><TH k="gap">Gap</TH><TH k="deadline">Deadline</TH><TH k="risk">Risk</TH>
          </tr></thead><tbody>
            {sorted(COMPLIANCE).map((c, i) => (
              <tr key={i} className={`border-t border-gray-100 hover:bg-gray-50 ${c.risk === 'High' ? 'bg-rose-50/30' : ''}`}>
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{c.cert}</td><td className="px-4 py-3 text-gray-500">{c.required}</td>
                <td className="px-4 py-3 font-bold" style={{ color: c.rate >= 90 ? '#059669' : c.rate >= 80 ? '#F5920B' : '#DC2626' }}>{c.rate}%</td>
                <td className="px-4 py-3 font-bold" style={{ color: c.gap > 10 ? '#DC2626' : c.gap > 3 ? '#F5920B' : '#059669' }}>{c.gap}</td>
                <td className="px-4 py-3">{c.deadline}</td><td className="px-4 py-3">{badge(c.risk)}</td>
              </tr>
            ))}
          </tbody></table>
        </div>
        <button className="px-4 py-2 bg-orange-500 text-white rounded-lg text-sm font-medium hover:bg-orange-600" onClick={() => handleAi('compliance-report')}>Generate Compliance Report</button>
      </>}

      {tab === 'skills' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Skill Areas" value="12" /><KPI label="Fully Covered" value="7" /><KPI label="Partial" value="3" /><KPI label="Critical Gaps" value="2" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-x-auto">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Skill</th>
            {['Operations','Engineering','Sales','Finance','HR','Support'].map(d => <th key={d} className="px-3 py-3 text-center text-xs font-bold uppercase tracking-wider text-gray-400">{d}</th>)}
          </tr></thead><tbody>
            {SKILLS.map((s, i) => (
              <tr key={i} className="border-t border-gray-100">
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{s.skill}</td>
                {['Operations','Engineering','Sales','Finance','HR','Support'].map(d => {
                  const v = (s as any)[d];
                  return <td key={d} className="px-3 py-3 text-center"><span className={`px-2 py-0.5 rounded text-xs font-medium ${skillColor(v)}`}>{v}</span></td>;
                })}
              </tr>
            ))}
          </tbody></table>
        </div>
        <button className="px-4 py-2 bg-orange-500 text-white rounded-lg text-sm font-medium hover:bg-orange-600" onClick={() => handleAi('skill-gap-analysis')}>Run Skill Gap Analysis</button>
      </>}

      {tab === 'certs' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Total Certs" value="89" /><KPI label="Valid" value="74" /><KPI label="Expiring Soon" value="8" /><KPI label="Expired" value="6" sub="2 lapsed operators" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="cert">Certification</TH><TH k="employee">Employee</TH><TH k="status">Status</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Issued</th><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Expiry</th><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Renewal</th>
          </tr></thead><tbody>
            {sorted(CERTS).map((c, i) => (
              <tr key={i} className={`border-t border-gray-100 hover:bg-gray-50 ${c.status === 'Expired' ? 'bg-rose-50/30' : ''}`}>
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{c.cert}</td><td className="px-4 py-3">{c.employee}</td>
                <td className="px-4 py-3">{badge(c.status)}</td>
                <td className="px-4 py-3 text-gray-500">{c.issued}</td><td className="px-4 py-3 text-gray-500">{c.expiry}</td>
                <td className="px-4 py-3">{c.renewal ? <span className="text-xs font-medium text-rose-600">Required</span> : <span className="text-xs text-gray-400">No</span>}</td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </>}

      {modalOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={() => setModalOpen(false)}>
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold" style={{ color: '#1B2A4A' }}>{modalAction.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</h3>
              <button className="text-gray-400 hover:text-gray-600 text-xl" onClick={() => setModalOpen(false)}>&#x2715;</button>
            </div>
            {aiLoading ? <div className="flex items-center gap-3 py-8"><div className="w-5 h-5 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" /><span className="text-sm text-gray-500">Analyzing...</span></div>
            : <div className="text-sm text-gray-700 whitespace-pre-wrap">{aiResult}</div>}
            {!aiLoading && aiResult && <button className="mt-4 px-3 py-1.5 bg-gray-100 text-gray-600 rounded-lg text-xs font-medium hover:bg-gray-200" onClick={() => navigator.clipboard.writeText(aiResult)}>Copy to Clipboard</button>}
          </div>
        </div>
      )}
    </div>
  );
}
