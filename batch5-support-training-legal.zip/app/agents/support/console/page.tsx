'use client';
import { useState, useEffect } from 'react';
import {
  BarChart, Bar, AreaChart, Area, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

const TICKETS = [
  { id: 'TK-4421', customer: 'TechFlow', subject: 'Login errors after update', priority: 'P1', status: 'Open', assignee: 'Sarah M.', age: '2h', sla: 'Critical', description: 'Multiple users unable to login since v2.4 update. Affects 40+ users. Error: AUTH_TIMEOUT.', resolution: '' },
  { id: 'TK-4418', customer: 'BuildRight', subject: 'Report export failing', priority: 'P2', status: 'In Progress', assignee: 'Mike R.', age: '6h', sla: 'On Track', description: 'PDF export returns blank pages for custom reports. CSV works fine.', resolution: '' },
  { id: 'TK-4415', customer: 'RetailMax', subject: 'Dashboard loading slow', priority: 'P3', status: 'In Progress', assignee: 'Lisa K.', age: '14h', sla: 'On Track', description: 'Main dashboard takes 12+ seconds to load. Started after adding 500+ SKUs.', resolution: '' },
  { id: 'TK-4412', customer: 'DataSync', subject: 'API rate limit questions', priority: 'P4', status: 'Open', assignee: 'Unassigned', age: '22h', sla: 'On Track', description: 'Customer wants to increase API rate limits from 100/min to 500/min for integration.', resolution: '' },
  { id: 'TK-4409', customer: 'MegaCorp', subject: 'Billing discrepancy', priority: 'P2', status: 'Escalated', assignee: 'James T.', age: '3d', sla: 'Overdue', description: 'Invoice shows $4,200 but contract says $3,800/mo. Needs immediate resolution.', resolution: '' },
  { id: 'TK-4405', customer: 'Summit', subject: 'Feature request: bulk export', priority: 'P4', status: 'Open', assignee: 'Unassigned', age: '5d', sla: 'On Track', description: 'Requesting ability to export all inventory data in bulk CSV format.', resolution: '' },
];

const VOLUME_TREND = [
  { day: 'Feb 3', tickets: 4 }, { day: 'Feb 7', tickets: 6 }, { day: 'Feb 10', tickets: 8 },
  { day: 'Feb 14', tickets: 5 }, { day: 'Feb 17', tickets: 7 }, { day: 'Feb 21', tickets: 9 },
  { day: 'Feb 24', tickets: 6 }, { day: 'Feb 28', tickets: 8 }, { day: 'Mar 1', tickets: 5 },
  { day: 'Mar 4', tickets: 7 },
];

const RESPONSE_TREND = [
  { day: 'Feb 3', hrs: 3.2 }, { day: 'Feb 7', hrs: 2.8 }, { day: 'Feb 10', hrs: 3.0 },
  { day: 'Feb 14', hrs: 2.6 }, { day: 'Feb 17', hrs: 2.9 }, { day: 'Feb 21', hrs: 2.4 },
  { day: 'Feb 24', hrs: 2.5 }, { day: 'Feb 28', hrs: 2.2 }, { day: 'Mar 1', hrs: 2.4 },
  { day: 'Mar 4', hrs: 2.4 },
];

const AGENTS = [
  { name: 'Sarah M.', resolved: 38, avgResp: '1.8h', csat: 4.6, fcr: 72 },
  { name: 'Mike R.', resolved: 32, avgResp: '2.2h', csat: 4.3, fcr: 65 },
  { name: 'Lisa K.', resolved: 28, avgResp: '2.6h', csat: 4.1, fcr: 61 },
  { name: 'James T.', resolved: 28, avgResp: '3.1h', csat: 3.9, fcr: 58 },
];

const CUSTOMERS = [
  { name: 'TechFlow', csat: 3.2, open: 3, total: 18, health: 'Critical', lastInteraction: '2h ago', history: '3 P1 tickets this month, CSAT declining' },
  { name: 'BuildRight', csat: 4.1, open: 1, total: 8, health: 'Healthy', lastInteraction: '6h ago', history: 'Stable, occasional report issues' },
  { name: 'RetailMax', csat: 3.8, open: 1, total: 12, health: 'Warning', lastInteraction: '14h ago', history: 'Performance complaints increasing' },
  { name: 'MegaCorp', csat: 2.9, open: 2, total: 22, health: 'Critical', lastInteraction: '3d ago', history: 'Billing dispute, escalated. High-value account at risk.' },
  { name: 'DataSync', csat: 4.4, open: 1, total: 5, health: 'Healthy', lastInteraction: '22h ago', history: 'Integration-focused, low complexity' },
  { name: 'Summit', csat: 4.2, open: 1, total: 6, health: 'Healthy', lastInteraction: '5d ago', history: 'Feature requests only, satisfied overall' },
];

const KB_ARTICLES = [
  { title: 'Getting Started with WMS Integration', category: 'Setup', views: 342, helpful: 89, updated: '2026-02-15', author: 'Sarah M.' },
  { title: 'Troubleshooting Login Issues', category: 'Auth', views: 567, helpful: 76, updated: '2026-01-20', author: 'Mike R.' },
  { title: 'API Rate Limits and Best Practices', category: 'API', views: 234, helpful: 82, updated: '2026-02-28', author: 'Lisa K.' },
  { title: 'Report Export Guide', category: 'Reports', views: 189, helpful: 71, updated: '2025-12-10', author: 'James T.' },
  { title: 'Dashboard Performance Tips', category: 'Performance', views: 145, helpful: 65, updated: '2025-11-15', author: 'Lisa K.' },
];

const badge = (v: string) => {
  const m: Record<string, string> = {
    P1: 'bg-rose-50 text-rose-600', P2: 'bg-amber-50 text-amber-600', P3: 'bg-yellow-50 text-yellow-600', P4: 'bg-gray-100 text-gray-500',
    Open: 'bg-blue-50 text-blue-600', 'In Progress': 'bg-amber-50 text-amber-600', Escalated: 'bg-rose-50 text-rose-600',
    Resolved: 'bg-emerald-50 text-emerald-600', Closed: 'bg-gray-100 text-gray-500', New: 'bg-blue-50 text-blue-600',
    Critical: 'bg-rose-50 text-rose-600', 'On Track': 'bg-emerald-50 text-emerald-600', Overdue: 'bg-rose-50 text-rose-600',
    Healthy: 'bg-emerald-50 text-emerald-600', Warning: 'bg-amber-50 text-amber-600',
  };
  return <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${m[v] || 'bg-gray-100 text-gray-600'}`}>{v}</span>;
};

export default function SupportConsole() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('queue');
  const [sortKey, setSortKey] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalAction, setModalAction] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('/api/agents/support').then(r => r.json())
      .then(d => { setData(d); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const sort = (key: string) => { setSortKey(key); setSortDir(sortKey === key && sortDir === 'asc' ? 'desc' : 'asc'); setExpandedRow(null); };
  const sorted = (rows: any[]) => { if (!sortKey) return rows; return [...rows].sort((a, b) => { const av = a[sortKey], bv = b[sortKey]; const c = typeof av === 'number' ? av - bv : String(av).localeCompare(String(bv)); return sortDir === 'asc' ? c : -c; }); };
  const arrow = (k: string) => sortKey === k ? (sortDir === 'asc' ? ' ↑' : ' ↓') : '';

  const handleAi = async (action: string, payload?: any) => {
    setAiLoading(true); setAiResult(''); setModalAction(action); setModalOpen(true);
    const res = await fetch('/api/agents/support', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, tickets: TICKETS, ...payload }) });
    const r = await res.json(); setAiResult(r.result || r.error || 'Complete'); setAiLoading(false);
  };

  const src = data?.source;
  const tabs = ['queue', 'performance', 'health', 'kb'];
  const KPI = ({ label, value, sub }: { label: string; value: string; sub?: string }) => (
    <div className="bg-white rounded-xl border border-gray-200 p-4">
      <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-extrabold mt-1" style={{ color: '#1B2A4A', fontFamily: "'Outfit', sans-serif" }}>{value}</p>
      {sub && <p className={`text-xs mt-1 font-medium ${sub.includes('↑') || sub.includes('down') ? 'text-emerald-600' : sub.includes('breach') || sub.includes('Critical') ? 'text-rose-600' : 'text-gray-400'}`}>{sub}</p>}
    </div>
  );
  const TH = ({ k, children }: { k: string; children: React.ReactNode }) => (
    <th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400 cursor-pointer hover:text-gray-600" onClick={() => sort(k)}>{children}{arrow(k)}</th>
  );

  if (loading) return <div className="p-8 space-y-4">{[1,2,3,4].map(i => <div key={i} className="h-24 bg-gray-200 rounded-xl animate-pulse" />)}</div>;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3"><span className="text-3xl">🎧</span><div><h1 className="text-2xl font-extrabold" style={{ color: '#1B2A4A', fontFamily: "'Outfit', sans-serif" }}>Support Console</h1><p className="text-xs text-gray-400">People Department</p></div></div>
        {src && <span className={`px-3 py-1 rounded-full text-xs font-medium ${src === 'live' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>{src === 'live' ? 'Live Data' : 'Demo Data'}</span>}
      </div>
      <div className="flex gap-2 border-b border-gray-200">{tabs.map(t => (
        <button key={t} onClick={() => { setTab(t); setExpandedRow(null); setSortKey(''); }} className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === t ? 'border-orange-500 text-orange-600' : 'border-transparent text-gray-400 hover:text-gray-600'}`}>
          {t === 'queue' ? 'Ticket Queue' : t === 'performance' ? 'Performance' : t === 'health' ? 'Customer Health' : 'Knowledge Base'}
        </button>
      ))}</div>

      {tab === 'queue' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Open Tickets" value="47" /><KPI label="Avg Response" value="2.4h" sub="down 18%" /><KPI label="CSAT" value="4.2/5" sub="↑ 0.3" /><KPI label="Resolution Rate" value="89%" />
        </div>
        <input className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="Search tickets..." value={search} onChange={e => setSearch(e.target.value)} />
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">ID</th><TH k="customer">Customer</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Subject</th><TH k="priority">Priority</TH><TH k="status">Status</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Assignee</th><TH k="age">Age</TH><TH k="sla">SLA</TH>
          </tr></thead><tbody>
            {sorted(TICKETS.filter(t => t.subject.toLowerCase().includes(search.toLowerCase()) || t.customer.toLowerCase().includes(search.toLowerCase()))).map((t, i) => (
              <tr key={i} className={`border-t border-gray-100 hover:bg-gray-50 cursor-pointer ${t.sla === 'Overdue' || t.sla === 'Critical' ? 'bg-rose-50/30' : ''}`} onClick={() => setExpandedRow(expandedRow === i ? null : i)}>
                <td className="px-4 py-3 font-mono text-xs font-medium" style={{ color: '#1B2A4A' }}>{t.id}</td><td className="px-4 py-3">{t.customer}</td>
                <td className="px-4 py-3 font-medium text-gray-700 max-w-xs truncate">{t.subject}</td>
                <td className="px-4 py-3">{badge(t.priority)}</td><td className="px-4 py-3">{badge(t.status)}</td>
                <td className="px-4 py-3 text-gray-500">{t.assignee}</td><td className="px-4 py-3">{t.age}</td><td className="px-4 py-3">{badge(t.sla)}</td>
              </tr>
            ))}
          </tbody></table>
          {expandedRow !== null && (() => { const t = sorted(TICKETS.filter(tx => tx.subject.toLowerCase().includes(search.toLowerCase()) || tx.customer.toLowerCase().includes(search.toLowerCase())))[expandedRow]; if (!t) return null; return (
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
              <p className="text-xs text-gray-600 mb-3">{t.description}</p>
              <div className="flex gap-2">
                <button className="px-3 py-1.5 bg-orange-500 text-white rounded-lg text-xs font-medium hover:bg-orange-600" onClick={() => handleAi('draft-response', { subject: t.subject, customerName: t.customer, issue: t.description })}>Draft Response</button>
                <button className="px-3 py-1.5 bg-emerald-500 text-white rounded-lg text-xs font-medium hover:bg-emerald-600" onClick={() => handleAi('knowledge-article', { subject: t.subject, category: 'Support' })}>Generate KB Article</button>
              </div>
            </div>
          ); })()}
        </div>
      </>}

      {tab === 'performance' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="This Month" value="142" /><KPI label="Resolved" value="126" /><KPI label="First Contact" value="67%" /><KPI label="SLA Breaches" value="4" sub="breach count" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <h3 className="text-sm font-bold mb-3" style={{ color: '#1B2A4A' }}>Ticket Volume (30 Days)</h3>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={VOLUME_TREND}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="day" tick={{ fontSize: 10 }} /><YAxis /><Tooltip />
              <Area type="monotone" dataKey="tickets" stroke="#F5920B" fill="#F5920B" fillOpacity={0.15} strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <h3 className="text-sm font-bold mb-3" style={{ color: '#1B2A4A' }}>Avg Response Time (Hours)</h3>
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={RESPONSE_TREND}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="day" tick={{ fontSize: 10 }} /><YAxis /><Tooltip />
              <Line type="monotone" dataKey="hrs" stroke="#2A9D8F" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="name">Agent</TH><TH k="resolved">Resolved</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Avg Resp</th><TH k="csat">CSAT</TH><TH k="fcr">FCR %</TH>
          </tr></thead><tbody>
            {sorted(AGENTS).map((a, i) => (
              <tr key={i} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{a.name}</td><td className="px-4 py-3">{a.resolved}</td>
                <td className="px-4 py-3">{a.avgResp}</td>
                <td className="px-4 py-3 font-bold" style={{ color: a.csat >= 4.2 ? '#059669' : a.csat >= 3.8 ? '#F5920B' : '#DC2626' }}>{a.csat}</td>
                <td className="px-4 py-3">{a.fcr}%</td>
              </tr>
            ))}
          </tbody></table>
        </div>
      </>}

      {tab === 'health' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Healthy" value="45" /><KPI label="Warning" value="8" /><KPI label="Critical" value="2" sub="Critical accounts" /><KPI label="Avg CSAT" value="4.2" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="name">Customer</TH><TH k="csat">CSAT</TH><TH k="open">Open</TH><TH k="total">Total</TH><TH k="health">Health</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Last</th>
          </tr></thead><tbody>
            {sorted(CUSTOMERS).map((c, i) => (
              <tr key={i} className={`border-t border-gray-100 hover:bg-gray-50 cursor-pointer ${c.health === 'Critical' ? 'bg-rose-50/30' : ''}`} onClick={() => setExpandedRow(expandedRow === i ? null : i)}>
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{c.name}</td>
                <td className="px-4 py-3 font-bold" style={{ color: c.csat >= 4.0 ? '#059669' : c.csat >= 3.5 ? '#F5920B' : '#DC2626' }}>{c.csat}</td>
                <td className="px-4 py-3">{c.open}</td><td className="px-4 py-3">{c.total}</td>
                <td className="px-4 py-3">{badge(c.health)}</td><td className="px-4 py-3 text-gray-500">{c.lastInteraction}</td>
              </tr>
            ))}
          </tbody></table>
          {expandedRow !== null && (() => { const c = sorted(CUSTOMERS)[expandedRow]; if (!c) return null; return (
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
              <p className="text-xs text-gray-600 mb-2">{c.history}</p>
            </div>
          ); })()}
        </div>
      </>}

      {tab === 'kb' && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPI label="Total Articles" value="34" /><KPI label="Avg Helpfulness" value="78%" /><KPI label="Needs Update" value="5" /><KPI label="Gaps Identified" value="3" />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm"><thead><tr className="bg-gray-50">
            <TH k="title">Article</TH><TH k="category">Category</TH><TH k="views">Views</TH><TH k="helpful">Helpful %</TH><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Updated</th><th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Author</th>
          </tr></thead><tbody>
            {sorted(KB_ARTICLES).map((a, i) => (
              <tr key={i} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3 font-medium" style={{ color: '#1B2A4A' }}>{a.title}</td><td className="px-4 py-3">{a.category}</td>
                <td className="px-4 py-3">{a.views}</td>
                <td className="px-4 py-3 font-bold" style={{ color: a.helpful >= 80 ? '#059669' : a.helpful >= 70 ? '#F5920B' : '#DC2626' }}>{a.helpful}%</td>
                <td className="px-4 py-3 text-gray-500">{a.updated}</td><td className="px-4 py-3 text-gray-500">{a.author}</td>
              </tr>
            ))}
          </tbody></table>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-orange-500 text-white rounded-lg text-sm font-medium hover:bg-orange-600" onClick={() => handleAi('analyze-trends')}>Analyze Trends</button>
          <button className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600" onClick={() => handleAi('knowledge-article', { subject: 'Login Troubleshooting', category: 'Auth' })}>Generate Article</button>
        </div>
      </>}

      {modalOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={() => setModalOpen(false)}>
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold" style={{ color: '#1B2A4A' }}>{modalAction.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</h3>
              <button className="text-gray-400 hover:text-gray-600 text-xl" onClick={() => setModalOpen(false)}>&#x2715;</button>
            </div>
            {aiLoading ? <div className="flex items-center gap-3 py-8"><div className="w-5 h-5 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" /><span className="text-sm text-gray-500">Analyzing...</span></div>
            : <div className="text-sm text-gray-700 whitespace-pre-wrap">{aiResult}</div>}
            {!aiLoading && aiResult && <button className="mt-4 px-3 py-1.5 bg-gray-100 text-gray-600 rounded-lg text-xs font-medium hover:bg-gray-200" onClick={() => navigator.clipboard.writeText(aiResult)}>Copy to Clipboard</button>}
          </div>
        </div>
      )}
    </div>
  );
}
