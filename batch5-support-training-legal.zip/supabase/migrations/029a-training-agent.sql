CREATE TABLE IF NOT EXISTS agent_training_data (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID REFERENCES companies(id),
  course_name TEXT NOT NULL,
  department TEXT,
  enrolled INTEGER DEFAULT 0,
  completed INTEGER DEFAULT 0,
  completion_rate DECIMAL(5,2),
  due_date DATE,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft','active','completed','overdue','archived')),
  course_type TEXT DEFAULT 'elective' CHECK (course_type IN ('mandatory','compliance','elective','onboarding')),
  instructor TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_training_company ON agent_training_data(company_id);
ALTER TABLE agent_training_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Company isolation" ON agent_training_data FOR ALL
  USING (company_id IN (SELECT company_id FROM users WHERE id = auth.uid()));
