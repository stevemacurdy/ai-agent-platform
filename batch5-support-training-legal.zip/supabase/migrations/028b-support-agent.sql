CREATE TABLE IF NOT EXISTS agent_support_data (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID REFERENCES companies(id),
  subject TEXT NOT NULL,
  customer TEXT,
  contact_email TEXT,
  category TEXT,
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low','medium','high','critical')),
  status TEXT DEFAULT 'new' CHECK (status IN ('new','open','in-progress','waiting','resolved','closed')),
  assignee TEXT,
  sla_deadline TIMESTAMPTZ,
  sla_breach BOOLEAN DEFAULT false,
  response_time DECIMAL(10,2),
  satisfaction INTEGER CHECK (satisfaction BETWEEN 1 AND 5),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_support_company ON agent_support_data(company_id);
ALTER TABLE agent_support_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Company isolation" ON agent_support_data FOR ALL
  USING (company_id IN (SELECT company_id FROM users WHERE id = auth.uid()));
