CREATE TABLE IF NOT EXISTS agent_legal_data (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID REFERENCES companies(id),
  title TEXT NOT NULL,
  counterparty TEXT,
  contract_type TEXT DEFAULT 'other' CHECK (contract_type IN ('nda','msa','sow','vendor','employment','lease','other')),
  value DECIMAL(12,2),
  start_date DATE,
  end_date DATE,
  auto_renew BOOLEAN DEFAULT false,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft','review','active','expired','terminated','renewed')),
  risk_level TEXT DEFAULT 'low' CHECK (risk_level IN ('low','medium','high','critical')),
  key_terms JSONB DEFAULT '{}',
  assigned_to TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_legal_company ON agent_legal_data(company_id);
ALTER TABLE agent_legal_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Company isolation" ON agent_legal_data FOR ALL
  USING (company_id IN (SELECT company_id FROM users WHERE id = auth.uid()));
