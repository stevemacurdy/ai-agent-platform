/**
 * WoulfAI Master Wiring Script — Full-Stack Integration
 * Run from: ai-agent-platform root (after all phase zips installed)
 * node master-wiring.js
 */
const fs = require('fs');
const path = require('path');

let fixes = 0, skips = 0, warnings = [];
function fix(m) { fixes++; console.log('  + ' + m); }
function skip(m) { skips++; console.log('  o ' + m); }
function warn(m) { warnings.push(m); console.log('  ! ' + m); }
function has(f) { return fs.existsSync(f); }
function rd(f) { return fs.readFileSync(f, 'utf8'); }
function wr(f, d) { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, d); }

console.log('');
console.log('  ============================================');
console.log('  WoulfAI Master Wiring Script');
console.log('  ============================================');
console.log('');

// =============================================
// 1. SIDEBAR NAVIGATION
// =============================================
console.log('  [1/7] SIDEBAR NAVIGATION');

const NAV = [
  { id: 'admin-hub', label: 'Admin Hub', href: '/admin', icon: 'H' },
  { id: 'sales-crm', label: 'Sales CRM', href: '/admin/sales-crm', icon: 'S' },
  { id: 'cfo-console', label: 'CFO Console', href: '/agents/cfo/console', icon: 'C' },
  { id: 'payables', label: 'Payables', href: '/agents/cfo/payables', icon: 'P' },
  { id: 'finops', label: 'FinOps Suite', href: '/agents/cfo/finops', icon: 'F' },
  { id: 'finops-pro', label: 'FinOps Pro', href: '/agents/cfo/finops-pro', icon: 'D' },
  { id: 'sales-intel', label: 'Sales Intel', href: '/agents/sales/intel', icon: 'I' },
  { id: 'cfo-tools', label: 'CFO Tools', href: '/agents/cfo/tools', icon: 'T' },
  { id: 'bug-bash', label: 'Bug Bash', href: '/admin/bug-bash', icon: 'B' },
];

const layoutPath = 'app/admin/layout.tsx';
if (has(layoutPath)) {
  let layout = rd(layoutPath);
  const missing = NAV.filter(n => !layout.includes(n.href));
  if (missing.length > 0) {
    const patterns = [
      /(const\s+\w+\s*(?::\s*[^=]*)?\s*=\s*\[)/,
    ];
    let done = false;
    for (const p of patterns) {
      const m = layout.match(p);
      if (m) {
        const idx = m.index + m[0].length;
        const inj = missing.map(n =>
          `\n    { id: '${n.id}', label: '${n.label}', href: '${n.href}', icon: '${n.icon}' },`
        ).join('');
        layout = layout.slice(0, idx) + inj + layout.slice(idx);
        done = true; break;
      }
    }
    if (done) { wr(layoutPath, layout); fix('Added ' + missing.length + ' sidebar items: ' + missing.map(n => n.label).join(', ')); }
    else {
      // Write config file as fallback
      wr('lib/nav-config.ts', `export const NAV_ITEMS = ${JSON.stringify(NAV, null, 2)};\n`);
      warn('Auto-patch failed. Created lib/nav-config.ts — merge manually');
      missing.forEach(n => console.log(`      { id: '${n.id}', label: '${n.label}', href: '${n.href}' }`));
    }
  } else skip('All sidebar items present');
} else warn('app/admin/layout.tsx not found');

// =============================================
// 2. ROOT LAYOUT — suppressHydrationWarning
// =============================================
console.log('');
console.log('  [2/7] ROOT LAYOUT');

if (has('app/layout.tsx')) {
  let root = rd('app/layout.tsx');
  if (!root.includes('suppressHydrationWarning')) {
    root = root.replace(/<body(?=[>\s])/g, '<body suppressHydrationWarning');
    wr('app/layout.tsx', root);
    fix('Added suppressHydrationWarning to <body>');
  } else skip('suppressHydrationWarning present');
} else warn('app/layout.tsx not found');

// =============================================
// 3. LIB/SUPABASE.TS — Required exports
// =============================================
console.log('');
console.log('  [3/7] LIB/SUPABASE.TS');

if (has('lib/supabase.ts')) {
  let sb = rd('lib/supabase.ts');
  let patched = false;
  const adds = [
    [/AgentName/, 'export type AgentName = "wms" | "support" | "sales" | "cfo" | "marketing";', 'AgentName type'],
    [/export type User|export interface User/, 'export type User = { email: string; role: string; permissions: Record<string, boolean> };', 'User type'],
    [/ALL_AGENTS/, 'export const ALL_AGENTS: AgentName[] = ["wms", "support", "sales", "cfo", "marketing"];', 'ALL_AGENTS'],
    [/getUserAgents/, 'export function getUserAgents(user: any): AgentName[] { return ALL_AGENTS; }', 'getUserAgents'],
    [/isSuperAdmin/, 'export function isSuperAdmin(user: any): boolean { return user?.role === "super_admin"; }', 'isSuperAdmin'],
    [/canAccessAdmin/, 'export function canAccessAdmin(user: any): boolean { return !!user && ["super_admin","org_admin","employee"].includes(user.role); }', 'canAccessAdmin'],
    [/getLoginRedirect/, 'export function getLoginRedirect(user: any): string { if (!user) return "/login"; if (user.role === "beta_tester") return "/dashboard/bug-bash"; return "/admin"; }', 'getLoginRedirect'],
    [/getCurrentUser/, `export async function getCurrentUser() {\n  try { const s = typeof window !== 'undefined' ? localStorage.getItem('woulfai_session') : null; if (!s) return null; const p = JSON.parse(s); if (!p.loggedIn && !p.user) return null; return { email: p.user?.email || 'admin', role: 'super_admin', permissions: { sales_agent: true, cfo_agent: true, admin_analytics: true, agent_creator: true, wms_agent: true } }; } catch { return null }\n}`, 'getCurrentUser'],
  ];
  for (const [regex, code, label] of adds) {
    if (!regex.test(sb)) { sb += '\n' + code + '\n'; patched = true; fix('Added ' + label); }
    else skip(label + ' present');
  }
  if (patched) wr('lib/supabase.ts', sb);
} else warn('lib/supabase.ts not found');

// =============================================
// 4. API ENDPOINT AUDIT
// =============================================
console.log('');
console.log('  [4/7] API ENDPOINTS');

const APIS = {
  'app/api/intelligence/route.ts': 'AI Personality',
  'app/api/documents/route.ts': 'Doc Scanner (Trump Rule)',
  'app/api/reimbursements/route.ts': 'Reimbursements',
  'app/api/debrief/route.ts': 'Field Debrief',
  'app/api/ap/route.ts': 'Accounts Payable',
  'app/api/debt/route.ts': 'Debt Manager',
  'app/api/labor/route.ts': 'Labor Tracking',
  'app/api/forecasting/route.ts': 'Forecasting',
  'app/api/sandbox/route.ts': 'Business Sandbox',
  'app/api/tax-reserve/route.ts': 'Tax Reserve',
  'app/api/duplicate-detection/route.ts': 'Duplicate Detection',
  'app/api/anomaly/route.ts': 'Anomaly Detection',
  'app/api/vendor-scoring/route.ts': 'Vendor Scoring',
  'app/api/lending-packet/route.ts': 'Lending Packet',
  'app/api/finance-capture/route.ts': 'Payables OCR',
  'app/api/finance-reconcile/route.ts': 'Bank Reconciliation',
  'app/api/sales-intel/route.ts': 'Sales Intel',
  'app/api/cfo-invoices/route.ts': 'Invoice Drill-Down',
  'app/api/cfo-collections/route.ts': 'AI Collections',
  'app/api/cfo-health/route.ts': 'Financial Health',
  'app/api/cfo-cashflow/route.ts': 'Cashflow Forecast',
};

for (const [f, l] of Object.entries(APIS)) {
  if (has(f)) skip(l); else warn('MISSING: ' + l + ' -> ' + f);
}

// =============================================
// 5. UI PAGE AUDIT
// =============================================
console.log('');
console.log('  [5/7] UI PAGES');

const PAGES = {
  'app/admin/page.tsx': 'Admin Hub',
  'app/admin/sales-crm/page.tsx': 'Sales CRM',
  'app/admin/bug-bash/page.tsx': 'Bug Bash',
  'app/agents/cfo/tools/page.tsx': 'CFO Tools',
  'app/agents/cfo/finops/page.tsx': 'FinOps Suite',
  'app/agents/cfo/finops-pro/page.tsx': 'FinOps Pro',
  'app/agents/cfo/payables/page.tsx': 'Payables Engine',
  'app/agents/cfo/console/page.tsx': 'CFO Console',
  'app/agents/sales/intel/page.tsx': 'Sales Intel',
  'app/dashboard/page.tsx': 'Dashboard',
};

for (const [f, l] of Object.entries(PAGES)) {
  if (has(f)) skip(l); else warn('MISSING: ' + l + ' -> ' + f);
}

// =============================================
// 6. CROSS-WIRING
// =============================================
console.log('');
console.log('  [6/7] CROSS-WIRING');

// Dashboard CFO route
if (has('app/dashboard/page.tsx')) {
  let d = rd('app/dashboard/page.tsx');
  if (d.includes("'/agents/cfo'") && !d.includes("'/agents/cfo/console'")) {
    d = d.replace(/['"]\/agents\/cfo['"]/g, "'/agents/cfo/console'");
    wr('app/dashboard/page.tsx', d);
    fix('Dashboard CFO route -> /agents/cfo/console');
  } else skip('Dashboard routes OK');
}

// Console -> Payables link
if (has('app/agents/cfo/console/page.tsx')) {
  const c = rd('app/agents/cfo/console/page.tsx');
  if (c.includes('/agents/cfo/payables')) skip('Console -> Payables linked');
  else warn('Console missing Payables link');
}

// Collections -> Invoices
if (has('app/api/cfo-collections/route.ts')) {
  if (rd('app/api/cfo-collections/route.ts').includes('/api/cfo-invoices')) skip('Collections -> Invoices wired');
  else warn('Collections not wired to Invoices');
}

// Health -> AP + Debt
if (has('app/api/cfo-health/route.ts')) {
  const h = rd('app/api/cfo-health/route.ts');
  if (h.includes('/api/cfo-invoices') && h.includes('/api/ap')) skip('Health -> AP, Invoices wired');
  else warn('Health missing internal wires');
}

// Cashflow sources
if (has('app/api/cfo-cashflow/route.ts')) {
  const cf = rd('app/api/cfo-cashflow/route.ts');
  if (cf.includes('hubspotDeals') && cf.includes('odooReceivables')) skip('Cashflow sources present');
  else warn('Cashflow missing data sources');
}

// =============================================
// 7. VERIFICATION COMMANDS
// =============================================
console.log('');
console.log('  [7/7] VERIFICATION COMMANDS');
console.log('  After npm run dev, run each to confirm:');
console.log('');

const B = 'http://localhost:3000';
const H2 = '-H "x-admin-email: admin"';
const parse = "node -e \"d=JSON.parse(require('fs').readFileSync(0,'utf8'));";

[
  ['AP Engine',      `curl -s ${H2} "${B}/api/ap" | ${parse}console.log('OK:',d.expenses?.length,'expenses')"`],
  ['Debt',           `curl -s ${H2} "${B}/api/debt" | ${parse}console.log('OK:',Object.keys(d).length,'keys')"`],
  ['Tax Reserve',    `curl -s ${H2} "${B}/api/tax-reserve" | ${parse}console.log('OK:',!!d.quarterlyPayments)"`],
  ['Vendor Scoring', `curl -s ${H2} "${B}/api/vendor-scoring" | ${parse}console.log('OK:',d.vendors?.length,'vendors')"`],
  ['Lending Packet', `curl -s ${H2} "${B}/api/lending-packet?view=preview" | ${parse}console.log('OK:',!!d.packet)"`],
  ['Payables OCR',   `curl -s ${H2} "${B}/api/finance-capture?view=pending" | ${parse}console.log('OK:',d.items?.length,'pending')"`],
  ['Reconciliation', `curl -s ${H2} "${B}/api/finance-reconcile" | ${parse}console.log('OK:',d.reconciliation?.totalTransactions,'txns')"`],
  ['Sales Intel',    `curl -s ${H2} "${B}/api/sales-intel" | ${parse}console.log('OK:',d.totalProfiles,'profiles')"`],
  ['Invoices',       `curl -s ${H2} "${B}/api/cfo-invoices" | ${parse}console.log('OK:',d.invoices?.length,'inv, AR:'+d.summary?.totalAR)"`],
  ['Collections',    `curl -s ${H2} "${B}/api/cfo-collections" | ${parse}console.log('OK:',d.debtorCount,'debtors')"`],
  ['Health Score',   `curl -s ${H2} "${B}/api/cfo-health?view=health" | ${parse}console.log('OK: score='+d.healthScore+'/100')"`],
  ['Cashflow',       `curl -s ${H2} "${B}/api/cfo-cashflow" | ${parse}console.log('OK: 90d='+d.totals?.endingCash90)"`],
].forEach(([mod, cmd]) => {
  console.log(`    # ${mod}`);
  console.log(`    ${cmd}`);
  console.log('');
});

// =============================================
// SUMMARY
// =============================================
console.log('  ============================================');
console.log('  Fixes:    ' + fixes);
console.log('  OK:       ' + skips);
console.log('  Warnings: ' + warnings.length);
console.log('  ============================================');
if (warnings.length > 0) {
  console.log('');
  console.log('  ACTIONS REQUIRED:');
  warnings.forEach((w, i) => console.log('    ' + (i + 1) + '. ' + w));
}
console.log('');
