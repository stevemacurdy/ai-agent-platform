-- ============================================================================
-- WoulfAI Migration 005: Phase 6/7 Tables
-- Run AFTER 004_finops_suite.sql
-- Covers: Invoice audit log, bank transactions, payment log, tax reserve
--         buckets, anomaly logs, behavioral profiles
-- ============================================================================

-- Ensure trigger function exists
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================
-- 1. INVOICE AUDIT LOG (Phase 7)
-- Tracks every line-item edit with before/after values
-- ============================
CREATE TABLE IF NOT EXISTS invoice_audit_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  invoice_id TEXT NOT NULL,
  line_item_id TEXT,
  user_id UUID REFERENCES profiles(id),
  user_email TEXT,
  action TEXT NOT NULL CHECK (action IN (
    'line_item_edit', 'line_item_added', 'line_item_removed',
    'payment_received', 'partial_payment', 'status_change',
    'odoo_sync', 'void', 'refund'
  )),
  field_changed TEXT,
  old_value JSONB,
  new_value JSONB,
  odoo_synced BOOLEAN DEFAULT FALSE,
  odoo_sync_timestamp TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================
-- 2. BANK TRANSACTIONS (Phase 6)
-- Stores Plaid/Odoo bank feed for reconciliation
-- ============================
CREATE TABLE IF NOT EXISTS bank_transactions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  external_id TEXT,
  date DATE NOT NULL,
  description TEXT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  transaction_type TEXT CHECK (transaction_type IN ('debit', 'credit')),
  account_name TEXT,
  account_last4 TEXT,
  reconciled BOOLEAN DEFAULT FALSE,
  matched_expense_id UUID,
  match_type TEXT CHECK (match_type IN ('exact', 'auto', 'manual', 'dismissed')),
  match_confidence DECIMAL(5,2),
  source TEXT DEFAULT 'manual' CHECK (source IN ('plaid', 'odoo', 'manual', 'csv_import')),
  raw_data JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================
-- 3. PAYMENT LOG (Phase 6)
-- Every outbound payment with confirmation tracking
-- ============================
CREATE TABLE IF NOT EXISTS payment_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  expense_id UUID REFERENCES ap_expenses(id),
  vendor_name TEXT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  payment_method_id TEXT,
  payment_method_label TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'reversed')),
  confirmation_number TEXT,
  paid_at TIMESTAMPTZ,
  odoo_synced BOOLEAN DEFAULT FALSE,
  odoo_sync_timestamp TIMESTAMPTZ,
  initiated_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================
-- 4. TAX RESERVE BUCKETS (Phase 5b)
-- Quarterly set-asides with alert thresholds
-- ============================
CREATE TABLE IF NOT EXISTS tax_reserve_buckets (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  quarter TEXT NOT NULL,
  year INTEGER NOT NULL,
  federal_reserve DECIMAL(12,2) DEFAULT 0,
  state_reserve DECIMAL(12,2) DEFAULT 0,
  payroll_reserve DECIMAL(12,2) DEFAULT 0,
  total_reserve DECIMAL(12,2) DEFAULT 0,
  target_amount DECIMAL(12,2) DEFAULT 0,
  actual_deposited DECIMAL(12,2) DEFAULT 0,
  shortfall DECIMAL(12,2) DEFAULT 0,
  due_date DATE,
  status TEXT DEFAULT 'accumulating' CHECK (status IN ('accumulating', 'funded', 'underfunded', 'paid')),
  alert_sent BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(org_id, quarter, year)
);

-- ============================
-- 5. ANOMALY LOGS (Phase 5b)
-- Historical baseline comparisons and detected anomalies
-- ============================
CREATE TABLE IF NOT EXISTS anomaly_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  detection_type TEXT CHECK (detection_type IN ('spike', 'new_vendor', 'category_drift', 'duplicate', 'timing', 'amount')),
  severity TEXT CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  vendor_name TEXT,
  category TEXT,
  current_amount DECIMAL(12,2),
  baseline_amount DECIMAL(12,2),
  deviation_percent DECIMAL(8,2),
  description TEXT,
  expense_id UUID,
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'investigating', 'resolved', 'dismissed')),
  resolved_by UUID REFERENCES profiles(id),
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================
-- 6. BEHAVIORAL PROFILES (Phase 6)
-- Sales intel personality analysis + battle cards
-- ============================
CREATE TABLE IF NOT EXISTS behavioral_profiles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id) ON DELETE CASCADE,
  contact_name TEXT NOT NULL,
  company TEXT,
  communication_style TEXT CHECK (communication_style IN ('Direct', 'Analytical', 'Relational', 'Expressive')),
  tone_pace TEXT,
  buyer_persona TEXT,
  persona_description TEXT,
  reality_potential_score INTEGER CHECK (reality_potential_score BETWEEN 0 AND 100),
  buying_triggers TEXT[],
  buying_bridge TEXT,
  engagement_level TEXT CHECK (engagement_level IN ('very_high', 'high', 'medium', 'low')),
  pain_points TEXT[],
  do_list TEXT[],
  dont_list TEXT[],
  negotiation_tips TEXT[],
  meeting_notes TEXT,
  analysis_source TEXT CHECK (analysis_source IN ('meeting_notes', 'transcript', 'email', 'call_recording')),
  last_analyzed TIMESTAMPTZ,
  hubspot_synced BOOLEAN DEFAULT FALSE,
  hubspot_sync_timestamp TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================
-- 7. RLS POLICIES
-- ============================
ALTER TABLE invoice_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE tax_reserve_buckets ENABLE ROW LEVEL SECURITY;
ALTER TABLE anomaly_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE behavioral_profiles ENABLE ROW LEVEL SECURITY;

-- Super admin full access
CREATE POLICY "sa_audit" ON invoice_audit_log FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin'));
CREATE POLICY "sa_bank_tx" ON bank_transactions FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin'));
CREATE POLICY "sa_payments" ON payment_log FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin'));
CREATE POLICY "sa_tax" ON tax_reserve_buckets FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin'));
CREATE POLICY "sa_anomaly" ON anomaly_logs FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin'));
CREATE POLICY "sa_behavioral" ON behavioral_profiles FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'super_admin'));

-- Org-scoped access
CREATE POLICY "org_audit" ON invoice_audit_log FOR ALL
  USING (org_id IN (SELECT org_id FROM profiles WHERE id = auth.uid()));
CREATE POLICY "org_bank_tx" ON bank_transactions FOR ALL
  USING (org_id IN (SELECT org_id FROM profiles WHERE id = auth.uid()));
CREATE POLICY "org_payments" ON payment_log FOR ALL
  USING (org_id IN (SELECT org_id FROM profiles WHERE id = auth.uid()));
CREATE POLICY "org_tax" ON tax_reserve_buckets FOR ALL
  USING (org_id IN (SELECT org_id FROM profiles WHERE id = auth.uid()));
CREATE POLICY "org_anomaly" ON anomaly_logs FOR ALL
  USING (org_id IN (SELECT org_id FROM profiles WHERE id = auth.uid()));
CREATE POLICY "org_behavioral" ON behavioral_profiles FOR ALL
  USING (org_id IN (SELECT org_id FROM profiles WHERE id = auth.uid()));

-- ============================
-- 8. INDEXES
-- ============================
CREATE INDEX IF NOT EXISTS idx_audit_invoice ON invoice_audit_log(invoice_id);
CREATE INDEX IF NOT EXISTS idx_audit_user ON invoice_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON invoice_audit_log(action);
CREATE INDEX IF NOT EXISTS idx_audit_created ON invoice_audit_log(created_at);

CREATE INDEX IF NOT EXISTS idx_bank_tx_date ON bank_transactions(date);
CREATE INDEX IF NOT EXISTS idx_bank_tx_reconciled ON bank_transactions(reconciled);
CREATE INDEX IF NOT EXISTS idx_bank_tx_org ON bank_transactions(org_id);

CREATE INDEX IF NOT EXISTS idx_payment_expense ON payment_log(expense_id);
CREATE INDEX IF NOT EXISTS idx_payment_status ON payment_log(status);
CREATE INDEX IF NOT EXISTS idx_payment_vendor ON payment_log(vendor_name);

CREATE INDEX IF NOT EXISTS idx_tax_quarter ON tax_reserve_buckets(quarter, year);
CREATE INDEX IF NOT EXISTS idx_tax_status ON tax_reserve_buckets(status);

CREATE INDEX IF NOT EXISTS idx_anomaly_type ON anomaly_logs(detection_type);
CREATE INDEX IF NOT EXISTS idx_anomaly_severity ON anomaly_logs(severity);
CREATE INDEX IF NOT EXISTS idx_anomaly_status ON anomaly_logs(status);

CREATE INDEX IF NOT EXISTS idx_behavioral_contact ON behavioral_profiles(contact_id);
CREATE INDEX IF NOT EXISTS idx_behavioral_style ON behavioral_profiles(communication_style);
CREATE INDEX IF NOT EXISTS idx_behavioral_score ON behavioral_profiles(reality_potential_score);

-- ============================
-- 9. TRIGGERS
-- ============================
DROP TRIGGER IF EXISTS bank_tx_ts ON bank_transactions;
CREATE TRIGGER bank_tx_ts BEFORE UPDATE ON bank_transactions
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS payment_ts ON payment_log;
CREATE TRIGGER payment_ts BEFORE UPDATE ON payment_log
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS tax_ts ON tax_reserve_buckets;
CREATE TRIGGER tax_ts BEFORE UPDATE ON tax_reserve_buckets
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS behavioral_ts ON behavioral_profiles;
CREATE TRIGGER behavioral_ts BEFORE UPDATE ON behavioral_profiles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ============================
-- 10. ADD personality_bio + reality_potential_score TO contacts (if missing)
-- ============================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'contacts' AND column_name = 'personality_bio') THEN
    ALTER TABLE contacts ADD COLUMN personality_bio TEXT;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'contacts' AND column_name = 'reality_potential_score') THEN
    ALTER TABLE contacts ADD COLUMN reality_potential_score INTEGER CHECK (reality_potential_score BETWEEN 0 AND 100);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'contacts' AND column_name = 'communication_style') THEN
    ALTER TABLE contacts ADD COLUMN communication_style TEXT;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'contacts' AND column_name = 'buyer_persona') THEN
    ALTER TABLE contacts ADD COLUMN buyer_persona TEXT;
  END IF;
END $$;
