import { NextRequest, NextResponse } from 'next/server';

const ADMINS = ['steve@woulfgroup.com', 'stevemacurdy@gmail.com', 'admin'];
function isAuth(req: NextRequest) { const e = req.headers.get('x-admin-email'); return e && ADMINS.includes(e.toLowerCase()); }

const AP_CATEGORIES = [
  { key: 'advertising', label: 'Advertising' },
  { key: 'car_truck', label: 'Car/Truck' },
  { key: 'commissions_fees', label: 'Commissions & Fees' },
  { key: 'contract_labor', label: 'Contract Labor' },
  { key: 'employee_benefits', label: 'Employee Benefits' },
  { key: 'insurance', label: 'Insurance' },
  { key: 'interest_mortgage', label: 'Interest/Mortgage' },
  { key: 'legal_professional', label: 'Legal/Professional' },
  { key: 'office_expense', label: 'Office Expense' },
  { key: 'profit_sharing', label: 'Profit Sharing' },
  { key: 'rent_lease_vehicles', label: 'Rent/Lease (Vehicles)' },
  { key: 'rent_lease_machinery', label: 'Rent/Lease (Machinery)' },
  { key: 'rent_lease_property', label: 'Rent/Lease (Property)' },
  { key: 'repairs_maintenance', label: 'Repairs & Maintenance' },
  { key: 'supplies', label: 'Supplies' },
  { key: 'taxes_licenses', label: 'Taxes & Licenses' },
  { key: 'travel_meals', label: 'Travel & Meals' },
  { key: 'utilities', label: 'Utilities' },
  { key: 'wages', label: 'Wages' },
];

// In-memory store
let expenses: any[] = [
  { id: 'ap-1', vendorName: 'Google Ads', invoiceNumber: 'GADS-2026-01', description: 'January ad spend', amount: 4200, category: 'advertising', allocationType: 'overhead', projectId: null, invoiceDate: '2026-01-15', dueDate: '2026-02-15', paidDate: '2026-01-28', status: 'paid', odooAccount: 'woulf', ocrData: {} },
  { id: 'ap-2', vendorName: 'CAT Financial', invoiceNumber: 'CAT-88741', description: 'Forklift lease — monthly', amount: 3800, category: 'rent_lease_machinery', allocationType: 'project', projectId: 'proj-1', invoiceDate: '2026-02-01', dueDate: '2026-03-01', paidDate: null, status: 'approved', odooAccount: 'woulf', ocrData: {} },
  { id: 'ap-3', vendorName: 'Smith & Associates', invoiceNumber: 'SA-1147', description: 'Contract review — Pinnacle deal', amount: 2500, category: 'legal_professional', allocationType: 'project', projectId: 'proj-2', invoiceDate: '2026-01-20', dueDate: '2026-02-20', paidDate: null, status: 'pending', odooAccount: 'woulf', ocrData: {} },
  { id: 'ap-4', vendorName: 'National Grid', invoiceNumber: 'NG-Feb-2026', description: 'Warehouse electricity', amount: 1890, category: 'utilities', allocationType: 'overhead', projectId: null, invoiceDate: '2026-02-05', dueDate: '2026-03-05', paidDate: null, status: 'pending', odooAccount: 'woulf', ocrData: {} },
  { id: 'ap-5', vendorName: 'ADP Payroll', invoiceNumber: 'ADP-W9-FEB', description: 'Feb payroll — warehouse crew', amount: 38500, category: 'wages', allocationType: 'overhead', projectId: null, invoiceDate: '2026-02-14', dueDate: '2026-02-14', paidDate: '2026-02-14', status: 'paid', odooAccount: 'woulf', ocrData: {} },
  { id: 'ap-6', vendorName: 'Delta Airlines', invoiceNumber: 'DL-8847221', description: 'Sarah — NYC client trip', amount: 485, category: 'travel_meals', allocationType: 'project', projectId: 'proj-2', invoiceDate: '2026-01-08', dueDate: '2026-01-08', paidDate: '2026-01-08', status: 'paid', odooAccount: 'woulf', ocrData: {} },
  { id: 'ap-7', vendorName: 'Clutch Client Co', invoiceNumber: 'CC-001', description: 'Rack installation materials', amount: 12400, category: 'supplies', allocationType: 'project', projectId: 'proj-3', invoiceDate: '2026-02-01', dueDate: '2026-03-01', paidDate: null, status: 'approved', odooAccount: 'clutch', ocrData: {} },
  { id: 'ap-8', vendorName: 'State Farm', invoiceNumber: 'SF-Q1-2026', description: 'Q1 general liability premium', amount: 6200, category: 'insurance', allocationType: 'overhead', projectId: null, invoiceDate: '2026-01-01', dueDate: '2026-01-15', paidDate: '2026-01-12', status: 'paid', odooAccount: 'woulf', ocrData: {} },
];

let projects: any[] = [
  { id: 'proj-1', name: 'Logicorp Warehouse Expansion', code: 'LOG-WE-2026', client: 'Logicorp', odooAccount: 'woulf', budget: 185000, status: 'active', startDate: '2025-11-01', endDate: '2026-06-30' },
  { id: 'proj-2', name: 'Pinnacle Group Digital Overhaul', code: 'PIN-DO-2026', client: 'Pinnacle Group', odooAccount: 'woulf', budget: 95000, status: 'active', startDate: '2026-01-15', endDate: '2026-08-01' },
  { id: 'proj-3', name: 'Clutch Rack Installation', code: 'CLU-RI-2026', client: 'Clutch Client', odooAccount: 'clutch', budget: 45000, status: 'active', startDate: '2026-02-01', endDate: '2026-04-30' },
];

// AI categorization
async function aiCategorize(description: string, vendor: string): Promise<string> {
  const OPENAI_KEY = process.env.OPENAI_API_KEY;
  if (!OPENAI_KEY) {
    const lower = (description + ' ' + vendor).toLowerCase();
    if (lower.includes('ad') || lower.includes('marketing')) return 'advertising';
    if (lower.includes('legal') || lower.includes('attorney')) return 'legal_professional';
    if (lower.includes('electric') || lower.includes('water') || lower.includes('gas')) return 'utilities';
    if (lower.includes('payroll') || lower.includes('wage') || lower.includes('salary')) return 'wages';
    if (lower.includes('travel') || lower.includes('flight') || lower.includes('hotel') || lower.includes('meal')) return 'travel_meals';
    if (lower.includes('insurance')) return 'insurance';
    if (lower.includes('lease') || lower.includes('rent')) return 'rent_lease_property';
    if (lower.includes('repair') || lower.includes('maintenance')) return 'repairs_maintenance';
    return 'office_expense';
  }
  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: `Categorize this expense. Vendor: "${vendor}". Description: "${description}". Return ONLY one of these category keys: ${AP_CATEGORIES.map(c => c.key).join(', ')}` }],
        temperature: 0.1, max_tokens: 50,
      }),
    });
    const data = await res.json();
    const cat = data.choices?.[0]?.message?.content?.trim().toLowerCase();
    return AP_CATEGORIES.find(c => c.key === cat) ? cat : 'office_expense';
  } catch { return 'office_expense'; }
}

export async function GET(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const { searchParams } = new URL(request.url);
  const view = searchParams.get('view');
  const basis = searchParams.get('basis') || 'accrual'; // cash or accrual
  const odooAccount = searchParams.get('odoo') || 'all';

  let filtered = expenses;
  if (odooAccount !== 'all') filtered = filtered.filter(e => e.odooAccount === odooAccount);

  if (view === 'categories') return NextResponse.json({ categories: AP_CATEGORIES });
  if (view === 'projects') return NextResponse.json({ projects });

  if (view === 'summary') {
    // Cash basis: only count paid expenses. Accrual: count all approved+paid by invoice date
    const relevant = basis === 'cash'
      ? filtered.filter(e => e.status === 'paid' && e.paidDate)
      : filtered.filter(e => ['approved', 'paid'].includes(e.status));

    const byCategory: Record<string, number> = {};
    for (const e of relevant) byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;

    const byProject: Record<string, { name: string; total: number; budget: number }> = {};
    for (const e of relevant.filter(x => x.allocationType === 'project' && x.projectId)) {
      const proj = projects.find(p => p.id === e.projectId);
      if (!byProject[e.projectId]) byProject[e.projectId] = { name: proj?.name || 'Unknown', total: 0, budget: proj?.budget || 0 };
      byProject[e.projectId].total += e.amount;
    }

    const totalAP = relevant.reduce((s, e) => s + e.amount, 0);
    const overheadTotal = relevant.filter(e => e.allocationType === 'overhead').reduce((s, e) => s + e.amount, 0);
    const projectTotal = relevant.filter(e => e.allocationType === 'project').reduce((s, e) => s + e.amount, 0);
    const pendingTotal = filtered.filter(e => e.status === 'pending').reduce((s, e) => s + e.amount, 0);
    const woulfTotal = relevant.filter(e => e.odooAccount === 'woulf').reduce((s, e) => s + e.amount, 0);
    const clutchTotal = relevant.filter(e => e.odooAccount === 'clutch').reduce((s, e) => s + e.amount, 0);

    return NextResponse.json({
      basis, totalAP, overheadTotal, projectTotal, pendingTotal, woulfTotal, clutchTotal,
      byCategory: Object.entries(byCategory).map(([k, v]) => ({ category: k, label: AP_CATEGORIES.find(c => c.key === k)?.label || k, amount: v })).sort((a, b) => b.amount - a.amount),
      byProject: Object.entries(byProject).map(([id, v]) => ({ projectId: id, ...v, utilization: v.budget > 0 ? Math.round(v.total / v.budget * 100) : 0 })),
    });
  }

  if (view === 'project-pnl') {
    const projectId = searchParams.get('projectId');
    if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 });
    const proj = projects.find(p => p.id === projectId);
    const projExpenses = filtered.filter(e => e.projectId === projectId);
    return NextResponse.json({ project: proj, expenses: projExpenses, total: projExpenses.reduce((s, e) => s + e.amount, 0) });
  }

  return NextResponse.json({ expenses: filtered, projects, categories: AP_CATEGORIES });
}

export async function POST(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const body = await request.json();

  switch (body.action) {
    case 'create': {
      if (!body.vendorName || !body.amount || !body.category || !body.invoiceDate) {
        return NextResponse.json({ error: 'vendorName, amount, category, invoiceDate required' }, { status: 400 });
      }
      if (!AP_CATEGORIES.find(c => c.key === body.category)) {
        return NextResponse.json({ error: 'Invalid category. Must be one of: ' + AP_CATEGORIES.map(c => c.key).join(', ') }, { status: 400 });
      }
      const expense = {
        id: 'ap-' + Date.now(), vendorName: body.vendorName, invoiceNumber: body.invoiceNumber || '',
        description: body.description || '', amount: body.amount, category: body.category,
        allocationType: body.allocationType || 'overhead', projectId: body.projectId || null,
        invoiceDate: body.invoiceDate, dueDate: body.dueDate || null, paidDate: null,
        status: 'pending', odooAccount: body.odooAccount || 'woulf', ocrData: {},
      };
      expenses.push(expense);
      return NextResponse.json({ expense });
    }

    case 'scan': {
      const suggestedCategory = await aiCategorize(body.description || '', body.vendorName || '');
      return NextResponse.json({
        suggestedCategory,
        suggestedCategoryLabel: AP_CATEGORIES.find(c => c.key === suggestedCategory)?.label,
        allCategories: AP_CATEGORIES,
      });
    }

    case 'approve': {
      const idx = expenses.findIndex(e => e.id === body.expenseId);
      if (idx === -1) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      expenses[idx].status = 'approved';
      return NextResponse.json({ expense: expenses[idx] });
    }

    case 'pay': {
      const idx = expenses.findIndex(e => e.id === body.expenseId);
      if (idx === -1) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      expenses[idx].status = 'paid';
      expenses[idx].paidDate = body.paidDate || new Date().toISOString().split('T')[0];
      return NextResponse.json({ expense: expenses[idx] });
    }

    case 'create-project': {
      const proj = {
        id: 'proj-' + Date.now(), name: body.name, code: body.code || '', client: body.client || '',
        odooAccount: body.odooAccount || 'woulf', budget: body.budget || 0, status: 'active',
        startDate: body.startDate || null, endDate: body.endDate || null,
      };
      projects.push(proj);
      return NextResponse.json({ project: proj });
    }

    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
