import { NextRequest, NextResponse } from 'next/server';

const ADMINS = ['steve@woulfgroup.com', 'stevemacurdy@gmail.com', 'admin'];
function isAuth(req: NextRequest) { const e = req.headers.get('x-admin-email'); return e && ADMINS.includes(e.toLowerCase()); }

let entries: any[] = [
  { id: 'lb-1', employeeName: 'Marcus Williams', employeeEmail: 'marcus@woulfgroup.com', projectId: 'proj-1', projectName: 'Logicorp Warehouse Expansion', task: 'Rack installation — Bay 4-6', clockIn: '2026-02-14T07:00:00Z', clockOut: '2026-02-14T15:30:00Z', hours: 8.5, hourlyRate: 35, totalCost: 297.50, status: 'approved' },
  { id: 'lb-2', employeeName: 'Marcus Williams', employeeEmail: 'marcus@woulfgroup.com', projectId: 'proj-1', projectName: 'Logicorp Warehouse Expansion', task: 'Conveyor alignment', clockIn: '2026-02-15T07:00:00Z', clockOut: '2026-02-15T16:00:00Z', hours: 9, hourlyRate: 35, totalCost: 315, status: 'approved' },
  { id: 'lb-3', employeeName: 'Jake Torres', employeeEmail: 'jake@woulfgroup.com', projectId: 'proj-1', projectName: 'Logicorp Warehouse Expansion', task: 'Electrical rough-in', clockIn: '2026-02-14T07:30:00Z', clockOut: '2026-02-14T16:00:00Z', hours: 8.5, hourlyRate: 42, totalCost: 357, status: 'approved' },
  { id: 'lb-4', employeeName: 'Jake Torres', employeeEmail: 'jake@woulfgroup.com', projectId: 'proj-3', projectName: 'Clutch Rack Installation', task: 'Site survey and layout', clockIn: '2026-02-15T08:00:00Z', clockOut: '2026-02-15T14:00:00Z', hours: 6, hourlyRate: 42, totalCost: 252, status: 'completed' },
  { id: 'lb-5', employeeName: 'Sarah Chen', employeeEmail: 'sarah@woulfgroup.com', projectId: 'proj-2', projectName: 'Pinnacle Group Digital Overhaul', task: 'Requirements gathering — onsite', clockIn: '2026-02-13T09:00:00Z', clockOut: '2026-02-13T17:00:00Z', hours: 8, hourlyRate: 55, totalCost: 440, status: 'approved' },
  { id: 'lb-6', employeeName: 'Carlos Reyes', employeeEmail: 'carlos@woulfgroup.com', projectId: 'proj-1', projectName: 'Logicorp Warehouse Expansion', task: 'Forklift operation — material movement', clockIn: '2026-02-16T06:30:00Z', clockOut: null, hours: null, hourlyRate: 28, totalCost: null, status: 'active' },
];

export async function GET(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const { searchParams } = new URL(request.url);
  const view = searchParams.get('view');

  if (view === 'active') {
    return NextResponse.json({ entries: entries.filter(e => e.status === 'active') });
  }

  if (view === 'summary') {
    const completed = entries.filter(e => e.status !== 'active');
    const byProject: Record<string, { name: string; hours: number; cost: number; workers: Set<string> }> = {};
    for (const e of completed) {
      if (!byProject[e.projectId]) byProject[e.projectId] = { name: e.projectName, hours: 0, cost: 0, workers: new Set() };
      byProject[e.projectId].hours += e.hours || 0;
      byProject[e.projectId].cost += e.totalCost || 0;
      byProject[e.projectId].workers.add(e.employeeName);
    }
    const byEmployee: Record<string, { hours: number; cost: number; entries: number }> = {};
    for (const e of completed) {
      if (!byEmployee[e.employeeName]) byEmployee[e.employeeName] = { hours: 0, cost: 0, entries: 0 };
      byEmployee[e.employeeName].hours += e.hours || 0;
      byEmployee[e.employeeName].cost += e.totalCost || 0;
      byEmployee[e.employeeName].entries++;
    }
    return NextResponse.json({
      totalHours: completed.reduce((s, e) => s + (e.hours || 0), 0),
      totalCost: completed.reduce((s, e) => s + (e.totalCost || 0), 0),
      activeWorkers: entries.filter(e => e.status === 'active').length,
      byProject: Object.entries(byProject).map(([id, v]) => ({ projectId: id, name: v.name, hours: v.hours, cost: v.cost, workers: v.workers.size })),
      byEmployee: Object.entries(byEmployee).map(([name, v]) => ({ name, ...v })),
    });
  }

  return NextResponse.json({ entries });
}

export async function POST(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const body = await request.json();

  switch (body.action) {
    case 'clock-in': {
      const entry = {
        id: 'lb-' + Date.now(), employeeName: body.employeeName, employeeEmail: body.employeeEmail || '',
        projectId: body.projectId, projectName: body.projectName || '', task: body.task || '',
        clockIn: new Date().toISOString(), clockOut: null, hours: null,
        hourlyRate: body.hourlyRate || 30, totalCost: null, status: 'active',
      };
      entries.push(entry);
      return NextResponse.json({ entry });
    }
    case 'clock-out': {
      const idx = entries.findIndex(e => e.id === body.entryId);
      if (idx === -1) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      const clockOut = new Date();
      const clockIn = new Date(entries[idx].clockIn);
      const hours = Math.round((clockOut.getTime() - clockIn.getTime()) / 3600000 * 100) / 100;
      entries[idx].clockOut = clockOut.toISOString();
      entries[idx].hours = hours;
      entries[idx].totalCost = Math.round(hours * entries[idx].hourlyRate * 100) / 100;
      entries[idx].status = 'completed';
      return NextResponse.json({ entry: entries[idx] });
    }
    case 'approve': {
      const idx = entries.findIndex(e => e.id === body.entryId);
      if (idx === -1) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      entries[idx].status = 'approved';
      return NextResponse.json({ entry: entries[idx] });
    }
    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
