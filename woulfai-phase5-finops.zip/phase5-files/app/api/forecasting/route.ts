import { NextRequest, NextResponse } from 'next/server';

const ADMINS = ['steve@woulfgroup.com', 'stevemacurdy@gmail.com', 'admin'];
function isAuth(req: NextRequest) { const e = req.headers.get('x-admin-email'); return e && ADMINS.includes(e.toLowerCase()); }

// ====== FORECASTING ENGINE ======
function generateForecast(period: string, inputs: any) {
  const monthlyRevenue = inputs.monthlyRevenue || 85000;
  const monthlyExpenses = inputs.monthlyExpenses || 72000;
  const monthlyDebtService = inputs.monthlyDebtService || 37630;
  const cashOnHand = inputs.cashOnHand || 48000;
  const arOutstanding = inputs.arOutstanding || 38995;
  const apOutstanding = inputs.apOutstanding || 15800;
  const growthRate = inputs.growthRate || 0.03; // 3% monthly

  const months = period === '30day' ? 1 : period === '60day' ? 2 : period === '90day' ? 3 : period === '12month' ? 12 : 24;
  const projections = [];
  let runningCash = cashOnHand;
  let runningAR = arOutstanding;
  let rev = monthlyRevenue;

  for (let m = 1; m <= months; m++) {
    rev = rev * (1 + growthRate);
    const arCollection = runningAR * 0.85; // 85% collection rate
    const newAR = rev * 0.3; // 30% of revenue goes to AR
    const cashIn = rev * 0.7 + arCollection;
    const cashOut = monthlyExpenses + monthlyDebtService;
    const netCash = cashIn - cashOut;

    runningCash += netCash;
    runningAR = runningAR - arCollection + newAR;

    projections.push({
      month: m,
      label: new Date(Date.now() + m * 30.44 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
      revenue: Math.round(rev),
      expenses: Math.round(monthlyExpenses),
      debtService: Math.round(monthlyDebtService),
      cashIn: Math.round(cashIn),
      cashOut: Math.round(cashOut),
      netCash: Math.round(netCash),
      endingCash: Math.round(runningCash),
      arBalance: Math.round(runningAR),
      burnRate: Math.round(cashOut),
      runwayMonths: runningCash > 0 ? Math.round(runningCash / cashOut * 10) / 10 : 0,
    });
  }

  const alerts = [];
  const negativeCash = projections.find(p => p.endingCash < 0);
  if (negativeCash) alerts.push({ severity: 'critical', message: `Cash negative in month ${negativeCash.month} (${negativeCash.label})`, month: negativeCash.month });
  const lowCash = projections.find(p => p.endingCash < monthlyExpenses);
  if (lowCash && !negativeCash) alerts.push({ severity: 'warning', message: `Cash drops below 1 month expenses in ${lowCash.label}`, month: lowCash.month });
  if (runningCash > cashOnHand * 2) alerts.push({ severity: 'positive', message: `Cash doubles by month ${months}`, month: months });

  return {
    period, months, inputs: { monthlyRevenue, monthlyExpenses, monthlyDebtService, cashOnHand, arOutstanding, apOutstanding, growthRate },
    projections, alerts,
    summary: {
      endingCash: Math.round(runningCash),
      totalRevenue: Math.round(projections.reduce((s, p) => s + p.revenue, 0)),
      totalExpenses: Math.round(projections.reduce((s, p) => s + p.expenses + p.debtService, 0)),
      avgMonthlyNet: Math.round(projections.reduce((s, p) => s + p.netCash, 0) / months),
      minCash: Math.round(Math.min(...projections.map(p => p.endingCash))),
      maxCash: Math.round(Math.max(...projections.map(p => p.endingCash))),
    },
  };
}

// ====== BUSINESS IDEAS ======
let ideas: any[] = [
  {
    id: 'idea-1', title: '3PL Customer Portal SaaS', description: 'White-label inventory management portal for 3PL warehouse customers. Charge $500-2,000/mo per client.',
    initialInvestment: 25000, monthlyRevenueEstimate: 8000, monthlyCostEstimate: 2000, timeToProfit: 5, riskLevel: 'medium',
    aiAnalysis: {
      viabilityScore: 82, roiMonths: 5, annualProfit: 72000,
      strengths: ['Leverages existing warehouse expertise', 'Recurring SaaS revenue', 'Low marginal cost per client'],
      weaknesses: ['Competitive market', 'Requires ongoing development', 'Support overhead'],
      verdict: 'Highly viable — strong fit with core competency. $25K investment recovers in ~5 months with 10+ clients.',
    },
    status: 'viable',
  },
  {
    id: 'idea-2', title: 'Equipment Rental Division', description: 'Rent idle warehouse equipment (forklifts, pallet jacks, conveyors) to other warehouses on short-term contracts.',
    initialInvestment: 5000, monthlyRevenueEstimate: 4000, monthlyCostEstimate: 1500, timeToProfit: 2, riskLevel: 'low',
    aiAnalysis: {
      viabilityScore: 75, roiMonths: 2, annualProfit: 30000,
      strengths: ['Monetizes idle assets', 'Low startup cost', 'Insurance deductible'],
      weaknesses: ['Equipment wear and tear', 'Liability exposure', 'Logistics of delivery'],
      verdict: 'Viable with caveats — ensure insurance covers rental use. Start with 2-3 pieces as pilot.',
    },
    status: 'viable',
  },
];

async function analyzeIdea(idea: any, financialContext: any): Promise<any> {
  const OPENAI_KEY = process.env.OPENAI_API_KEY;
  const monthlyProfit = idea.monthlyRevenueEstimate - idea.monthlyCostEstimate;
  const roiMonths = monthlyProfit > 0 ? Math.ceil(idea.initialInvestment / monthlyProfit) : 999;
  const annualProfit = monthlyProfit * 12;
  const canAfford = financialContext.cashOnHand > idea.initialInvestment * 1.5;

  if (!OPENAI_KEY) {
    return {
      viabilityScore: monthlyProfit > 3000 ? 80 : monthlyProfit > 1000 ? 60 : 30,
      roiMonths, annualProfit,
      strengths: [canAfford ? 'Affordable with current cash position' : 'May stretch cash reserves', 'Diversifies revenue streams'],
      weaknesses: [!canAfford ? 'Requires external funding' : 'Opportunity cost of capital', 'Execution risk'],
      cashImpact: `Initial $${idea.initialInvestment.toLocaleString()} investment. Monthly net: $${monthlyProfit.toLocaleString()}. Cash positive in ${roiMonths} months.`,
      verdict: monthlyProfit > 3000 ? 'Viable — strong ROI potential' : monthlyProfit > 0 ? 'Marginal — proceed with caution' : 'Not viable at current projections',
    };
  }

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: `Analyze this business idea's viability. Current cash: $${financialContext.cashOnHand}. Monthly revenue: $${financialContext.monthlyRevenue}. Monthly expenses: $${financialContext.monthlyExpenses}. Debt service: $${financialContext.monthlyDebtService}/mo.

Idea: "${idea.title}" — ${idea.description}
Investment: $${idea.initialInvestment}. Projected monthly revenue: $${idea.monthlyRevenueEstimate}. Monthly cost: $${idea.monthlyCostEstimate}.

Return ONLY JSON: {"viabilityScore":0-100,"roiMonths":N,"annualProfit":N,"strengths":["..."],"weaknesses":["..."],"cashImpact":"...","verdict":"..."}` }],
        temperature: 0.5, max_tokens: 500,
      }),
    });
    const data = await res.json();
    return JSON.parse(data.choices?.[0]?.message?.content?.replace(/```json|```/g, '').trim());
  } catch {
    return { viabilityScore: 50, roiMonths, annualProfit, strengths: ['Analysis unavailable'], weaknesses: ['Analysis unavailable'], verdict: 'Manual review needed' };
  }
}

export async function GET(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const { searchParams } = new URL(request.url);
  const view = searchParams.get('view');

  if (view === 'forecast') {
    const period = searchParams.get('period') || '90day';
    const forecast = generateForecast(period, {
      monthlyRevenue: 85000, monthlyExpenses: 72000, monthlyDebtService: 37630,
      cashOnHand: 48000, arOutstanding: 38995, apOutstanding: 15800, growthRate: 0.03,
    });
    return NextResponse.json(forecast);
  }

  if (view === 'ideas') return NextResponse.json({ ideas });

  return NextResponse.json({ ideas, forecastPeriods: ['30day', '60day', '90day', '12month', '24month'] });
}

export async function POST(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const body = await request.json();

  switch (body.action) {
    case 'forecast': {
      const forecast = generateForecast(body.period || '90day', body.inputs || {});
      return NextResponse.json(forecast);
    }
    case 'create-idea': {
      const idea = { id: 'idea-' + Date.now(), ...body.data, status: 'draft', aiAnalysis: {} };
      ideas.push(idea);
      return NextResponse.json({ idea });
    }
    case 'analyze-idea': {
      const idx = ideas.findIndex(i => i.id === body.ideaId);
      if (idx === -1) return NextResponse.json({ error: 'Not found' }, { status: 404 });
      ideas[idx].status = 'analyzing';
      const analysis = await analyzeIdea(ideas[idx], {
        cashOnHand: 48000, monthlyRevenue: 85000, monthlyExpenses: 72000, monthlyDebtService: 37630,
      });
      ideas[idx].aiAnalysis = analysis;
      ideas[idx].status = analysis.viabilityScore >= 60 ? 'viable' : 'not_viable';
      return NextResponse.json({ idea: ideas[idx] });
    }
    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
