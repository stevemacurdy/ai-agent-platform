import { NextRequest, NextResponse } from 'next/server';

const ADMINS = ['steve@woulfgroup.com', 'stevemacurdy@gmail.com', 'admin'];
function isAuth(req: NextRequest) { const e = req.headers.get('x-admin-email'); return e && ADMINS.includes(e.toLowerCase()); }

// ====== EQUIPMENT LEDGER ======
let equipment: any[] = [
  { id: 'eq-1', name: 'CAT GP25N Forklift', description: '5,000 lb capacity propane forklift', serialNumber: 'AT83F40534', purchaseDate: '2023-06-15', purchasePrice: 32000, currentValue: 24000, depreciationMethod: 'straight_line', usefulLifeYears: 7, salvageValue: 5000, location: 'Warehouse A', assignedProject: 'proj-1', status: 'active' },
  { id: 'eq-2', name: 'Crown RR 5200 Reach Truck', description: 'Electric reach truck — 4,500 lb', serialNumber: 'CR5200-8841', purchaseDate: '2024-01-10', purchasePrice: 45000, currentValue: 38000, depreciationMethod: 'straight_line', usefulLifeYears: 10, salvageValue: 8000, location: 'Warehouse B', assignedProject: null, status: 'active' },
  { id: 'eq-3', name: '2022 Ford F-350 Service Truck', description: 'Crew cab — field operations', serialNumber: '1FT8W3BT2NED12345', purchaseDate: '2022-03-20', purchasePrice: 62000, currentValue: 44000, depreciationMethod: 'declining_balance', usefulLifeYears: 6, salvageValue: 15000, location: 'Field', assignedProject: null, status: 'active' },
  { id: 'eq-4', name: 'Dematic Conveyor System', description: '200ft powered conveyor — installed at Logicorp', serialNumber: 'DEM-CV-2025-001', purchaseDate: '2025-08-01', purchasePrice: 185000, currentValue: 168000, depreciationMethod: 'straight_line', usefulLifeYears: 15, salvageValue: 25000, location: 'Logicorp Warehouse', assignedProject: 'proj-1', status: 'active' },
  { id: 'eq-5', name: 'Raymond 8210 Pallet Jack', description: 'Electric pallet jack — 6,000 lb', serialNumber: 'RAY-8210-4421', purchaseDate: '2024-09-01', purchasePrice: 8500, currentValue: 7200, depreciationMethod: 'straight_line', usefulLifeYears: 5, salvageValue: 1500, location: 'Warehouse A', assignedProject: null, status: 'maintenance' },
];

// ====== LOANS ======
let loans: any[] = [
  { id: 'loan-1', lender: 'First National Bank', loanType: 'mortgage', originalAmount: 1500000, currentBalance: 1320000, interestRate: 7.25, monthlyPayment: 30000, originationDate: '2020-01-15', maturityDate: '2035-01-15', collateral: '500 Commerce Drive — Main HQ', status: 'active', contractUrl: '', ocrTerms: {}, aiRecommendations: {} },
  { id: 'loan-2', lender: 'CAT Financial', loanType: 'equipment', originalAmount: 32000, currentBalance: 18500, interestRate: 5.9, monthlyPayment: 680, originationDate: '2023-06-15', maturityDate: '2028-06-15', collateral: 'CAT GP25N Forklift', status: 'active', contractUrl: '', ocrTerms: {}, aiRecommendations: {} },
  { id: 'loan-3', lender: 'SBA - Chase Bank', loanType: 'sba', originalAmount: 250000, currentBalance: 195000, interestRate: 6.5, monthlyPayment: 4800, originationDate: '2022-03-01', maturityDate: '2032-03-01', collateral: 'Business assets', status: 'active', contractUrl: '', ocrTerms: {}, aiRecommendations: {} },
  { id: 'loan-4', lender: 'Ford Motor Credit', loanType: 'vehicle', originalAmount: 55000, currentBalance: 28000, interestRate: 4.9, monthlyPayment: 950, originationDate: '2022-03-20', maturityDate: '2027-03-20', collateral: '2022 Ford F-350', status: 'active', contractUrl: '', ocrTerms: {}, aiRecommendations: {} },
  { id: 'loan-5', lender: 'Regional Credit Union', loanType: 'line_of_credit', originalAmount: 100000, currentBalance: 42000, interestRate: 8.75, monthlyPayment: 1200, originationDate: '2024-06-01', maturityDate: '2026-06-01', collateral: 'Unsecured', status: 'active', contractUrl: '', ocrTerms: {}, aiRecommendations: {} },
];

// AI loan analysis
async function analyzeLoan(loan: any): Promise<any> {
  const OPENAI_KEY = process.env.OPENAI_API_KEY;
  const monthsRemaining = Math.max(1, Math.ceil((new Date(loan.maturityDate).getTime() - Date.now()) / (30.44 * 24 * 60 * 60 * 1000)));
  const totalRemainingPayments = monthsRemaining * loan.monthlyPayment;
  const totalInterestRemaining = totalRemainingPayments - loan.currentBalance;
  const payoffWithExtra = (extra: number) => {
    let bal = loan.currentBalance;
    let months = 0;
    const r = loan.interestRate / 100 / 12;
    while (bal > 0 && months < 600) {
      bal = bal * (1 + r) - loan.monthlyPayment - extra;
      months++;
    }
    return months;
  };

  const strategies = [
    { strategy: 'Minimum Payments', monthsToPayoff: monthsRemaining, totalInterest: totalInterestRemaining, monthlyCost: loan.monthlyPayment },
    { strategy: 'Extra $500/mo', monthsToPayoff: payoffWithExtra(500), totalInterest: Math.max(0, totalInterestRemaining * 0.7), monthlyCost: loan.monthlyPayment + 500 },
    { strategy: 'Extra $1,000/mo', monthsToPayoff: payoffWithExtra(1000), totalInterest: Math.max(0, totalInterestRemaining * 0.5), monthlyCost: loan.monthlyPayment + 1000 },
    { strategy: 'Double Payments', monthsToPayoff: payoffWithExtra(loan.monthlyPayment), totalInterest: Math.max(0, totalInterestRemaining * 0.35), monthlyCost: loan.monthlyPayment * 2 },
  ];

  const cashCrunchOptions = [
    { option: 'Request 90-day deferment', impact: 'Adds ~$' + Math.round(loan.currentBalance * (loan.interestRate/100/12) * 3).toLocaleString() + ' in accrued interest', risk: 'low' },
    { option: 'Interest-only payments for 6 months', impact: 'Pay $' + Math.round(loan.currentBalance * (loan.interestRate/100/12)).toLocaleString() + '/mo temporarily', risk: 'low' },
    { option: 'Request loan modification', impact: 'Extend term to reduce monthly by 20-30%', risk: 'medium' },
  ];

  const refinanceTarget = loan.interestRate > 6 ? {
    recommended: true,
    currentRate: loan.interestRate,
    targetRate: Math.max(4.5, loan.interestRate - 2.5),
    potentialMonthlySavings: Math.round(loan.monthlyPayment * 0.25),
    searchTerms: loan.loanType === 'mortgage' ? 'commercial mortgage refinance' : loan.loanType === 'sba' ? 'SBA loan refinance' : 'equipment financing refinance',
  } : { recommended: false, reason: 'Current rate is competitive' };

  return { strategies, cashCrunchOptions, refinanceTarget, monthsRemaining, totalInterestRemaining: Math.round(totalInterestRemaining) };
}

// Credit score mock (would integrate with Experian/D&B API)
const creditData = {
  business: { score: 78, provider: 'Dun & Bradstreet PAYDEX', lastUpdated: '2026-02-01', trend: 'stable', factors: ['Payment history strong', 'Credit utilization at 42%', 'Trade references: 12'] },
  personal: { score: 742, provider: 'FICO (via Experian)', lastUpdated: '2026-02-10', trend: 'improving', factors: ['0 late payments', 'Credit age: 14 years', 'Utilization: 18%'] },
};

export async function GET(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const { searchParams } = new URL(request.url);
  const view = searchParams.get('view');

  if (view === 'equipment') {
    const totalValue = equipment.filter(e => e.status === 'active').reduce((s, e) => s + e.currentValue, 0);
    const totalPurchase = equipment.reduce((s, e) => s + e.purchasePrice, 0);
    return NextResponse.json({ equipment, totalCurrentValue: totalValue, totalPurchasePrice: totalPurchase, totalDepreciation: totalPurchase - totalValue });
  }

  if (view === 'loans') {
    const totalDebt = loans.filter(l => l.status === 'active').reduce((s, l) => s + l.currentBalance, 0);
    const totalMonthlyPayments = loans.filter(l => l.status === 'active').reduce((s, l) => s + l.monthlyPayment, 0);
    const highestRate = loans.reduce((max, l) => l.interestRate > max.interestRate ? l : max, loans[0]);
    return NextResponse.json({ loans, totalDebt, totalMonthlyPayments, annualDebtService: totalMonthlyPayments * 12, highestRateLoan: highestRate });
  }

  if (view === 'loan-analysis') {
    const loanId = searchParams.get('loanId');
    const loan = loans.find(l => l.id === loanId);
    if (!loan) return NextResponse.json({ error: 'Loan not found' }, { status: 404 });
    const analysis = await analyzeLoan(loan);
    return NextResponse.json({ loan, analysis });
  }

  if (view === 'credit') return NextResponse.json({ credit: creditData });

  if (view === 'summary') {
    const totalDebt = loans.filter(l => l.status === 'active').reduce((s, l) => s + l.currentBalance, 0);
    const totalEquipment = equipment.filter(e => e.status === 'active').reduce((s, e) => s + e.currentValue, 0);
    return NextResponse.json({ totalDebt, totalEquipment, netAssetPosition: totalEquipment - totalDebt, credit: creditData });
  }

  return NextResponse.json({ equipment, loans, credit: creditData });
}

export async function POST(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const body = await request.json();

  switch (body.action) {
    case 'add-equipment': {
      const eq = { id: 'eq-' + Date.now(), ...body.data, status: 'active' };
      equipment.push(eq);
      return NextResponse.json({ equipment: eq });
    }
    case 'add-loan': {
      const ln = { id: 'loan-' + Date.now(), ...body.data, status: 'active', ocrTerms: {}, aiRecommendations: {} };
      loans.push(ln);
      return NextResponse.json({ loan: ln });
    }
    case 'analyze-all-loans': {
      const analyses = [];
      for (const loan of loans.filter(l => l.status === 'active')) {
        const a = await analyzeLoan(loan);
        analyses.push({ loan, analysis: a });
      }
      // Debt avalanche recommendation (highest rate first)
      const sorted = [...loans.filter(l => l.status === 'active')].sort((a, b) => b.interestRate - a.interestRate);
      return NextResponse.json({ analyses, avalancheOrder: sorted.map(l => ({ id: l.id, lender: l.lender, rate: l.interestRate, balance: l.currentBalance })) });
    }
    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
