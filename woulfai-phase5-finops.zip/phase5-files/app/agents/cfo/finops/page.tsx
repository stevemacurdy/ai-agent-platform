'use client'

import { useState, useEffect, useRef } from 'react'

function getEmail() { try { return JSON.parse(localStorage.getItem('woulfai_session') || '{}')?.user?.email || 'admin' } catch { return 'admin' } }
const hdrs = () => ({ 'x-admin-email': getEmail(), 'Content-Type': 'application/json' })

export default function FinOpsPage() {
  const [tab, setTab] = useState<'ap' | 'debt' | 'labor' | 'forecast' | 'sandbox'>('ap')
  const [basis, setBasis] = useState<'accrual' | 'cash'>('accrual')
  const [odooFilter, setOdooFilter] = useState('all')
  const [toast, setToast] = useState<string | null>(null)
  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(null), 3000) }

  // ====== AP STATE ======
  const [apSummary, setApSummary] = useState<any>(null)
  const [apExpenses, setApExpenses] = useState<any[]>([])
  const [projects, setProjects] = useState<any[]>([])
  const [showAddAP, setShowAddAP] = useState(false)
  const [apForm, setApForm] = useState({ vendorName: '', amount: '', category: '', description: '', allocationType: 'overhead', projectId: '', odooAccount: 'woulf', invoiceDate: '' })

  // ====== DEBT STATE ======
  const [equipment, setEquipment] = useState<any[]>([])
  const [loans, setLoans] = useState<any[]>([])
  const [credit, setCredit] = useState<any>(null)
  const [loanAnalysis, setLoanAnalysis] = useState<any>(null)
  const [analyzingLoan, setAnalyzingLoan] = useState<string | null>(null)

  // ====== LABOR STATE ======
  const [laborEntries, setLaborEntries] = useState<any[]>([])
  const [laborSummary, setLaborSummary] = useState<any>(null)

  // ====== FORECAST STATE ======
  const [forecastPeriod, setForecastPeriod] = useState('90day')
  const [forecast, setForecast] = useState<any>(null)
  const [forecastLoading, setForecastLoading] = useState(false)

  // ====== SANDBOX STATE ======
  const [ideas, setIdeas] = useState<any[]>([])
  const [showAddIdea, setShowAddIdea] = useState(false)
  const [ideaForm, setIdeaForm] = useState({ title: '', description: '', initialInvestment: '', monthlyRevenueEstimate: '', monthlyCostEstimate: '' })

  // Loaders
  const loadAP = async () => {
    const [sumRes, allRes, projRes] = await Promise.all([
      fetch(`/api/ap?view=summary&basis=${basis}&odoo=${odooFilter}`, { headers: { 'x-admin-email': getEmail() } }),
      fetch(`/api/ap?odoo=${odooFilter}`, { headers: { 'x-admin-email': getEmail() } }),
      fetch('/api/ap?view=projects', { headers: { 'x-admin-email': getEmail() } }),
    ])
    setApSummary(await sumRes.json())
    const allData = await allRes.json()
    setApExpenses(allData.expenses || [])
    setProjects((await projRes.json()).projects || [])
  }
  const loadDebt = async () => {
    const [eqRes, lnRes, crRes] = await Promise.all([
      fetch('/api/debt?view=equipment', { headers: { 'x-admin-email': getEmail() } }),
      fetch('/api/debt?view=loans', { headers: { 'x-admin-email': getEmail() } }),
      fetch('/api/debt?view=credit', { headers: { 'x-admin-email': getEmail() } }),
    ])
    const eqData = await eqRes.json(); setEquipment(eqData.equipment || [])
    const lnData = await lnRes.json(); setLoans(lnData.loans || [])
    setCredit((await crRes.json()).credit)
  }
  const loadLabor = async () => {
    const [allRes, sumRes] = await Promise.all([
      fetch('/api/labor', { headers: { 'x-admin-email': getEmail() } }),
      fetch('/api/labor?view=summary', { headers: { 'x-admin-email': getEmail() } }),
    ])
    setLaborEntries((await allRes.json()).entries || [])
    setLaborSummary(await sumRes.json())
  }
  const loadForecast = async (period?: string) => {
    setForecastLoading(true)
    const p = period || forecastPeriod
    const res = await fetch(`/api/forecasting?view=forecast&period=${p}`, { headers: { 'x-admin-email': getEmail() } })
    setForecast(await res.json())
    setForecastLoading(false)
  }
  const loadIdeas = async () => {
    const res = await fetch('/api/forecasting?view=ideas', { headers: { 'x-admin-email': getEmail() } })
    setIdeas((await res.json()).ideas || [])
  }

  useEffect(() => { loadAP() }, [basis, odooFilter])
  useEffect(() => { if (tab === 'debt') loadDebt(); if (tab === 'labor') loadLabor(); if (tab === 'forecast') loadForecast(); if (tab === 'sandbox') loadIdeas() }, [tab])

  const createAP = async () => {
    await fetch('/api/ap', { method: 'POST', headers: hdrs(), body: JSON.stringify({ action: 'create', ...apForm, amount: parseFloat(apForm.amount) }) })
    showToast('Expense created'); setShowAddAP(false); loadAP()
  }

  const analyzeLoan = async (loanId: string) => {
    setAnalyzingLoan(loanId)
    const res = await fetch(`/api/debt?view=loan-analysis&loanId=${loanId}`, { headers: { 'x-admin-email': getEmail() } })
    setLoanAnalysis(await res.json())
    setAnalyzingLoan(null)
  }

  const createIdea = async () => {
    await fetch('/api/forecasting', { method: 'POST', headers: hdrs(), body: JSON.stringify({ action: 'create-idea', data: { ...ideaForm, initialInvestment: parseFloat(ideaForm.initialInvestment), monthlyRevenueEstimate: parseFloat(ideaForm.monthlyRevenueEstimate), monthlyCostEstimate: parseFloat(ideaForm.monthlyCostEstimate) } }) })
    showToast('Idea added'); setShowAddIdea(false); loadIdeas()
  }

  const analyzeIdea = async (id: string) => {
    await fetch('/api/forecasting', { method: 'POST', headers: hdrs(), body: JSON.stringify({ action: 'analyze-idea', ideaId: id }) })
    showToast('Analysis complete'); loadIdeas()
  }

  const CAT_COLORS: Record<string, string> = { advertising: 'text-pink-400', wages: 'text-blue-400', utilities: 'text-yellow-400', insurance: 'text-violet-400', travel_meals: 'text-amber-400', supplies: 'text-emerald-400', rent_lease_machinery: 'text-cyan-400', legal_professional: 'text-rose-400', rent_lease_property: 'text-indigo-400', office_expense: 'text-gray-400' }

  const tabs = [
    { key: 'ap', label: 'Accounts Payable', icon: '\uD83D\uDCB3' },
    { key: 'debt', label: 'Debt & Assets', icon: '\uD83C\uDFE6' },
    { key: 'labor', label: 'Labor Tracking', icon: '\u23F1\uFE0F' },
    { key: 'forecast', label: 'Forecasting', icon: '\uD83D\uDCC8' },
    { key: 'sandbox', label: 'Idea Sandbox', icon: '\uD83D\uDCA1' },
  ]

  return (
    <div className="max-w-[1200px] mx-auto space-y-5">
      {toast && <div className="fixed top-4 right-4 z-50 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm px-4 py-2 rounded-lg">{toast}</div>}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">CFO FinOps Suite</h1>
          <p className="text-sm text-gray-500 mt-1">Financial operations, debt management, and predictive analytics</p>
        </div>
        <div className="flex gap-2 items-center">
          <span className="text-[10px] text-gray-500 font-mono">ACCOUNTING:</span>
          <button onClick={() => setBasis('accrual')} className={'px-3 py-1 rounded-lg text-xs font-medium ' + (basis === 'accrual' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'text-gray-500 bg-white/5')}> Accrual</button>
          <button onClick={() => setBasis('cash')} className={'px-3 py-1 rounded-lg text-xs font-medium ' + (basis === 'cash' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'text-gray-500 bg-white/5')}>Cash</button>
          <span className="text-gray-700 mx-1">|</span>
          <select value={odooFilter} onChange={e => setOdooFilter(e.target.value)} className="px-2 py-1 bg-white/5 border border-white/10 rounded-lg text-xs text-gray-400">
            <option value="all">All Accounts</option>
            <option value="woulf">Woulf</option>
            <option value="clutch">Clutch</option>
          </select>
        </div>
      </div>

      {/* TABS */}
      <div className="flex gap-1 overflow-x-auto">
        {tabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key as any)}
            className={'px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ' +
              (tab === t.key ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5')}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* ================================================================ */}
      {/* ACCOUNTS PAYABLE TAB */}
      {/* ================================================================ */}
      {tab === 'ap' && apSummary && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: `Total AP (${basis})`, value: apSummary.totalAP, color: 'text-white' },
              { label: 'Pending Approval', value: apSummary.pendingTotal, color: 'text-amber-400' },
              { label: 'Project Costs', value: apSummary.projectTotal, color: 'text-violet-400' },
              { label: 'Overhead', value: apSummary.overheadTotal, color: 'text-gray-400' },
            ].map((kpi, i) => (
              <div key={i} className="bg-[#0A0E15] border border-white/5 rounded-xl p-4">
                <div className="text-[10px] text-gray-500 font-mono uppercase">{kpi.label}</div>
                <div className={`text-xl font-mono font-bold mt-1 ${kpi.color}`}>${kpi.value?.toLocaleString()}</div>
              </div>
            ))}
          </div>

          {odooFilter === 'all' && (
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#0A0E15] border border-blue-500/10 rounded-xl p-3 flex items-center justify-between">
                <span className="text-xs text-gray-400">Woulf Account</span>
                <span className="font-mono font-bold text-blue-400">${apSummary.woulfTotal?.toLocaleString()}</span>
              </div>
              <div className="bg-[#0A0E15] border border-violet-500/10 rounded-xl p-3 flex items-center justify-between">
                <span className="text-xs text-gray-400">Clutch Account</span>
                <span className="font-mono font-bold text-violet-400">${apSummary.clutchTotal?.toLocaleString()}</span>
              </div>
            </div>
          )}

          {/* Category Breakdown */}
          <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">Spend by Category</h3>
              <button onClick={() => setShowAddAP(!showAddAP)} className="px-3 py-1.5 bg-blue-500 text-white rounded-lg text-xs">+ Add Expense</button>
            </div>
            <div className="space-y-2">
              {apSummary.byCategory?.map((c: any) => (
                <div key={c.category} className="flex items-center justify-between py-1.5">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: 'currentColor' }} />
                    <span className={'text-sm ' + (CAT_COLORS[c.category] || 'text-gray-400')}>{c.label}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-32 h-1.5 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500/50 rounded-full" style={{ width: Math.min(100, c.amount / (apSummary.totalAP || 1) * 100) + '%' }} />
                    </div>
                    <span className="text-sm font-mono font-bold w-24 text-right">${c.amount?.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {showAddAP && (
            <div className="bg-[#0A0E15] border border-blue-500/20 rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-semibold">New Expense</h3>
              <div className="grid grid-cols-2 gap-3">
                <input value={apForm.vendorName} onChange={e => setApForm({...apForm, vendorName: e.target.value})} placeholder="Vendor" className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" />
                <input value={apForm.amount} onChange={e => setApForm({...apForm, amount: e.target.value})} placeholder="Amount" type="number" className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <select value={apForm.category} onChange={e => setApForm({...apForm, category: e.target.value})} className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm">
                  <option value="">Select Category (Required)</option>
                  <option value="advertising">Advertising</option><option value="car_truck">Car/Truck</option>
                  <option value="commissions_fees">Commissions &amp; Fees</option><option value="contract_labor">Contract Labor</option>
                  <option value="employee_benefits">Employee Benefits</option><option value="insurance">Insurance</option>
                  <option value="interest_mortgage">Interest/Mortgage</option><option value="legal_professional">Legal/Professional</option>
                  <option value="office_expense">Office Expense</option><option value="profit_sharing">Profit Sharing</option>
                  <option value="rent_lease_vehicles">Rent/Lease (Vehicles)</option><option value="rent_lease_machinery">Rent/Lease (Machinery)</option>
                  <option value="rent_lease_property">Rent/Lease (Property)</option><option value="repairs_maintenance">Repairs &amp; Maintenance</option>
                  <option value="supplies">Supplies</option><option value="taxes_licenses">Taxes &amp; Licenses</option>
                  <option value="travel_meals">Travel &amp; Meals</option><option value="utilities">Utilities</option>
                  <option value="wages">Wages</option>
                </select>
                <input type="date" value={apForm.invoiceDate} onChange={e => setApForm({...apForm, invoiceDate: e.target.value})} className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <select value={apForm.allocationType} onChange={e => setApForm({...apForm, allocationType: e.target.value})} className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm">
                  <option value="overhead">General Overhead</option><option value="project">Project Cost</option>
                </select>
                {apForm.allocationType === 'project' && (
                  <select value={apForm.projectId} onChange={e => setApForm({...apForm, projectId: e.target.value})} className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm">
                    <option value="">Select Project</option>
                    {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                )}
                <select value={apForm.odooAccount} onChange={e => setApForm({...apForm, odooAccount: e.target.value})} className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm">
                  <option value="woulf">Woulf Account</option><option value="clutch">Clutch Account</option>
                </select>
              </div>
              <input value={apForm.description} onChange={e => setApForm({...apForm, description: e.target.value})} placeholder="Description" className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" />
              <button onClick={createAP} disabled={!apForm.vendorName || !apForm.amount || !apForm.category || !apForm.invoiceDate}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium disabled:opacity-40">Create Expense</button>
            </div>
          )}

          {/* Project P&Ls */}
          {apSummary.byProject?.length > 0 && (
            <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
              <h3 className="text-sm font-semibold mb-3">Project Cost Tracking</h3>
              {apSummary.byProject.map((p: any) => (
                <div key={p.projectId} className="flex items-center justify-between py-2 border-b border-white/[0.03] last:border-0">
                  <div><div className="text-sm">{p.name}</div><div className="text-[10px] text-gray-500">Budget: ${p.budget?.toLocaleString()}</div></div>
                  <div className="flex items-center gap-4">
                    <div className="w-24 h-1.5 bg-white/5 rounded-full overflow-hidden">
                      <div className={'h-full rounded-full ' + (p.utilization > 90 ? 'bg-rose-500' : p.utilization > 70 ? 'bg-amber-500' : 'bg-emerald-500')} style={{ width: Math.min(100, p.utilization) + '%' }} />
                    </div>
                    <span className="text-xs font-mono">{p.utilization}%</span>
                    <span className="text-sm font-mono font-bold">${p.total?.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Recent Expenses */}
          <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
            <h3 className="text-sm font-semibold mb-3">Recent Expenses</h3>
            <div className="space-y-2">
              {apExpenses.slice(0, 10).map((e: any) => (
                <div key={e.id} className="flex items-center justify-between py-2 border-b border-white/[0.03] last:border-0">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <span className={'text-[10px] font-mono px-1.5 py-0.5 rounded ' +
                      (e.status === 'paid' ? 'bg-emerald-500/10 text-emerald-400' : e.status === 'approved' ? 'bg-blue-500/10 text-blue-400' : 'bg-amber-500/10 text-amber-400')}>{e.status}</span>
                    <div className="min-w-0">
                      <div className="text-sm truncate">{e.vendorName}</div>
                      <div className="text-[10px] text-gray-500">{e.description}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <span className={'text-[10px] px-1.5 py-0.5 rounded ' + (e.odooAccount === 'clutch' ? 'bg-violet-500/10 text-violet-400' : 'bg-blue-500/10 text-blue-400')}>{e.odooAccount}</span>
                    <span className="text-sm font-mono font-bold">${e.amount?.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ================================================================ */}
      {/* DEBT & ASSETS TAB */}
      {/* ================================================================ */}
      {tab === 'debt' && (
        <div className="space-y-4">
          {/* Credit Scores */}
          {credit && (
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border border-blue-500/20 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[10px] text-gray-400 uppercase font-mono">Business Credit</div>
                  <span className={'text-[10px] px-1.5 py-0.5 rounded ' + (credit.business.trend === 'improving' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-gray-500/10 text-gray-400')}>{credit.business.trend}</span>
                </div>
                <div className="text-3xl font-bold text-blue-400">{credit.business.score}</div>
                <div className="text-[10px] text-gray-500 mt-1">{credit.business.provider}</div>
              </div>
              <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/20 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[10px] text-gray-400 uppercase font-mono">Personal Credit</div>
                  <span className={'text-[10px] px-1.5 py-0.5 rounded ' + (credit.personal.trend === 'improving' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-gray-500/10 text-gray-400')}>{credit.personal.trend}</span>
                </div>
                <div className="text-3xl font-bold text-emerald-400">{credit.personal.score}</div>
                <div className="text-[10px] text-gray-500 mt-1">{credit.personal.provider}</div>
              </div>
            </div>
          )}

          {/* Loans */}
          <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold">Active Loans &amp; Debt</h3>
              <div className="text-sm font-mono">Total: <span className="font-bold text-rose-400">${loans.filter(l => l.status === 'active').reduce((s: number, l: any) => s + l.currentBalance, 0).toLocaleString()}</span></div>
            </div>
            {loans.map((loan: any) => (
              <div key={loan.id} className="py-3 border-b border-white/[0.03] last:border-0">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium">{loan.lender}</div>
                    <div className="text-[10px] text-gray-500">{loan.loanType?.replace('_', ' ')} — {loan.collateral}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-mono font-bold">${loan.currentBalance?.toLocaleString()}</div>
                    <div className="text-[10px] text-gray-500">{loan.interestRate}% — ${loan.monthlyPayment?.toLocaleString()}/mo</div>
                  </div>
                </div>
                <div className="flex gap-2 mt-2">
                  <button onClick={() => analyzeLoan(loan.id)} disabled={analyzingLoan === loan.id}
                    className="px-3 py-1 bg-blue-500/10 text-blue-400 rounded text-xs hover:bg-blue-500/20 disabled:opacity-50">
                    {analyzingLoan === loan.id ? 'Analyzing...' : 'AI Pay-Down Analysis'}
                  </button>
                  {loan.interestRate > 6 && <span className="px-2 py-1 bg-amber-500/10 text-amber-400 rounded text-[10px]">Refinance Candidate</span>}
                </div>
              </div>
            ))}
          </div>

          {/* Loan Analysis Panel */}
          {loanAnalysis && (
            <div className="bg-[#0A0E15] border border-blue-500/20 rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold">Pay-Down Analysis: {loanAnalysis.loan?.lender}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {loanAnalysis.analysis?.strategies?.map((s: any, i: number) => (
                  <div key={i} className={'bg-white/[0.02] border rounded-lg p-3 ' + (i === 0 ? 'border-white/5' : i === 1 ? 'border-blue-500/20' : i === 2 ? 'border-emerald-500/20' : 'border-violet-500/20')}>
                    <div className="text-xs font-medium mb-2">{s.strategy}</div>
                    <div className="text-lg font-mono font-bold">{s.monthsToPayoff}mo</div>
                    <div className="text-[10px] text-gray-500">${s.monthlyCost?.toLocaleString()}/mo</div>
                  </div>
                ))}
              </div>
              {loanAnalysis.analysis?.cashCrunchOptions && (
                <div>
                  <h4 className="text-xs font-semibold text-amber-400 mb-2">Cash Crunch Options</h4>
                  {loanAnalysis.analysis.cashCrunchOptions.map((o: any, i: number) => (
                    <div key={i} className="flex items-center justify-between py-1.5 text-xs">
                      <span className="text-gray-300">{o.option}</span>
                      <span className="text-gray-500">{o.impact}</span>
                    </div>
                  ))}
                </div>
              )}
              {loanAnalysis.analysis?.refinanceTarget?.recommended && (
                <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-lg p-3">
                  <div className="text-xs font-semibold text-emerald-400 mb-1">Refinance Recommended</div>
                  <div className="text-xs text-gray-400">Target rate: {loanAnalysis.analysis.refinanceTarget.targetRate}% (currently {loanAnalysis.analysis.refinanceTarget.currentRate}%). Potential savings: ${loanAnalysis.analysis.refinanceTarget.potentialMonthlySavings?.toLocaleString()}/mo</div>
                </div>
              )}
            </div>
          )}

          {/* Equipment Ledger */}
          <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
            <h3 className="text-sm font-semibold mb-3">Equipment Ledger</h3>
            <div className="space-y-2">
              {equipment.map((eq: any) => (
                <div key={eq.id} className="flex items-center justify-between py-2 border-b border-white/[0.03] last:border-0">
                  <div>
                    <div className="text-sm">{eq.name}</div>
                    <div className="text-[10px] text-gray-500">{eq.location} — SN: {eq.serialNumber}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-bold">${eq.currentValue?.toLocaleString()}</div>
                    <div className="text-[10px] text-gray-500">Purchased: ${eq.purchasePrice?.toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ================================================================ */}
      {/* LABOR TRACKING TAB */}
      {/* ================================================================ */}
      {tab === 'labor' && (
        <div className="space-y-4">
          {laborSummary && (
            <div className="grid grid-cols-4 gap-3">
              <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-4">
                <div className="text-[10px] text-gray-500 font-mono uppercase">Total Hours</div>
                <div className="text-xl font-mono font-bold mt-1">{laborSummary.totalHours?.toFixed(1)}</div>
              </div>
              <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-4">
                <div className="text-[10px] text-gray-500 font-mono uppercase">Total Labor Cost</div>
                <div className="text-xl font-mono font-bold text-amber-400 mt-1">${laborSummary.totalCost?.toLocaleString()}</div>
              </div>
              <div className="bg-[#0A0E15] border border-emerald-500/20 rounded-xl p-4">
                <div className="text-[10px] text-gray-500 font-mono uppercase">Clocked In Now</div>
                <div className="text-xl font-mono font-bold text-emerald-400 mt-1">{laborSummary.activeWorkers}</div>
              </div>
              <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-4">
                <div className="text-[10px] text-gray-500 font-mono uppercase">Avg $/Hour</div>
                <div className="text-xl font-mono font-bold mt-1">${laborSummary.totalHours > 0 ? (laborSummary.totalCost / laborSummary.totalHours).toFixed(2) : '0'}</div>
              </div>
            </div>
          )}

          {/* By Project */}
          {laborSummary?.byProject?.length > 0 && (
            <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
              <h3 className="text-sm font-semibold mb-3">Labor by Project</h3>
              {laborSummary.byProject.map((p: any) => (
                <div key={p.projectId} className="flex items-center justify-between py-2 border-b border-white/[0.03] last:border-0">
                  <div><div className="text-sm">{p.name}</div><div className="text-[10px] text-gray-500">{p.workers} workers</div></div>
                  <div className="text-right">
                    <span className="text-sm font-mono">{p.hours?.toFixed(1)} hrs</span>
                    <span className="mx-2 text-gray-700">|</span>
                    <span className="text-sm font-mono font-bold">${p.cost?.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Active + Recent Entries */}
          <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
            <h3 className="text-sm font-semibold mb-3">Time Entries</h3>
            {laborEntries.map((e: any) => (
              <div key={e.id} className="flex items-center justify-between py-2 border-b border-white/[0.03] last:border-0">
                <div className="flex items-center gap-3">
                  <span className={'w-2 h-2 rounded-full ' + (e.status === 'active' ? 'bg-emerald-400 animate-pulse' : 'bg-gray-600')} />
                  <div>
                    <div className="text-sm">{e.employeeName}</div>
                    <div className="text-[10px] text-gray-500">{e.task} — {e.projectName}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-sm">{e.hours ? e.hours.toFixed(1) + ' hrs' : 'Active'}</div>
                  <div className="text-[10px] text-gray-500">{e.totalCost ? '$' + e.totalCost.toFixed(2) : '@$' + e.hourlyRate + '/hr'}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================================================================ */}
      {/* FORECASTING TAB */}
      {/* ================================================================ */}
      {tab === 'forecast' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            {['30day', '60day', '90day', '12month', '24month'].map(p => (
              <button key={p} onClick={() => { setForecastPeriod(p); loadForecast(p) }}
                className={'px-3 py-1.5 rounded-lg text-xs font-medium ' + (forecastPeriod === p ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'text-gray-500 bg-white/5 hover:text-white')}>
                {p.replace('day', ' Day').replace('month', ' Month')}
              </button>
            ))}
          </div>

          {forecastLoading ? (
            <div className="flex items-center justify-center py-10"><div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" /></div>
          ) : forecast && (
            <>
              {/* Alerts */}
              {forecast.alerts?.map((a: any, i: number) => (
                <div key={i} className={'border rounded-xl p-3 text-sm ' +
                  (a.severity === 'critical' ? 'bg-rose-500/5 border-rose-500/20 text-rose-400' :
                   a.severity === 'warning' ? 'bg-amber-500/5 border-amber-500/20 text-amber-400' : 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400')}>
                  {a.severity === 'critical' ? '\u26A0\uFE0F' : a.severity === 'warning' ? '\u26A1' : '\u2705'} {a.message}
                </div>
              ))}

              {/* Summary KPIs */}
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {[
                  { label: 'Ending Cash', value: forecast.summary?.endingCash, color: forecast.summary?.endingCash > 0 ? 'text-emerald-400' : 'text-rose-400' },
                  { label: 'Total Revenue', value: forecast.summary?.totalRevenue, color: 'text-blue-400' },
                  { label: 'Total Expenses', value: forecast.summary?.totalExpenses, color: 'text-amber-400' },
                  { label: 'Avg Monthly Net', value: forecast.summary?.avgMonthlyNet, color: forecast.summary?.avgMonthlyNet > 0 ? 'text-emerald-400' : 'text-rose-400' },
                  { label: 'Min Cash', value: forecast.summary?.minCash, color: 'text-gray-300' },
                  { label: 'Max Cash', value: forecast.summary?.maxCash, color: 'text-gray-300' },
                ].map((kpi, i) => (
                  <div key={i} className="bg-[#0A0E15] border border-white/5 rounded-xl p-3">
                    <div className="text-[9px] text-gray-500 font-mono uppercase">{kpi.label}</div>
                    <div className={`text-sm font-mono font-bold mt-1 ${kpi.color}`}>${kpi.value?.toLocaleString()}</div>
                  </div>
                ))}
              </div>

              {/* Monthly Projections Table */}
              <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5 overflow-x-auto">
                <h3 className="text-sm font-semibold mb-3">Monthly Projections</h3>
                <table className="w-full text-xs">
                  <thead><tr className="text-[9px] text-gray-500 uppercase border-b border-white/5">
                    <th className="text-left py-2">Month</th><th className="text-right py-2">Revenue</th>
                    <th className="text-right py-2">Expenses</th><th className="text-right py-2">Debt</th>
                    <th className="text-right py-2">Net</th><th className="text-right py-2">Cash</th>
                    <th className="text-right py-2">Runway</th>
                  </tr></thead>
                  <tbody>
                    {forecast.projections?.map((p: any) => (
                      <tr key={p.month} className="border-b border-white/[0.03]">
                        <td className="py-2 text-gray-300">{p.label}</td>
                        <td className="py-2 text-right font-mono text-blue-400">${p.revenue?.toLocaleString()}</td>
                        <td className="py-2 text-right font-mono">${p.expenses?.toLocaleString()}</td>
                        <td className="py-2 text-right font-mono text-rose-400">${p.debtService?.toLocaleString()}</td>
                        <td className={'py-2 text-right font-mono font-bold ' + (p.netCash >= 0 ? 'text-emerald-400' : 'text-rose-400')}>${p.netCash?.toLocaleString()}</td>
                        <td className={'py-2 text-right font-mono ' + (p.endingCash >= 0 ? '' : 'text-rose-400')}>${p.endingCash?.toLocaleString()}</td>
                        <td className="py-2 text-right font-mono text-gray-500">{p.runwayMonths}mo</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {/* ================================================================ */}
      {/* BUSINESS IDEA SANDBOX */}
      {/* ================================================================ */}
      {tab === 'sandbox' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold">Business Ideas</h3>
            <button onClick={() => setShowAddIdea(!showAddIdea)} className="px-3 py-1.5 bg-blue-500 text-white rounded-lg text-xs">+ New Idea</button>
          </div>

          {showAddIdea && (
            <div className="bg-[#0A0E15] border border-blue-500/20 rounded-xl p-5 space-y-3">
              <input value={ideaForm.title} onChange={e => setIdeaForm({...ideaForm, title: e.target.value})} placeholder="Business idea title" className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" />
              <textarea value={ideaForm.description} onChange={e => setIdeaForm({...ideaForm, description: e.target.value})} placeholder="Describe the idea, target market, revenue model..." rows={3} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm resize-none" />
              <div className="grid grid-cols-3 gap-3">
                <input value={ideaForm.initialInvestment} onChange={e => setIdeaForm({...ideaForm, initialInvestment: e.target.value})} placeholder="Initial Investment ($)" type="number" className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" />
                <input value={ideaForm.monthlyRevenueEstimate} onChange={e => setIdeaForm({...ideaForm, monthlyRevenueEstimate: e.target.value})} placeholder="Monthly Revenue ($)" type="number" className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" />
                <input value={ideaForm.monthlyCostEstimate} onChange={e => setIdeaForm({...ideaForm, monthlyCostEstimate: e.target.value})} placeholder="Monthly Cost ($)" type="number" className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" />
              </div>
              <button onClick={createIdea} disabled={!ideaForm.title} className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium disabled:opacity-40">Add Idea</button>
            </div>
          )}

          {ideas.map((idea: any) => (
            <div key={idea.id} className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-medium">{idea.title}</h4>
                  <p className="text-xs text-gray-500 mt-0.5">{idea.description}</p>
                </div>
                <div className="flex items-center gap-2">
                  {idea.aiAnalysis?.viabilityScore != null && (
                    <div className={'text-2xl font-bold ' + (idea.aiAnalysis.viabilityScore >= 70 ? 'text-emerald-400' : idea.aiAnalysis.viabilityScore >= 50 ? 'text-amber-400' : 'text-rose-400')}>
                      {idea.aiAnalysis.viabilityScore}
                    </div>
                  )}
                  <span className={'text-[10px] font-mono px-2 py-0.5 rounded ' + (idea.status === 'viable' ? 'bg-emerald-500/10 text-emerald-400' : idea.status === 'not_viable' ? 'bg-rose-500/10 text-rose-400' : 'bg-gray-500/10 text-gray-400')}>{idea.status}</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 mb-3">
                <div className="bg-white/[0.02] rounded-lg p-2 text-center"><div className="text-[9px] text-gray-500">Investment</div><div className="font-mono text-sm">${idea.initialInvestment?.toLocaleString()}</div></div>
                <div className="bg-white/[0.02] rounded-lg p-2 text-center"><div className="text-[9px] text-gray-500">Monthly Profit</div><div className="font-mono text-sm text-emerald-400">${((idea.monthlyRevenueEstimate || 0) - (idea.monthlyCostEstimate || 0)).toLocaleString()}</div></div>
                <div className="bg-white/[0.02] rounded-lg p-2 text-center"><div className="text-[9px] text-gray-500">ROI</div><div className="font-mono text-sm">{idea.aiAnalysis?.roiMonths || '?'} months</div></div>
              </div>

              {idea.aiAnalysis?.verdict && (
                <div className="bg-white/[0.02] border border-white/5 rounded-lg p-3 mb-3">
                  <div className="text-xs text-gray-300">{idea.aiAnalysis.verdict}</div>
                </div>
              )}

              {idea.aiAnalysis?.strengths && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-[10px] text-emerald-400 font-semibold mb-1">Strengths</div>
                    {idea.aiAnalysis.strengths.map((s: string, i: number) => <div key={i} className="text-[10px] text-gray-400 py-0.5">{'\u2713'} {s}</div>)}
                  </div>
                  <div>
                    <div className="text-[10px] text-rose-400 font-semibold mb-1">Weaknesses</div>
                    {idea.aiAnalysis.weaknesses?.map((w: string, i: number) => <div key={i} className="text-[10px] text-gray-400 py-0.5">{'\u2717'} {w}</div>)}
                  </div>
                </div>
              )}

              {idea.status === 'draft' && (
                <button onClick={() => analyzeIdea(idea.id)} className="mt-3 px-3 py-1.5 bg-blue-500/10 text-blue-400 rounded text-xs hover:bg-blue-500/20">Run AI Analysis</button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
