const fs = require('fs');
const path = require('path');

console.log('');
console.log('  ╔══════════════════════════════════════════════════════════╗');
console.log('  ║  WoulfAI Phase 5: CFO FinOps & Intelligence Suite       ║');
console.log('  ║  AP Engine, Debt/Assets, Labor, Forecasting, Sandbox    ║');
console.log('  ╚══════════════════════════════════════════════════════════╝');
console.log('');

const BASE = path.join(__dirname, 'phase5-files');
let installed = 0;
let patched = 0;

function install(src, dest) {
  try {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(path.join(BASE, src), dest);
    const lines = fs.readFileSync(dest, 'utf8').split('\n').length;
    console.log('  + ' + dest + ' (' + lines + ' lines)');
    installed++;
  } catch(e) {
    console.log('  ! ' + src + ': ' + e.message);
  }
}

console.log('API Routes:');
install('app/api/ap/route.ts', 'app/api/ap/route.ts');
install('app/api/debt/route.ts', 'app/api/debt/route.ts');
install('app/api/labor/route.ts', 'app/api/labor/route.ts');
install('app/api/forecasting/route.ts', 'app/api/forecasting/route.ts');
console.log('');

console.log('UI Pages:');
install('app/agents/cfo/finops/page.tsx', 'app/agents/cfo/finops/page.tsx');
console.log('');

console.log('Sidebar:');
try {
  let layout = fs.readFileSync('app/admin/layout.tsx', 'utf8');
  if (!layout.includes('finops')) {
    const targets = ["'integrations'", "'cfo-tools'", "'cfo-console'", "'debrief'"];
    let changed = false;
    for (const target of targets) {
      if (layout.includes(target)) {
        const pattern = new RegExp("(\\{[^}]*id:\\s*" + target + "[^}]*\\}),?");
        if (pattern.test(layout)) {
          layout = layout.replace(pattern, "$1,\n    { id: 'finops', label: 'FinOps Suite', href: '/agents/cfo/finops', icon: '\uD83D\uDCB0' },");
          changed = true;
          break;
        }
      }
    }
    if (changed) {
      fs.writeFileSync('app/admin/layout.tsx', layout);
      console.log('  ~ app/admin/layout.tsx (FinOps Suite added)');
      patched++;
    } else {
      console.log('  ! Could not auto-patch. Add manually:');
      console.log("    { id: 'finops', label: 'FinOps Suite', href: '/agents/cfo/finops', icon: '\uD83D\uDCB0' }");
    }
  } else {
    console.log('  o Sidebar already has FinOps');
  }
} catch(e) {
  console.log('  ! Sidebar: ' + e.message);
}

console.log('');
console.log('  ────────────────────────────────────────');
console.log('  Installed: ' + installed + ' files');
console.log('  Patched:   ' + patched + ' files');
console.log('  ────────────────────────────────────────');
console.log('');
console.log('  New route: /agents/cfo/finops');
console.log('');
console.log('  5 Tabs:');
console.log('    Accounts Payable   19 mandatory categories, project vs overhead,');
console.log('                       cash/accrual toggle, Woulf/Clutch segregation');
console.log('    Debt & Assets      Equipment ledger, loan optimizer, pay-down');
console.log('                       strategies, refinance research, credit scores');
console.log('    Labor Tracking     Clock in/out, project assignment, cost rollup');
console.log('    Forecasting        30/60/90-day + 12/24-month cash flow projections');
console.log('    Idea Sandbox       Input business ideas, AI viability analysis');
console.log('');
console.log('  API endpoints:');
console.log('    /api/ap            AP CRUD, OCR categorization, project P&Ls');
console.log('    /api/debt          Equipment, loans, AI pay-down, credit scores');
console.log('    /api/labor         Clock in/out, project hours, cost tracking');
console.log('    /api/forecasting   Cash flow projections + business idea analysis');
console.log('');
console.log('  SQL: Run 004_finops_suite.sql in Supabase');
console.log('  Then: npm run dev');
console.log('');
