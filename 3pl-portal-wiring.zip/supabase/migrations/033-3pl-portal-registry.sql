-- =============================================================================
-- WoulfAI Migration 033: Register 3PL Customer Portal agent
-- =============================================================================

INSERT INTO agent_registry (slug, display_name, short_description, description, icon, status, component_path, display_order)
VALUES (
  '3pl-portal',
  '3PL Customer Portal',
  'White-label customer portal with inventory, ordering, billing, and AI support',
  'Give every 3PL customer self-service access to inventory, ordering, billing, and AI support — cuts support calls 60%',
  '🏗️',
  'live',
  'agents/3pl-portal/console',
  24
) ON CONFLICT (slug) DO UPDATE SET
  status = 'live',
  component_path = 'agents/3pl-portal/console';

INSERT INTO agent_category_map (agent_id, category_id, is_primary)
SELECT a.id, c.id, true
FROM agent_registry a, agent_categories c
WHERE a.slug = '3pl-portal' AND c.slug = 'operations'
ON CONFLICT DO NOTHING;

SELECT 'Migration 033 complete: 3PL Customer Portal registered' AS status;
