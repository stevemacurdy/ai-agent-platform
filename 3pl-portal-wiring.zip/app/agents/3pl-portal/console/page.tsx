'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const NAVY = '#1B2A4A';
const ORANGE = '#F5920B';
const TEAL = '#2A9D8F';
const RED = '#DC2626';
const GREEN = '#059669';
const BORDER = '#E5E7EB';

interface Customer {
  code: string; name: string; skus: number; pallets: number; units: number;
  openOrders: number; balance: number; paymentStatus: string; autoPay: boolean;
  monthlyRevenue: number; contractEnd: string; zone: string; lastActivity: string;
}

interface KPI { label: string; value: string; change: string; trend: 'up' | 'down' | 'flat'; icon: string }

const DEMO_CUSTOMERS: Customer[] = [
  { code: 'MWS-001', name: 'Mountain West Supplements', skus: 16, pallets: 47, units: 8240, openOrders: 2, balance: 4847, paymentStatus: 'current', autoPay: true, monthlyRevenue: 7240, contractEnd: '2027-03-15', zone: 'A/B', lastActivity: '2 hours ago' },
  { code: 'RMN-002', name: 'Rocky Mountain Nutrition', skus: 24, pallets: 82, units: 14200, openOrders: 4, balance: 12340, paymentStatus: 'late-15', autoPay: false, monthlyRevenue: 11200, contractEnd: '2026-12-01', zone: 'A/C', lastActivity: '4 hours ago' },
  { code: 'PPL-003', name: 'Peak Performance Labs', skus: 8, pallets: 18, units: 3100, openOrders: 1, balance: 0, paymentStatus: 'current', autoPay: true, monthlyRevenue: 3890, contractEnd: '2027-06-30', zone: 'B', lastActivity: '1 day ago' },
  { code: 'FHC-004', name: 'Frontier Health Co', skus: 31, pallets: 104, units: 18400, openOrders: 5, balance: 8920, paymentStatus: 'current', autoPay: false, monthlyRevenue: 14100, contractEnd: '2026-09-15', zone: 'A/B/C', lastActivity: '30 min ago' },
  { code: 'SRD-005', name: 'Summit Retail Dist.', skus: 12, pallets: 38, units: 6800, openOrders: 3, balance: 22470, paymentStatus: 'late-30', autoPay: false, monthlyRevenue: 8750, contractEnd: '2026-07-01', zone: 'C', lastActivity: '3 days ago' },
  { code: 'WW-006', name: 'Wasatch Wellness', skus: 19, pallets: 34, units: 5900, openOrders: 2, balance: 3100, paymentStatus: 'current', autoPay: true, monthlyRevenue: 6420, contractEnd: '2027-01-15', zone: 'B', lastActivity: '6 hours ago' },
  { code: 'ALS-007', name: 'Alpine Supplements', skus: 6, pallets: 19, units: 3400, openOrders: 1, balance: 0, paymentStatus: 'current', autoPay: true, monthlyRevenue: 2980, contractEnd: '2027-09-01', zone: 'A', lastActivity: '1 day ago' },
];

const REVENUE_DATA = [
  { month: 'Oct', storage: 18400, handling: 19200, shipping: 12800 },
  { month: 'Nov', storage: 19800, handling: 20100, shipping: 13600 },
  { month: 'Dec', storage: 21200, handling: 22400, shipping: 15200 },
  { month: 'Jan', storage: 20100, handling: 21000, shipping: 14100 },
  { month: 'Feb', storage: 20800, handling: 21600, shipping: 14400 },
  { month: 'Mar', storage: 21400, handling: 22200, shipping: 14800 },
];

const AGING_DATA = [
  { bucket: 'Current', amount: 16867 },
  { bucket: '1-15 Days', amount: 0 },
  { bucket: '16-30 Days', amount: 12340 },
  { bucket: '31-60 Days', amount: 22470 },
];

const PIE_DATA = [
  { name: 'Auto-Pay', value: 4, color: GREEN },
  { name: 'Manual', value: 3, color: ORANGE },
];

const PALLET_TREND = [
  { month: 'Oct', pallets: 310 }, { month: 'Nov', pallets: 325 }, { month: 'Dec', pallets: 348 },
  { month: 'Jan', pallets: 335 }, { month: 'Feb', pallets: 338 }, { month: 'Mar', pallets: 342 },
];

const ACTIVITY = [
  { time: '30 min ago', event: 'Frontier Health Co placed order ORD-20260304-0023 (5 pallets)', type: 'order' },
  { time: '2 hours ago', event: 'Mountain West Supplements viewed inventory report', type: 'view' },
  { time: '4 hours ago', event: 'Rocky Mountain Nutrition submitted support ticket #847', type: 'support' },
  { time: '6 hours ago', event: 'Wasatch Wellness enabled auto-pay (3% discount)', type: 'billing' },
  { time: '1 day ago', event: 'Peak Performance Labs downloaded BOL for ORD-20260303-0012', type: 'order' },
  { time: '1 day ago', event: 'Alpine Supplements placed order ORD-20260303-0018 (1 pallet)', type: 'order' },
  { time: '3 days ago', event: 'Summit Retail Dist. last portal login', type: 'view' },
];

const fmt = (n: number) => n >= 1000 ? '$' + (n / 1000).toFixed(1) + 'K' : '$' + n;
const fmtFull = (n: number) => '$' + n.toLocaleString();

function StatusBadge({ status }: { status: string }) {
  const cfg: Record<string, { bg: string; color: string; label: string }> = {
    'current': { bg: '#ECFDF5', color: GREEN, label: 'Current' },
    'late-15': { bg: '#FFF7ED', color: ORANGE, label: 'Late 15' },
    'late-30': { bg: '#FEF2F2', color: RED, label: 'Late 30+' },
  };
  const c = cfg[status] || cfg['current'];
  return <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: c.bg, color: c.color }}>{c.label}</span>;
}

export default function ThreePLPortalConsole() {
  const [tab, setTab] = useState('dashboard');
  const [source, setSource] = useState<'live' | 'demo'>('demo');
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<keyof Customer>('monthlyRevenue');
  const [sortAsc, setSortAsc] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [aiModal, setAiModal] = useState<{ title: string; loading: boolean; result: string } | null>(null);

  useEffect(() => {
    fetch('/api/agents/3pl-portal').then(r => r.json()).then(d => {
      if (d.customer && d.customer.customer_code !== 'MWS-001') setSource('live');
    }).catch(() => {});
  }, []);

  const customers = DEMO_CUSTOMERS
    .filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.code.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      const av = a[sortKey], bv = b[sortKey];
      if (typeof av === 'number' && typeof bv === 'number') return sortAsc ? av - bv : bv - av;
      return sortAsc ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });

  const totalRevenue = DEMO_CUSTOMERS.reduce((s, c) => s + c.monthlyRevenue, 0);
  const totalAR = DEMO_CUSTOMERS.reduce((s, c) => s + c.balance, 0);
  const totalPallets = DEMO_CUSTOMERS.reduce((s, c) => s + c.pallets, 0);
  const autoPayPct = Math.round(DEMO_CUSTOMERS.filter(c => c.autoPay).length / DEMO_CUSTOMERS.length * 100);

  const kpis: KPI[] = [
    { label: 'Monthly Revenue', value: fmtFull(totalRevenue), change: '+11%', trend: 'up', icon: '\uD83D\uDCB0' },
    { label: 'Total AR', value: fmtFull(totalAR), change: '-4%', trend: 'up', icon: '\uD83D\uDCB3' },
    { label: 'Total Pallets', value: totalPallets.toLocaleString(), change: '+6%', trend: 'up', icon: '\uD83D\uDCE6' },
    { label: 'Auto-Pay Rate', value: autoPayPct + '%', change: '+8%', trend: 'up', icon: '\uD83D\uDD04' },
  ];

  function toggleSort(key: keyof Customer) {
    if (sortKey === key) setSortAsc(!sortAsc);
    else { setSortKey(key); setSortAsc(false); }
  }

  async function runAI(title: string, prompt: string) {
    setAiModal({ title, loading: true, result: '' });
    try {
      const resp = await fetch('/api/agents/3pl-portal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'ai-analysis', prompt }),
      });
      const d = await resp.json();
      setAiModal({ title, loading: false, result: d.result || d.message || 'Analysis complete. No actionable items found.' });
    } catch {
      setAiModal({ title, loading: false, result: 'Analysis unavailable. Please try again.' });
    }
  }

  const tabs = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'customers', label: 'Customers' },
    { id: 'billing', label: 'Billing' },
    { id: 'operations', label: 'Operations' },
  ];

  return (
    <div className="min-h-screen" style={{ background: '#F4F5F7' }}>
      <div className="max-w-[1200px] mx-auto px-4 py-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🏗️</span>
            <div>
              <h1 className="text-xl font-extrabold" style={{ color: NAVY, fontFamily: "'Outfit', sans-serif" }}>3PL Customer Portal</h1>
              <p className="text-xs" style={{ color: '#6B7280' }}>{DEMO_CUSTOMERS.length} active customers across {totalPallets} pallets</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className={'flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ' +
              (source === 'live' ? 'bg-emerald-50 text-emerald-600 border-emerald-500/20' : 'bg-amber-50 text-amber-600 border-amber-500/20')}>
              <span className={'w-1.5 h-1.5 rounded-full ' + (source === 'live' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500')} />
              {source === 'live' ? 'Live' : 'Demo'}
            </span>
            <Link href="/portal/MWS-001" target="_blank" className="text-xs font-bold px-3 py-1.5 rounded-lg text-white" style={{ background: ORANGE }}>
              Preview Portal
            </Link>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b" style={{ borderColor: BORDER }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={'px-4 py-2 text-sm font-medium border-b-2 transition ' +
                (tab === t.id ? 'font-bold' : 'border-transparent')}
              style={tab === t.id ? { color: TEAL, borderColor: TEAL } : { color: '#9CA3AF' }}>
              {t.label}
            </button>
          ))}
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {kpis.map(k => (
            <div key={k.label} className="rounded-xl border bg-white p-4" style={{ borderColor: BORDER }}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: '#9CA3AF' }}>{k.label}</span>
                <span className="text-base">{k.icon}</span>
              </div>
              <p className="text-xl font-extrabold" style={{ color: NAVY, fontFamily: "'Outfit', sans-serif" }}>{k.value}</p>
              <p className="text-[10px] font-medium mt-1" style={{ color: k.trend === 'up' ? GREEN : RED }}>
                {k.trend === 'up' ? '\u2191' : '\u2193'} {k.change}
              </p>
            </div>
          ))}
        </div>

        {/* Dashboard Tab */}
        {tab === 'dashboard' && (
          <div className="space-y-5">
            <div className="grid md:grid-cols-2 gap-5">
              {/* Revenue Chart */}
              <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
                <h3 className="text-sm font-bold mb-3" style={{ color: NAVY }}>Revenue by Category (6 Mo)</h3>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={REVENUE_DATA}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
                    <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9CA3AF' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#9CA3AF' }} tickFormatter={v => fmt(v)} />
                    <Tooltip formatter={(v: number) => fmtFull(v)} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="storage" fill={TEAL} name="Storage" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="handling" fill={ORANGE} name="Handling" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="shipping" fill={NAVY} name="Shipping" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Activity Feed */}
              <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
                <h3 className="text-sm font-bold mb-3" style={{ color: NAVY }}>Recent Portal Activity</h3>
                <div className="space-y-2.5 max-h-[220px] overflow-y-auto">
                  {ACTIVITY.map((a, i) => (
                    <div key={i} className="flex items-start gap-2.5">
                      <span className="text-sm mt-0.5">{a.type === 'order' ? '\uD83D\uDCE6' : a.type === 'billing' ? '\uD83D\uDCB3' : a.type === 'support' ? '\uD83C\uDFA7' : '\uD83D\uDC41'}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs" style={{ color: NAVY }}>{a.event}</p>
                        <p className="text-[10px]" style={{ color: '#9CA3AF' }}>{a.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Customer Table */}
            <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold" style={{ color: NAVY }}>Customer Overview</h3>
                <div className="flex gap-2">
                  <button onClick={() => runAI('Billing Report', 'Generate a billing summary for all 3PL customers including total AR, aging buckets, auto-pay enrollment, and recommended actions for late accounts.')}
                    className="text-[10px] font-bold px-3 py-1.5 rounded-lg border" style={{ borderColor: TEAL, color: TEAL }}>AI Billing Report</button>
                  <button onClick={() => runAI('Portal Health', 'Analyze portal engagement across all customers: login frequency, feature usage, order volume trends, and identify customers who may be at risk of churn.')}
                    className="text-[10px] font-bold px-3 py-1.5 rounded-lg border" style={{ borderColor: ORANGE, color: ORANGE }}>Portal Health</button>
                </div>
              </div>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search customers..."
                className="w-full rounded-lg border px-3 py-2 text-xs mb-3 focus:outline-none focus:ring-2" style={{ borderColor: BORDER }} />
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b" style={{ borderColor: BORDER }}>
                      {[
                        { key: 'name', label: 'Customer' }, { key: 'pallets', label: 'Pallets' }, { key: 'openOrders', label: 'Orders' },
                        { key: 'balance', label: 'Balance' }, { key: 'paymentStatus', label: 'Payment' }, { key: 'monthlyRevenue', label: 'Revenue/Mo' }, { key: 'lastActivity', label: 'Last Active' },
                      ].map(col => (
                        <th key={col.key} onClick={() => toggleSort(col.key as keyof Customer)}
                          className="text-left py-2 font-semibold cursor-pointer select-none" style={{ color: '#6B7280' }}>
                          {col.label} {sortKey === col.key ? (sortAsc ? '\u2191' : '\u2193') : ''}
                        </th>
                      ))}
                      <th className="text-right py-2 font-semibold" style={{ color: '#6B7280' }}>Portal</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customers.map(c => (
                      <tr key={c.code} onClick={() => setExpanded(expanded === c.code ? null : c.code)}
                        className="border-b cursor-pointer hover:bg-gray-50 transition" style={{ borderColor: '#F3F4F6' }}>
                        <td className="py-2.5">
                          <span className="font-semibold" style={{ color: NAVY }}>{c.name}</span>
                          <span className="text-[10px] ml-1.5" style={{ color: '#9CA3AF' }}>{c.code}</span>
                        </td>
                        <td className="py-2.5" style={{ color: NAVY }}>{c.pallets}</td>
                        <td className="py-2.5" style={{ color: NAVY }}>{c.openOrders}</td>
                        <td className="py-2.5 font-medium" style={{ color: c.balance > 10000 ? RED : NAVY }}>{fmtFull(c.balance)}</td>
                        <td className="py-2.5"><StatusBadge status={c.paymentStatus} /></td>
                        <td className="py-2.5 font-medium" style={{ color: NAVY }}>{fmtFull(c.monthlyRevenue)}</td>
                        <td className="py-2.5" style={{ color: '#9CA3AF' }}>{c.lastActivity}</td>
                        <td className="py-2.5 text-right">
                          <Link href={'/portal/' + c.code} target="_blank" onClick={e => e.stopPropagation()}
                            className="text-[10px] font-bold px-2 py-1 rounded-lg" style={{ background: '#F3F4F6', color: '#6B7280' }}>
                            Open
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Customers Tab */}
        {tab === 'customers' && (
          <div className="space-y-5">
            <div className="grid md:grid-cols-3 gap-5">
              {DEMO_CUSTOMERS.map(c => (
                <div key={c.code} className="rounded-xl border bg-white p-5 hover:shadow-md transition" style={{ borderColor: c.paymentStatus === 'late-30' ? RED + '40' : BORDER }}>
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="text-sm font-bold" style={{ color: NAVY }}>{c.name}</p>
                      <p className="text-[10px]" style={{ color: '#9CA3AF' }}>{c.code}</p>
                    </div>
                    <StatusBadge status={c.paymentStatus} />
                  </div>
                  <div className="grid grid-cols-2 gap-y-2 text-xs mb-3">
                    <div><span style={{ color: '#9CA3AF' }}>SKUs:</span> <span className="font-medium" style={{ color: NAVY }}>{c.skus}</span></div>
                    <div><span style={{ color: '#9CA3AF' }}>Pallets:</span> <span className="font-medium" style={{ color: NAVY }}>{c.pallets}</span></div>
                    <div><span style={{ color: '#9CA3AF' }}>Open Orders:</span> <span className="font-medium" style={{ color: NAVY }}>{c.openOrders}</span></div>
                    <div><span style={{ color: '#9CA3AF' }}>Balance:</span> <span className="font-medium" style={{ color: c.balance > 10000 ? RED : NAVY }}>{fmtFull(c.balance)}</span></div>
                    <div><span style={{ color: '#9CA3AF' }}>Revenue/Mo:</span> <span className="font-medium" style={{ color: NAVY }}>{fmtFull(c.monthlyRevenue)}</span></div>
                    <div><span style={{ color: '#9CA3AF' }}>Auto-Pay:</span> <span className="font-medium" style={{ color: c.autoPay ? GREEN : '#9CA3AF' }}>{c.autoPay ? 'Yes' : 'No'}</span></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px]" style={{ color: '#9CA3AF' }}>Contract: {new Date(c.contractEnd).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</span>
                    <Link href={'/portal/' + c.code} target="_blank" className="text-[10px] font-bold px-3 py-1 rounded-lg text-white" style={{ background: TEAL }}>
                      Open Portal
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Billing Tab */}
        {tab === 'billing' && (
          <div className="space-y-5">
            <div className="grid md:grid-cols-2 gap-5">
              <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
                <h3 className="text-sm font-bold mb-3" style={{ color: NAVY }}>AR Aging</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={AGING_DATA}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
                    <XAxis dataKey="bucket" tick={{ fontSize: 10, fill: '#9CA3AF' }} />
                    <YAxis tick={{ fontSize: 10, fill: '#9CA3AF' }} tickFormatter={v => fmt(v)} />
                    <Tooltip formatter={(v: number) => fmtFull(v)} />
                    <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
                      {AGING_DATA.map((e, i) => (
                        <Cell key={i} fill={i === 0 ? GREEN : i <= 1 ? TEAL : i === 2 ? ORANGE : RED} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
                <h3 className="text-sm font-bold mb-3" style={{ color: NAVY }}>Auto-Pay Enrollment</h3>
                <div className="flex items-center gap-6">
                  <ResponsiveContainer width={140} height={140}>
                    <PieChart>
                      <Pie data={PIE_DATA} cx="50%" cy="50%" innerRadius={40} outerRadius={60} dataKey="value" stroke="none">
                        {PIE_DATA.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-2">
                    {PIE_DATA.map(p => (
                      <div key={p.name} className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full" style={{ background: p.color }} />
                        <span className="text-xs" style={{ color: NAVY }}>{p.name}: <strong>{p.value}</strong> customers</span>
                      </div>
                    ))}
                    <p className="text-[10px] mt-2" style={{ color: '#9CA3AF' }}>Auto-pay saves avg 12 days on payment</p>
                  </div>
                </div>
                <button onClick={() => runAI('Auto-Pay Campaign', 'Draft personalized auto-pay invitation emails for the 3 customers without auto-pay enabled. Include the 3% discount incentive and estimated annual savings for each customer based on their monthly volume.')}
                  className="mt-3 text-[10px] font-bold px-3 py-1.5 rounded-lg border w-full" style={{ borderColor: ORANGE, color: ORANGE }}>
                  Draft Auto-Pay Invitations
                </button>
              </div>
            </div>

            {/* Late accounts detail */}
            <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
              <h3 className="text-sm font-bold mb-3" style={{ color: NAVY }}>Past Due Accounts</h3>
              {DEMO_CUSTOMERS.filter(c => c.paymentStatus !== 'current').length === 0 ? (
                <p className="text-xs" style={{ color: '#9CA3AF' }}>All accounts are current.</p>
              ) : (
                <div className="space-y-3">
                  {DEMO_CUSTOMERS.filter(c => c.paymentStatus !== 'current').map(c => (
                    <div key={c.code} className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: c.paymentStatus === 'late-30' ? RED + '40' : ORANGE + '40', background: c.paymentStatus === 'late-30' ? '#FEF2F2' : '#FFF7ED' }}>
                      <div>
                        <p className="text-sm font-semibold" style={{ color: NAVY }}>{c.name}</p>
                        <p className="text-xs" style={{ color: '#6B7280' }}>{fmtFull(c.balance)} outstanding</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <StatusBadge status={c.paymentStatus} />
                        <button onClick={() => runAI('Collection Plan: ' + c.name, 'Create a collection strategy for ' + c.name + ' (' + c.code + ') who owes ' + fmtFull(c.balance) + ' and is ' + c.paymentStatus + '. Include: 1) recommended communication approach, 2) escalation timeline, 3) whether to hold new orders, 4) specific email draft.')}
                          className="text-[10px] font-bold px-3 py-1 rounded-lg text-white" style={{ background: c.paymentStatus === 'late-30' ? RED : ORANGE }}>
                          Collection Plan
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Operations Tab */}
        {tab === 'operations' && (
          <div className="space-y-5">
            <div className="grid md:grid-cols-2 gap-5">
              <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
                <h3 className="text-sm font-bold mb-3" style={{ color: NAVY }}>Pallet Count Trend</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={PALLET_TREND}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
                    <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9CA3AF' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#9CA3AF' }} />
                    <Tooltip />
                    <Area type="monotone" dataKey="pallets" fill={TEAL + '20'} stroke={TEAL} strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
                <h3 className="text-sm font-bold mb-3" style={{ color: NAVY }}>Space by Customer</h3>
                <div className="space-y-2">
                  {DEMO_CUSTOMERS.sort((a, b) => b.pallets - a.pallets).map(c => {
                    const pct = Math.round(c.pallets / totalPallets * 100);
                    return (
                      <div key={c.code} className="flex items-center gap-2">
                        <span className="text-xs w-32 truncate" style={{ color: NAVY }}>{c.name}</span>
                        <div className="flex-1 h-4 rounded-full overflow-hidden" style={{ background: '#F3F4F6' }}>
                          <div className="h-full rounded-full" style={{ width: pct + '%', background: TEAL }} />
                        </div>
                        <span className="text-[10px] font-bold w-14 text-right" style={{ color: '#6B7280' }}>{c.pallets} ({pct}%)</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Orders pipeline */}
            <div className="rounded-xl border bg-white p-5" style={{ borderColor: BORDER }}>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold" style={{ color: NAVY }}>Open Orders Across Customers</h3>
                <button onClick={() => runAI('Capacity Forecast', 'Analyze current order pipeline and pallet trends. Forecast when we will hit capacity constraints in each zone. Recommend actions: zone rebalancing, staffing adjustments, or customer communication about lead times.')}
                  className="text-[10px] font-bold px-3 py-1.5 rounded-lg border" style={{ borderColor: TEAL, color: TEAL }}>
                  AI Capacity Forecast
                </button>
              </div>
              <div className="grid grid-cols-4 gap-3">
                {['Pending', 'Picking', 'Packed', 'Shipped Today'].map((stage, i) => {
                  const counts = [2, 1, 0, 1];
                  const colors = ['#EFF6FF', '#FFF7ED', '#F5F3FF', '#ECFDF5'];
                  const textColors = ['#2563EB', ORANGE, '#7C3AED', GREEN];
                  return (
                    <div key={stage} className="rounded-lg p-4 text-center" style={{ background: colors[i] }}>
                      <p className="text-2xl font-bold" style={{ color: textColors[i] }}>{counts[i]}</p>
                      <p className="text-[10px] font-medium mt-1" style={{ color: textColors[i] }}>{stage}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* AI Modal */}
        {aiModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setAiModal(null)}>
            <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full mx-4 max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <div className="p-5 border-b" style={{ borderColor: BORDER }}>
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold" style={{ color: NAVY }}>{aiModal.title}</h3>
                  <button onClick={() => setAiModal(null)} className="text-lg" style={{ color: '#9CA3AF' }}>x</button>
                </div>
              </div>
              <div className="p-5">
                {aiModal.loading ? (
                  <div className="flex items-center gap-2 py-8 justify-center">
                    <div className="w-5 h-5 border-2 rounded-full animate-spin" style={{ borderColor: TEAL, borderTopColor: 'transparent' }} />
                    <span className="text-xs" style={{ color: '#6B7280' }}>Analyzing...</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <pre className="text-xs whitespace-pre-wrap leading-relaxed" style={{ color: NAVY }}>{aiModal.result}</pre>
                    <button onClick={() => { navigator.clipboard.writeText(aiModal.result); }}
                      className="text-[10px] font-bold px-3 py-1.5 rounded-lg border" style={{ borderColor: BORDER, color: '#6B7280' }}>
                      Copy to Clipboard
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
