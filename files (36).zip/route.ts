// ============================================================
// app/api/admin/comp-agent/route.ts
// Super Admin endpoint to comp agent access for a company
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth'; // your auth helper
import { db } from '@/lib/db';                 // your DB client

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();

    // 1. Verify Super Admin
    if (!session?.user || !session.user.roles?.includes('super_admin')) {
      return NextResponse.json(
        { error: 'Unauthorized. Super Admin access required.' },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { companyId, agentSlug, compAll } = body;

    if (!companyId) {
      return NextResponse.json(
        { error: 'companyId is required' },
        { status: 400 }
      );
    }

    // 2. Comp all agents or a specific one
    if (compAll) {
      const result = await db.query(
        `SELECT admin_comp_all_agents($1, $2) AS count`,
        [session.user.id, companyId]
      );
      return NextResponse.json({
        success: true,
        message: `Comped ${result.rows[0].count} agents for company`,
        companyId,
      });
    }

    if (!agentSlug) {
      return NextResponse.json(
        { error: 'agentSlug is required (or set compAll: true)' },
        { status: 400 }
      );
    }

    const result = await db.query(
      `SELECT admin_comp_agent($1, $2, $3) AS subscription_id`,
      [session.user.id, companyId, agentSlug]
    );

    return NextResponse.json({
      success: true,
      subscriptionId: result.rows[0].subscription_id,
      agentSlug,
      companyId,
      status: 'comped',
    });

  } catch (error: any) {
    console.error('[comp-agent] Error:', error);
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}
