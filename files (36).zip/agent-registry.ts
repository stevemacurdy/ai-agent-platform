// ============================================================
// lib/agents/agent-registry.ts
// Single source of truth for all WoulfAI agents
// ============================================================

export type AgentStatus = 'demo' | 'live' | 'beta' | 'disabled';
export type PortalGroup = 'woulf' | 'clutch';
export type AgentCategory = 'leadership' | 'marketing' | 'operations' | 'hr' | 'finance';
export type SubscriptionStatus = 'none' | 'trial' | 'active' | 'comped' | 'expired' | 'cancelled';

export interface AgentConfig {
  slug: string;
  displayName: string;
  description: string;
  icon: string;           // Lucide icon name
  category: AgentCategory;
  portalGroup: PortalGroup;
  status: AgentStatus;
  route: string;
  odooModel: string | null;
  features: {
    submit: boolean;
    edit: boolean;
    download: boolean;
    aiChat: boolean;
  };
  emptyState: {
    title: string;
    description: string;
    ctaLabel: string;
    ctaAction: string;    // 'create' | 'import' | 'connect'
  };
}

// ============================================================
// MASTER AGENT DEFINITIONS
// ============================================================
export const AGENT_REGISTRY: Record<string, AgentConfig> = {

  'org-lead-multirole': {
    slug: 'org-lead-multirole',
    displayName: 'Organization Lead',
    description: 'Multi-role business command center for organization leaders',
    icon: 'Crown',
    category: 'leadership',
    portalGroup: 'woulf',
    status: 'live',
    route: '/dashboard/org-lead',
    odooModel: null,
    features: {
      submit: true,
      edit: true,
      download: true,
      aiChat: true,
    },
    emptyState: {
      title: 'Welcome, Organization Lead',
      description: 'Your command center is ready. Start by connecting your business data or exploring your agent suite.',
      ctaLabel: 'Configure Dashboard',
      ctaAction: 'create',
    },
  },

  'seo-agent': {
    slug: 'seo-agent',
    displayName: 'SEO Agent',
    description: 'AI-powered SEO analysis, keyword tracking & site optimization',
    icon: 'Search',
    category: 'marketing',
    portalGroup: 'clutch',
    status: 'live',
    route: '/dashboard/agents/seo',
    odooModel: 'seo.analysis',
    features: {
      submit: true,
      edit: true,
      download: true,
      aiChat: true,
    },
    emptyState: {
      title: 'No SEO Data Yet',
      description: 'Add your first domain to start tracking keywords, rankings, and optimization opportunities.',
      ctaLabel: 'Add Domain',
      ctaAction: 'create',
    },
  },

  'marketing-agent': {
    slug: 'marketing-agent',
    displayName: 'Marketing Agent',
    description: 'Campaign management, lead generation & content strategy',
    icon: 'Megaphone',
    category: 'marketing',
    portalGroup: 'clutch',
    status: 'live',
    route: '/dashboard/agents/marketing',
    odooModel: 'marketing.campaign',
    features: {
      submit: true,
      edit: true,
      download: true,
      aiChat: true,
    },
    emptyState: {
      title: 'No Campaigns Yet',
      description: 'Launch your first marketing campaign to start tracking spend, leads, and ROI.',
      ctaLabel: 'Create Campaign',
      ctaAction: 'create',
    },
  },

  'wms-agent': {
    slug: 'wms-agent',
    displayName: 'WMS Agent',
    description: 'Warehouse management, inventory tracking & fulfillment operations',
    icon: 'Warehouse',
    category: 'operations',
    portalGroup: 'woulf',
    status: 'live',
    route: '/dashboard/agents/wms',
    odooModel: 'stock.warehouse',
    features: {
      submit: true,
      edit: true,
      download: true,
      aiChat: true,
    },
    emptyState: {
      title: 'No Inventory Data Yet',
      description: 'Connect your warehouse or import inventory to start tracking stock levels and fulfillment.',
      ctaLabel: 'Import Inventory',
      ctaAction: 'import',
    },
  },

  'hr-agent': {
    slug: 'hr-agent',
    displayName: 'HR Agent',
    description: 'Employee management, onboarding workflows & compliance tracking',
    icon: 'Users',
    category: 'hr',
    portalGroup: 'woulf',
    status: 'live',
    route: '/dashboard/agents/hr',
    odooModel: 'hr.employee',
    features: {
      submit: true,
      edit: true,
      download: true,
      aiChat: true,
    },
    emptyState: {
      title: 'No Employees Added',
      description: 'Add your team members or sync from Odoo to manage onboarding and compliance.',
      ctaLabel: 'Add Employee',
      ctaAction: 'create',
    },
  },

} as const;

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/** Get all live agents */
export function getLiveAgents(): AgentConfig[] {
  return Object.values(AGENT_REGISTRY).filter(a => a.status === 'live');
}

/** Get agents by portal group */
export function getAgentsByPortal(portal: PortalGroup): AgentConfig[] {
  return getLiveAgents().filter(a => a.portalGroup === portal);
}

/** Get agents by category */
export function getAgentsByCategory(category: AgentCategory): AgentConfig[] {
  return getLiveAgents().filter(a => a.category === category);
}

/** Get sidebar navigation structure grouped by category */
export function getSidebarNavGroups(): { category: AgentCategory; label: string; agents: AgentConfig[] }[] {
  const categoryLabels: Record<AgentCategory, string> = {
    leadership: 'Leadership',
    marketing: 'Marketing & Growth',
    operations: 'Operations',
    hr: 'People & HR',
    finance: 'Finance',
  };

  const categories: AgentCategory[] = ['leadership', 'marketing', 'operations', 'hr', 'finance'];

  return categories
    .map(cat => ({
      category: cat,
      label: categoryLabels[cat],
      agents: getAgentsByCategory(cat),
    }))
    .filter(group => group.agents.length > 0);
}

/** Check if an agent is accessible for a given subscription status */
export function isAgentAccessible(subStatus: SubscriptionStatus): boolean {
  return ['active', 'comped', 'trial'].includes(subStatus);
}
