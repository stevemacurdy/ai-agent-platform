// ============================================================
// components/dashboard/sidebar-nav.tsx
// Agent Sidebar — auto-built from AGENT_REGISTRY
// Shows live status, subscription badges, and portal grouping
// ============================================================

'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Crown, Search, Megaphone, Warehouse, Users,
  LayoutDashboard, Settings, ChevronDown, Zap,
} from 'lucide-react';
import { getSidebarNavGroups, type AgentConfig, type SubscriptionStatus } from '@/lib/agents/agent-registry';
import { useTenant } from '@/lib/providers/tenant-provider';

// ============================================================
// Icon Mapping
// ============================================================
const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Crown, Search, Megaphone, Warehouse, Users,
};

function AgentIcon({ name, className }: { name: string; className?: string }) {
  const Icon = ICON_MAP[name] || Zap;
  return <Icon className={className} />;
}

// ============================================================
// Subscription Badge
// ============================================================
function StatusBadge({ status }: { status: SubscriptionStatus }) {
  const config: Record<SubscriptionStatus, { label: string; color: string }> = {
    active:    { label: 'Live',    color: 'bg-emerald-500/15 text-emerald-400' },
    comped:    { label: 'Live',    color: 'bg-emerald-500/15 text-emerald-400' },
    trial:     { label: 'Trial',   color: 'bg-amber-500/15 text-amber-400' },
    expired:   { label: 'Expired', color: 'bg-red-500/15 text-red-400' },
    cancelled: { label: 'Inactive', color: 'bg-zinc-500/15 text-zinc-400' },
    none:      { label: 'Locked',  color: 'bg-zinc-500/15 text-zinc-500' },
  };

  const { label, color } = config[status] || config.none;
  return (
    <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full ${color}`}>
      {label}
    </span>
  );
}

// ============================================================
// Agent Nav Item
// ============================================================
interface AgentNavItemProps {
  agent: AgentConfig;
  isActive: boolean;
  subscriptionStatus: SubscriptionStatus;
}

function AgentNavItem({ agent, isActive, subscriptionStatus }: AgentNavItemProps) {
  const isAccessible = ['active', 'comped', 'trial'].includes(subscriptionStatus);

  return (
    <Link
      href={isAccessible ? agent.route : '#'}
      className={`
        flex items-center justify-between px-3 py-2 rounded-lg text-sm
        transition-all duration-150 group
        ${isActive
          ? 'bg-white/10 text-white font-medium'
          : isAccessible
            ? 'text-zinc-400 hover:text-white hover:bg-white/5'
            : 'text-zinc-600 cursor-not-allowed'
        }
      `}
      onClick={e => { if (!isAccessible) e.preventDefault(); }}
    >
      <div className="flex items-center gap-3">
        <AgentIcon name={agent.icon} className="w-4 h-4" />
        <span>{agent.displayName}</span>
      </div>
      <StatusBadge status={subscriptionStatus} />
    </Link>
  );
}

// ============================================================
// Business Switcher (Top of Sidebar)
// ============================================================
function BusinessSwitcher() {
  const { currentCompany, companies, switchCompany, isSwitching } = useTenant();

  if (companies.length <= 1) {
    return (
      <div className="px-4 py-3 border-b border-zinc-800">
        <p className="text-sm font-semibold text-white truncate">
          {currentCompany?.name || 'No Company'}
        </p>
      </div>
    );
  }

  return (
    <div className="px-4 py-3 border-b border-zinc-800">
      <div className="relative">
        <select
          value={currentCompany?.id || ''}
          onChange={e => switchCompany(e.target.value)}
          disabled={isSwitching}
          className="
            w-full bg-zinc-800 text-white text-sm font-semibold
            rounded-lg px-3 py-2 pr-8
            appearance-none cursor-pointer
            border border-zinc-700 hover:border-zinc-600
            focus:outline-none focus:ring-2 focus:ring-blue-500/50
            disabled:opacity-50
          "
        >
          {companies.map(company => (
            <option key={company.id} value={company.id}>
              {company.name}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 pointer-events-none" />
      </div>
      {isSwitching && (
        <p className="text-[10px] text-blue-400 mt-1 animate-pulse">Switching...</p>
      )}
    </div>
  );
}

// ============================================================
// Main Sidebar Component
// ============================================================
interface SidebarNavProps {
  agentSubscriptions: Record<string, SubscriptionStatus>;  // slug -> status
  userRole: string;
}

export function SidebarNav({ agentSubscriptions, userRole }: SidebarNavProps) {
  const pathname = usePathname();
  const navGroups = getSidebarNavGroups();

  return (
    <aside className="w-64 h-screen bg-zinc-900 border-r border-zinc-800 flex flex-col">
      {/* Business Switcher */}
      <BusinessSwitcher />

      {/* Main Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
        {/* Dashboard Home */}
        <Link
          href="/dashboard"
          className={`
            flex items-center gap-3 px-3 py-2 rounded-lg text-sm
            ${pathname === '/dashboard'
              ? 'bg-white/10 text-white font-medium'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
            }
          `}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Command Center</span>
        </Link>

        {/* Agent Groups */}
        {navGroups.map(group => (
          <div key={group.category}>
            <p className="px-3 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider mb-2">
              {group.label}
            </p>
            <div className="space-y-0.5">
              {group.agents.map(agent => (
                <AgentNavItem
                  key={agent.slug}
                  agent={agent}
                  isActive={pathname === agent.route || pathname?.startsWith(agent.route + '/')}
                  subscriptionStatus={agentSubscriptions[agent.slug] || 'none'}
                />
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* Bottom: Settings (Admin only) */}
      {['super_admin', 'admin'].includes(userRole) && (
        <div className="border-t border-zinc-800 p-3">
          <Link
            href="/dashboard/admin/settings"
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-zinc-400 hover:text-white hover:bg-white/5"
          >
            <Settings className="w-4 h-4" />
            <span>Admin Settings</span>
          </Link>
        </div>
      )}
    </aside>
  );
}
