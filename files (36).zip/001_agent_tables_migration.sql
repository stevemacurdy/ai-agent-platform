-- ============================================================
-- WoulfAI Agent Deployment Migration
-- Version: 1.0.0
-- Date: 2026-02-18
-- Purpose: Create agent registry, agent-specific data tables,
--          admin comp logic, and multi-tenant isolation views
-- ============================================================

BEGIN;

-- ============================================================
-- 1. MASTER AGENT REGISTRY
-- ============================================================
CREATE TABLE IF NOT EXISTS agent_registry (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_slug      VARCHAR(50) UNIQUE NOT NULL,
    display_name    VARCHAR(100) NOT NULL,
    description     TEXT,
    icon            VARCHAR(50) DEFAULT 'bot',
    category        VARCHAR(50) NOT NULL,          -- 'operations', 'marketing', 'finance', 'hr', 'leadership'
    portal_group    VARCHAR(50) NOT NULL,          -- 'woulf' or 'clutch'
    status          VARCHAR(20) DEFAULT 'demo',    -- 'demo', 'live', 'beta', 'disabled'
    odoo_model      VARCHAR(100),                  -- mapped Odoo model for data sync
    default_route   VARCHAR(200) NOT NULL,
    sort_order      INT DEFAULT 0,
    requires_subscription BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Seed the 5 core agents
INSERT INTO agent_registry (agent_slug, display_name, description, icon, category, portal_group, status, odoo_model, default_route, sort_order) VALUES
    ('org-lead-multirole',  'Organization Lead',  'Multi-role business command center for org leaders',       'crown',        'leadership',  'woulf',  'live', NULL,                        '/dashboard/org-lead',      1),
    ('seo-agent',           'SEO Agent',          'AI-powered SEO analysis, keyword tracking & optimization', 'search',       'marketing',   'clutch', 'live', 'seo.analysis',              '/dashboard/agents/seo',    2),
    ('marketing-agent',     'Marketing Agent',    'Campaign management, lead gen & content strategy',         'megaphone',    'marketing',   'clutch', 'live', 'marketing.campaign',        '/dashboard/agents/marketing', 3),
    ('wms-agent',           'WMS Agent',          'Warehouse management, inventory tracking & fulfillment',   'warehouse',    'operations',  'woulf',  'live', 'stock.warehouse',           '/dashboard/agents/wms',    4),
    ('hr-agent',            'HR Agent',           'Employee management, onboarding & compliance tracking',    'users',        'hr',          'woulf',  'live', 'hr.employee',               '/dashboard/agents/hr',     5)
ON CONFLICT (agent_slug) DO UPDATE SET
    status = EXCLUDED.status,
    display_name = EXCLUDED.display_name,
    updated_at = NOW();

-- ============================================================
-- 2. AGENT ACCESS / SUBSCRIPTION TABLE
--    Links companies to agents with billing status
-- ============================================================
CREATE TABLE IF NOT EXISTS agent_subscriptions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    agent_id        UUID NOT NULL REFERENCES agent_registry(id) ON DELETE CASCADE,
    status          VARCHAR(20) DEFAULT 'trial',   -- 'trial', 'active', 'comped', 'expired', 'cancelled'
    stripe_sub_id   VARCHAR(100),                  -- NULL if comped
    comped_by       UUID REFERENCES users(id),     -- admin who granted comp
    comped_at       TIMESTAMPTZ,
    trial_ends_at   TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(company_id, agent_id)
);

CREATE INDEX idx_agent_subs_company ON agent_subscriptions(company_id);
CREATE INDEX idx_agent_subs_status ON agent_subscriptions(status);

-- ============================================================
-- 3. AGENT-SPECIFIC DATA TABLES (Multi-Tenant)
-- ============================================================

-- 3a. SEO Agent Data
CREATE TABLE IF NOT EXISTS seo_agent_data (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    domain          VARCHAR(255),
    keyword         VARCHAR(255),
    current_rank    INT,
    target_rank     INT,
    search_volume   INT,
    difficulty      DECIMAL(5,2),
    page_url        TEXT,
    last_crawled    TIMESTAMPTZ,
    notes           TEXT,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_seo_company ON seo_agent_data(company_id);

-- 3b. Marketing Agent Data
CREATE TABLE IF NOT EXISTS marketing_agent_data (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    campaign_name   VARCHAR(255) NOT NULL,
    campaign_type   VARCHAR(50),                   -- 'email', 'social', 'ppc', 'content', 'event'
    status          VARCHAR(30) DEFAULT 'draft',   -- 'draft', 'active', 'paused', 'completed'
    budget          DECIMAL(12,2),
    spend_to_date   DECIMAL(12,2) DEFAULT 0,
    leads_generated INT DEFAULT 0,
    conversions     INT DEFAULT 0,
    roi_percent     DECIMAL(8,2),
    start_date      DATE,
    end_date        DATE,
    notes           TEXT,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_marketing_company ON marketing_agent_data(company_id);

-- 3c. WMS Agent Data
CREATE TABLE IF NOT EXISTS wms_agent_data (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    warehouse_name  VARCHAR(255),
    sku             VARCHAR(100),
    product_name    VARCHAR(255),
    quantity_on_hand INT DEFAULT 0,
    quantity_reserved INT DEFAULT 0,
    quantity_available INT GENERATED ALWAYS AS (quantity_on_hand - quantity_reserved) STORED,
    reorder_point   INT DEFAULT 0,
    location_bin    VARCHAR(50),
    last_counted    TIMESTAMPTZ,
    odoo_product_id INT,                           -- FK to Odoo product
    notes           TEXT,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_wms_company ON wms_agent_data(company_id);

-- 3d. HR Agent Data
CREATE TABLE IF NOT EXISTS hr_agent_data (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    employee_name   VARCHAR(255) NOT NULL,
    email           VARCHAR(255),
    department      VARCHAR(100),
    position_title  VARCHAR(150),
    hire_date       DATE,
    status          VARCHAR(30) DEFAULT 'active',  -- 'active', 'onboarding', 'offboarding', 'terminated'
    manager_id      UUID REFERENCES users(id),
    odoo_employee_id INT,
    compliance_status VARCHAR(30) DEFAULT 'pending', -- 'pending', 'complete', 'overdue'
    notes           TEXT,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_hr_company ON hr_agent_data(company_id);

-- ============================================================
-- 4. ROW-LEVEL SECURITY (Multi-Tenant Isolation)
-- ============================================================

-- Enable RLS on all agent data tables
ALTER TABLE seo_agent_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketing_agent_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_agent_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE hr_agent_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_subscriptions ENABLE ROW LEVEL SECURITY;

-- Create policies: users can only see their company's data
-- (Assumes current_setting('app.current_company_id') is set per-session)

CREATE POLICY tenant_isolation_seo ON seo_agent_data
    USING (company_id::text = current_setting('app.current_company_id', TRUE));

CREATE POLICY tenant_isolation_marketing ON marketing_agent_data
    USING (company_id::text = current_setting('app.current_company_id', TRUE));

CREATE POLICY tenant_isolation_wms ON wms_agent_data
    USING (company_id::text = current_setting('app.current_company_id', TRUE));

CREATE POLICY tenant_isolation_hr ON hr_agent_data
    USING (company_id::text = current_setting('app.current_company_id', TRUE));

CREATE POLICY tenant_isolation_subs ON agent_subscriptions
    USING (company_id::text = current_setting('app.current_company_id', TRUE));

-- Super Admin bypass policy (can see all data)
CREATE POLICY admin_bypass_seo ON seo_agent_data
    USING (current_setting('app.user_role', TRUE) = 'super_admin');

CREATE POLICY admin_bypass_marketing ON marketing_agent_data
    USING (current_setting('app.user_role', TRUE) = 'super_admin');

CREATE POLICY admin_bypass_wms ON wms_agent_data
    USING (current_setting('app.user_role', TRUE) = 'super_admin');

CREATE POLICY admin_bypass_hr ON hr_agent_data
    USING (current_setting('app.user_role', TRUE) = 'super_admin');

-- ============================================================
-- 5. ADMIN COMP FUNCTION
--    Allows Super Admin to grant free agent access
-- ============================================================
CREATE OR REPLACE FUNCTION admin_comp_agent(
    p_admin_id UUID,
    p_company_id UUID,
    p_agent_slug VARCHAR(50)
)
RETURNS UUID AS $$
DECLARE
    v_agent_id UUID;
    v_sub_id UUID;
BEGIN
    -- Verify caller is super_admin
    IF NOT EXISTS (
        SELECT 1 FROM users 
        WHERE id = p_admin_id 
        AND 'super_admin' = ANY(roles)
    ) THEN
        RAISE EXCEPTION 'Unauthorized: Only Super Admins can comp agents';
    END IF;

    -- Get agent ID
    SELECT id INTO v_agent_id 
    FROM agent_registry 
    WHERE agent_slug = p_agent_slug;

    IF v_agent_id IS NULL THEN
        RAISE EXCEPTION 'Agent not found: %', p_agent_slug;
    END IF;

    -- Upsert subscription as comped
    INSERT INTO agent_subscriptions (company_id, agent_id, status, comped_by, comped_at)
    VALUES (p_company_id, v_agent_id, 'comped', p_admin_id, NOW())
    ON CONFLICT (company_id, agent_id) DO UPDATE SET
        status = 'comped',
        stripe_sub_id = NULL,
        comped_by = p_admin_id,
        comped_at = NOW(),
        updated_at = NOW()
    RETURNING id INTO v_sub_id;

    RETURN v_sub_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 6. BULK COMP — Comp ALL agents for a given company
-- ============================================================
CREATE OR REPLACE FUNCTION admin_comp_all_agents(
    p_admin_id UUID,
    p_company_id UUID
)
RETURNS INT AS $$
DECLARE
    v_count INT := 0;
    v_agent RECORD;
BEGIN
    FOR v_agent IN SELECT agent_slug FROM agent_registry WHERE status = 'live' LOOP
        PERFORM admin_comp_agent(p_admin_id, p_company_id, v_agent.agent_slug);
        v_count := v_count + 1;
    END LOOP;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 7. HELPER VIEW: Active agents per company
-- ============================================================
CREATE OR REPLACE VIEW v_company_active_agents AS
SELECT 
    c.id AS company_id,
    c.name AS company_name,
    ar.agent_slug,
    ar.display_name,
    ar.icon,
    ar.category,
    ar.portal_group,
    ar.default_route,
    COALESCE(asub.status, 'none') AS subscription_status,
    CASE 
        WHEN asub.status IN ('active', 'comped') THEN TRUE
        WHEN asub.status = 'trial' AND asub.trial_ends_at > NOW() THEN TRUE
        ELSE FALSE
    END AS is_accessible
FROM companies c
CROSS JOIN agent_registry ar
LEFT JOIN agent_subscriptions asub 
    ON asub.company_id = c.id AND asub.agent_id = ar.id
WHERE ar.status = 'live';

COMMIT;
