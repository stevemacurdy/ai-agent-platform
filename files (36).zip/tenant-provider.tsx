// ============================================================
// lib/providers/tenant-provider.tsx
// Global Business Switcher + Multi-Tenant Context
// Ensures all agent data refreshes on company switch
// ============================================================

'use client';

import React, { createContext, useContext, useState, useCallback, useEffect, useTransition } from 'react';
import { useRouter } from 'next/navigation';

// ============================================================
// Types
// ============================================================
interface Company {
  id: string;
  name: string;
  slug: string;
  logo?: string;
}

interface TenantContextType {
  currentCompany: Company | null;
  companies: Company[];
  switchCompany: (companyId: string) => void;
  isSwitching: boolean;
  companyId: string | null;
}

const TenantContext = createContext<TenantContextType>({
  currentCompany: null,
  companies: [],
  switchCompany: () => {},
  isSwitching: false,
  companyId: null,
});

// ============================================================
// Provider
// ============================================================
interface TenantProviderProps {
  children: React.ReactNode;
  initialCompanies: Company[];
  initialCompanyId?: string;
}

export function TenantProvider({ children, initialCompanies, initialCompanyId }: TenantProviderProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [companies] = useState<Company[]>(initialCompanies);
  const [currentCompanyId, setCurrentCompanyId] = useState<string | null>(
    initialCompanyId || initialCompanies[0]?.id || null
  );

  const currentCompany = companies.find(c => c.id === currentCompanyId) || null;

  // ----------------------------------------------------------
  // switchCompany: Updates context, sets cookie, invalidates
  // all agent data queries so dashboards refresh instantly
  // ----------------------------------------------------------
  const switchCompany = useCallback((companyId: string) => {
    const target = companies.find(c => c.id === companyId);
    if (!target) {
      console.error(`[TenantProvider] Company not found: ${companyId}`);
      return;
    }

    startTransition(async () => {
      // 1. Update server-side session with new companyId
      await fetch('/api/tenant/switch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ companyId }),
      });

      // 2. Update local state
      setCurrentCompanyId(companyId);

      // 3. Invalidate all cached data — forces every agent
      //    dashboard to refetch with new companyId filter
      router.refresh();
    });
  }, [companies, router]);

  // ----------------------------------------------------------
  // Provide companyId to all downstream components
  // ----------------------------------------------------------
  return (
    <TenantContext.Provider
      value={{
        currentCompany,
        companies,
        switchCompany,
        isSwitching: isPending,
        companyId: currentCompanyId,
      }}
    >
      {children}
    </TenantContext.Provider>
  );
}

// ============================================================
// Hook
// ============================================================
export function useTenant() {
  const ctx = useContext(TenantContext);
  if (!ctx) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return ctx;
}

// ============================================================
// Server-side helper: Extract companyId from session/cookie
// Use in Server Components and API routes
// ============================================================
export async function getServerCompanyId(): Promise<string | null> {
  // This would read from your auth session (e.g., next-auth, cookies)
  // Implementation depends on your auth setup
  const { cookies } = await import('next/headers');
  const cookieStore = await cookies();
  return cookieStore.get('woulfai_company_id')?.value || null;
}
