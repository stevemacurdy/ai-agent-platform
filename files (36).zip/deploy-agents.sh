#!/usr/bin/env bash
# ============================================================
# WoulfAI Master Deployment Script
# Applies all agent integrations, DB migrations, and UI wiring
# ============================================================

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log()   { echo -e "${GREEN}[✓]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
error() { echo -e "${RED}[✗]${NC} $1"; }
info()  { echo -e "${BLUE}[→]${NC} $1"; }
header(){ echo -e "\n${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; echo -e "${CYAN}  $1${NC}"; echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"; }

# ============================================================
# CONFIG — Update these for your environment
# ============================================================
PROJECT_DIR="${WOULFAI_PROJECT_DIR:-/home/ubuntu/woulfai}"
DB_URL="${DATABASE_URL:-postgresql://localhost:5432/woulfai}"
DEPLOY_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="${PROJECT_DIR}/.backups/$(date +%Y%m%d_%H%M%S)"

# ============================================================
# PRE-FLIGHT CHECKS
# ============================================================
header "WoulfAI Agent Deployment — Pre-Flight"

info "Checking environment..."

# Check Node
if ! command -v node &> /dev/null; then
    error "Node.js not found. Install Node 18+ first."
    exit 1
fi
log "Node.js $(node -v)"

# Check psql
if ! command -v psql &> /dev/null; then
    warn "psql not found — will skip direct DB migration. Run SQL manually."
    SKIP_DB=true
else
    log "psql available"
    SKIP_DB=false
fi

# Check project directory
if [ ! -d "$PROJECT_DIR" ]; then
    error "Project directory not found: $PROJECT_DIR"
    error "Set WOULFAI_PROJECT_DIR env var or update the script."
    exit 1
fi
log "Project directory: $PROJECT_DIR"

# ============================================================
# STEP 1: BACKUP
# ============================================================
header "Step 1/6 — Creating Backup"

mkdir -p "$BACKUP_DIR"

# Backup key files that will be modified
FILES_TO_BACKUP=(
    "lib/agents"
    "lib/providers"
    "components/dashboard"
    "components/agents"
    "app/api/admin"
    "app/api/tenant"
)

for dir in "${FILES_TO_BACKUP[@]}"; do
    src="$PROJECT_DIR/$dir"
    if [ -d "$src" ] || [ -f "$src" ]; then
        mkdir -p "$BACKUP_DIR/$(dirname "$dir")"
        cp -r "$src" "$BACKUP_DIR/$dir" 2>/dev/null || true
        log "Backed up: $dir"
    fi
done

log "Backup saved to: $BACKUP_DIR"

# ============================================================
# STEP 2: DATABASE MIGRATION
# ============================================================
header "Step 2/6 — Running Database Migration"

if [ "$SKIP_DB" = false ]; then
    info "Applying agent tables migration..."
    psql "$DB_URL" -f "$DEPLOY_DIR/001_agent_tables_migration.sql" 2>&1 | while IFS= read -r line; do
        echo "  $line"
    done
    log "Database migration complete"
else
    warn "Skipping DB migration (psql not available)"
    warn "Run manually: psql \$DATABASE_URL -f $DEPLOY_DIR/001_agent_tables_migration.sql"
fi

# ============================================================
# STEP 3: DEPLOY SOURCE FILES
# ============================================================
header "Step 3/6 — Deploying Source Files"

# Agent Registry
mkdir -p "$PROJECT_DIR/lib/agents"
cp "$DEPLOY_DIR/lib/agents/agent-registry.ts" "$PROJECT_DIR/lib/agents/agent-registry.ts"
log "Deployed: lib/agents/agent-registry.ts"

# Tenant Provider
mkdir -p "$PROJECT_DIR/lib/providers"
cp "$DEPLOY_DIR/lib/providers/tenant-provider.tsx" "$PROJECT_DIR/lib/providers/tenant-provider.tsx"
log "Deployed: lib/providers/tenant-provider.tsx"

# Sidebar Navigation
mkdir -p "$PROJECT_DIR/components/dashboard"
cp "$DEPLOY_DIR/components/dashboard/sidebar-nav.tsx" "$PROJECT_DIR/components/dashboard/sidebar-nav.tsx"
log "Deployed: components/dashboard/sidebar-nav.tsx"

# Agent Dashboard Shell
mkdir -p "$PROJECT_DIR/components/agents"
cp "$DEPLOY_DIR/components/agents/agent-dashboard-shell.tsx" "$PROJECT_DIR/components/agents/agent-dashboard-shell.tsx"
log "Deployed: components/agents/agent-dashboard-shell.tsx"

# API Routes
mkdir -p "$PROJECT_DIR/app/api/admin/comp-agent"
cp "$DEPLOY_DIR/app/api/admin/comp-agent/route.ts" "$PROJECT_DIR/app/api/admin/comp-agent/route.ts"
log "Deployed: app/api/admin/comp-agent/route.ts"

mkdir -p "$PROJECT_DIR/app/api/tenant/switch"
cp "$DEPLOY_DIR/app/api/tenant/switch/route.ts" "$PROJECT_DIR/app/api/tenant/switch/route.ts"
log "Deployed: app/api/tenant/switch/route.ts"

# ============================================================
# STEP 4: REBRAND SCAN — "Customer" → "Organization Lead"
# ============================================================
header "Step 4/6 — Rebranding: Customer → Organization Lead"

REBRAND_COUNT=0

# Scan all .ts, .tsx, .js, .jsx files for "Customer" references
while IFS= read -r -d '' file; do
    if grep -qi '"customer"' "$file" || grep -qi "'customer'" "$file" || grep -qi "Customer" "$file"; then
        # Skip node_modules, .next, backups
        if [[ "$file" == *"node_modules"* ]] || [[ "$file" == *".next"* ]] || [[ "$file" == *".backups"* ]]; then
            continue
        fi

        # Perform replacements (case-sensitive for each variant)
        sed -i \
            -e "s/'Customer'/'Organization Lead'/g" \
            -e 's/"Customer"/"Organization Lead"/g' \
            -e "s/customer_role/org_lead_role/g" \
            -e "s/CustomerPortal/OrgLeadPortal/g" \
            -e "s/CustomerDashboard/OrgLeadDashboard/g" \
            -e "s/isCustomer/isOrgLead/g" \
            "$file"

        REBRAND_COUNT=$((REBRAND_COUNT + 1))
        log "Rebranded: ${file#$PROJECT_DIR/}"
    fi
done < <(find "$PROJECT_DIR" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/.backups/*" -print0)

if [ "$REBRAND_COUNT" -eq 0 ]; then
    log "No remaining 'Customer' references found — rebrand already complete"
else
    log "Rebranded $REBRAND_COUNT files"
fi

# ============================================================
# STEP 5: SET ALL AGENTS TO LIVE
# ============================================================
header "Step 5/6 — Activating All Agents to LIVE"

if [ "$SKIP_DB" = false ]; then
    psql "$DB_URL" -c "
        UPDATE agent_registry
        SET status = 'live', updated_at = NOW()
        WHERE status != 'live';
    " 2>/dev/null
    log "All agents set to LIVE status in database"
else
    warn "Skipping DB agent activation (run manually):"
    warn "  UPDATE agent_registry SET status = 'live' WHERE status != 'live';"
fi

# Also update the registry file to ensure consistency
info "Verifying agent-registry.ts all show status: 'live'..."
DEMO_COUNT=$(grep -c "status: 'demo'" "$PROJECT_DIR/lib/agents/agent-registry.ts" 2>/dev/null || echo "0")
if [ "$DEMO_COUNT" -gt 0 ]; then
    sed -i "s/status: 'demo'/status: 'live'/g" "$PROJECT_DIR/lib/agents/agent-registry.ts"
    log "Updated $DEMO_COUNT agents from 'demo' → 'live' in registry"
else
    log "All agents already 'live' in registry file"
fi

# ============================================================
# STEP 6: BUILD & VERIFY
# ============================================================
header "Step 6/6 — Build & Verify"

cd "$PROJECT_DIR"

info "Installing any new dependencies..."
npm install 2>/dev/null || yarn install 2>/dev/null || true

info "Running TypeScript check..."
if npx tsc --noEmit 2>/dev/null; then
    log "TypeScript: No errors"
else
    warn "TypeScript errors detected — review before deploying to prod"
fi

info "Building project..."
if npm run build 2>&1 | tail -5; then
    log "Build successful"
else
    error "Build failed — check errors above"
    warn "Backup available at: $BACKUP_DIR"
    exit 1
fi

# ============================================================
# SUMMARY
# ============================================================
header "Deployment Complete"

echo -e "
${GREEN}┌─────────────────────────────────────────────────┐${NC}
${GREEN}│        WoulfAI Agent Deployment Summary          │${NC}
${GREEN}├─────────────────────────────────────────────────┤${NC}
${GREEN}│${NC}  Agents deployed:     5 (all LIVE)               ${GREEN}│${NC}
${GREEN}│${NC}  Database migration:  $([ "$SKIP_DB" = false ] && echo "Applied ✓" || echo "Pending (manual)")              ${GREEN}│${NC}
${GREEN}│${NC}  Rebrand scan:        ${REBRAND_COUNT} files updated              ${GREEN}│${NC}
${GREEN}│${NC}  Backup location:     .backups/                  ${GREEN}│${NC}
${GREEN}│${NC}                                                   ${GREEN}│${NC}
${GREEN}│${NC}  ${CYAN}Agents:${NC}                                         ${GREEN}│${NC}
${GREEN}│${NC}   ✓ Organization Lead  (Command Center)          ${GREEN}│${NC}
${GREEN}│${NC}   ✓ SEO Agent          (Clutch Portal)           ${GREEN}│${NC}
${GREEN}│${NC}   ✓ Marketing Agent    (Clutch Portal)           ${GREEN}│${NC}
${GREEN}│${NC}   ✓ WMS Agent          (Woulf Portal)            ${GREEN}│${NC}
${GREEN}│${NC}   ✓ HR Agent           (Woulf Portal)            ${GREEN}│${NC}
${GREEN}│${NC}                                                   ${GREEN}│${NC}
${GREEN}│${NC}  ${YELLOW}Next steps:${NC}                                     ${GREEN}│${NC}
${GREEN}│${NC}   1. Comp your businesses via Admin Portal       ${GREEN}│${NC}
${GREEN}│${NC}   2. Test Business Switcher across companies     ${GREEN}│${NC}
${GREEN}│${NC}   3. Verify Odoo data sync per agent             ${GREEN}│${NC}
${GREEN}│${NC}   4. Check empty states for new accounts         ${GREEN}│${NC}
${GREEN}└─────────────────────────────────────────────────┘${NC}
"

echo -e "${CYAN}Quick Comp (run in psql):${NC}"
echo -e "  SELECT admin_comp_all_agents('<your-admin-uuid>', '<your-company-uuid>');"
echo ""
echo -e "${CYAN}Or via API:${NC}"
echo -e "  curl -X POST https://www.woulfai.com/api/admin/comp-agent \\"
echo -e "    -H 'Content-Type: application/json' \\"
echo -e "    -d '{\"companyId\": \"<uuid>\", \"compAll\": true}'"
