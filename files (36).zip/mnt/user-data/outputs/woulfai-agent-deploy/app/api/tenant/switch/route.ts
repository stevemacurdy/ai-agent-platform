// ============================================================
// app/api/tenant/switch/route.ts
// Handles company switching from the Global Business Switcher
// Sets session + cookie so all server components pick up new companyId
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { companyId } = await req.json();

    if (!companyId) {
      return NextResponse.json({ error: 'companyId is required' }, { status: 400 });
    }

    // Verify user actually belongs to this company
    // (Super Admins can access any company)
    const isSuperAdmin = session.user.roles?.includes('super_admin');

    if (!isSuperAdmin) {
      const membership = await db.query(
        `SELECT 1 FROM company_members WHERE user_id = $1 AND company_id = $2`,
        [session.user.id, companyId]
      );

      if (membership.rows.length === 0) {
        return NextResponse.json(
          { error: 'You do not have access to this company' },
          { status: 403 }
        );
      }
    }

    // Set the companyId cookie (httpOnly for security)
    const response = NextResponse.json({ success: true, companyId });

    response.cookies.set('woulfai_company_id', companyId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 30, // 30 days
    });

    // Also set the Postgres session variable for RLS
    // (This will be done per-request in middleware, but we log the switch)
    console.log(`[tenant/switch] User ${session.user.id} switched to company ${companyId}`);

    return response;

  } catch (error: any) {
    console.error('[tenant/switch] Error:', error);
    return NextResponse.json(
      { error: 'Failed to switch company' },
      { status: 500 }
    );
  }
}
