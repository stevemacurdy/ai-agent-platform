// ============================================================
// components/agents/agent-dashboard-shell.tsx
// Universal agent dashboard wrapper
// Provides: Submit, Edit, Download + Empty State + Odoo sync
// ============================================================

'use client';

import React, { useState, useCallback } from 'react';
import { Plus, Pencil, Download, Bot, Loader2, AlertCircle } from 'lucide-react';
import { useTenant } from '@/lib/providers/tenant-provider';
import { type AgentConfig } from '@/lib/agents/agent-registry';

// ============================================================
// Types
// ============================================================
interface AgentDashboardShellProps {
  agent: AgentConfig;
  subscriptionStatus: string;
  data: any[];                          // Agent-specific records
  children: React.ReactNode;            // The actual agent UI
  onSubmit?: (payload: any) => Promise<void>;
  onEdit?: (id: string, payload: any) => Promise<void>;
  onDownload?: () => Promise<void>;
}

// ============================================================
// Empty State Component
// ============================================================
function EmptyState({ agent, onAction }: { agent: AgentConfig; onAction: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 px-8">
      <div className="w-16 h-16 rounded-2xl bg-zinc-800 flex items-center justify-center mb-6">
        <Bot className="w-8 h-8 text-zinc-500" />
      </div>
      <h3 className="text-xl font-semibold text-white mb-2">
        {agent.emptyState.title}
      </h3>
      <p className="text-sm text-zinc-400 text-center max-w-md mb-6">
        {agent.emptyState.description}
      </p>
      <button
        onClick={onAction}
        className="
          inline-flex items-center gap-2 px-5 py-2.5
          bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium
          rounded-lg transition-colors
        "
      >
        <Plus className="w-4 h-4" />
        {agent.emptyState.ctaLabel}
      </button>
    </div>
  );
}

// ============================================================
// Locked State (no subscription)
// ============================================================
function LockedState({ agent }: { agent: AgentConfig }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 px-8">
      <div className="w-16 h-16 rounded-2xl bg-zinc-800/50 flex items-center justify-center mb-6">
        <AlertCircle className="w-8 h-8 text-zinc-600" />
      </div>
      <h3 className="text-xl font-semibold text-zinc-400 mb-2">
        {agent.displayName} — Access Required
      </h3>
      <p className="text-sm text-zinc-500 text-center max-w-md mb-6">
        This agent requires an active subscription or admin comp to access.
        Contact your administrator or upgrade your plan.
      </p>
    </div>
  );
}

// ============================================================
// Action Toolbar (Submit / Edit / Download)
// ============================================================
interface ActionToolbarProps {
  agent: AgentConfig;
  onSubmit: () => void;
  onDownload: () => void;
  isSubmitting: boolean;
  isDownloading: boolean;
  selectedCount: number;
}

function ActionToolbar({
  agent, onSubmit, onDownload, isSubmitting, isDownloading, selectedCount,
}: ActionToolbarProps) {
  return (
    <div className="flex items-center justify-between px-6 py-3 bg-zinc-900 border-b border-zinc-800">
      {/* Left: Agent title */}
      <div>
        <h2 className="text-lg font-semibold text-white">{agent.displayName}</h2>
        <p className="text-xs text-zinc-500">{agent.description}</p>
      </div>

      {/* Right: Action buttons */}
      <div className="flex items-center gap-2">
        {agent.features.submit && (
          <button
            onClick={onSubmit}
            disabled={isSubmitting}
            className="
              inline-flex items-center gap-2 px-4 py-2
              bg-blue-600 hover:bg-blue-500 disabled:bg-blue-600/50
              text-white text-sm font-medium rounded-lg transition-colors
            "
          >
            {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            Submit
          </button>
        )}

        {agent.features.edit && selectedCount > 0 && (
          <button
            className="
              inline-flex items-center gap-2 px-4 py-2
              bg-zinc-700 hover:bg-zinc-600
              text-white text-sm font-medium rounded-lg transition-colors
            "
          >
            <Pencil className="w-4 h-4" />
            Edit ({selectedCount})
          </button>
        )}

        {agent.features.download && (
          <button
            onClick={onDownload}
            disabled={isDownloading}
            className="
              inline-flex items-center gap-2 px-4 py-2
              bg-zinc-700 hover:bg-zinc-600 disabled:bg-zinc-700/50
              text-white text-sm font-medium rounded-lg transition-colors
            "
          >
            {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            Download
          </button>
        )}
      </div>
    </div>
  );
}

// ============================================================
// Main Shell
// ============================================================
export function AgentDashboardShell({
  agent,
  subscriptionStatus,
  data,
  children,
  onSubmit,
  onEdit,
  onDownload,
}: AgentDashboardShellProps) {
  const { companyId } = useTenant();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const isAccessible = ['active', 'comped', 'trial'].includes(subscriptionStatus);

  // ----------------------------------------------------------
  // Handlers — wired to Odoo via API routes
  // ----------------------------------------------------------
  const handleSubmit = useCallback(async () => {
    if (!onSubmit) {
      setShowCreateModal(true);
      return;
    }
    setIsSubmitting(true);
    try {
      await onSubmit({ companyId, agentSlug: agent.slug });
    } finally {
      setIsSubmitting(false);
    }
  }, [onSubmit, companyId, agent.slug]);

  const handleDownload = useCallback(async () => {
    if (!onDownload) {
      // Default: export current data as CSV
      const csvUrl = `/api/agents/${agent.slug}/export?companyId=${companyId}&format=csv`;
      window.open(csvUrl, '_blank');
      return;
    }
    setIsDownloading(true);
    try {
      await onDownload();
    } finally {
      setIsDownloading(false);
    }
  }, [onDownload, agent.slug, companyId]);

  // ----------------------------------------------------------
  // Render
  // ----------------------------------------------------------
  if (!isAccessible) {
    return <LockedState agent={agent} />;
  }

  if (!data || data.length === 0) {
    return (
      <div className="flex-1 flex flex-col">
        <ActionToolbar
          agent={agent}
          onSubmit={handleSubmit}
          onDownload={handleDownload}
          isSubmitting={isSubmitting}
          isDownloading={isDownloading}
          selectedCount={0}
        />
        <EmptyState agent={agent} onAction={handleSubmit} />
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <ActionToolbar
        agent={agent}
        onSubmit={handleSubmit}
        onDownload={handleDownload}
        isSubmitting={isSubmitting}
        isDownloading={isDownloading}
        selectedCount={selectedIds.length}
      />
      <div className="flex-1 overflow-auto p-6">
        {children}
      </div>
    </div>
  );
}
