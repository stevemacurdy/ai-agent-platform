'use client'

import { useState } from 'react'

function getEmail() {
  try { return JSON.parse(localStorage.getItem('woulfai_session') || '{}')?.user?.email || 'admin' } catch { return 'admin' }
}
const hdrs = () => ({ 'x-admin-email': getEmail(), 'Content-Type': 'application/json' })

type Step = 'initial' | 'who' | 'outcome' | 'next_steps' | 'notes' | 'receipt' | 'summary'

interface DebriefData {
  contactName: string
  contactCompany: string
  dealTitle: string
  outcome: 'positive' | 'neutral' | 'negative'
  stageUpdate: string
  nextAction: string
  nextDate: string
  notes: string
  hasReceipt: boolean
  receiptAmount: number
  receiptCategory: string
  receiptDescription: string
}

export default function VoiceDebriefPage() {
  const [step, setStep] = useState<Step>('initial')
  const [notSales, setNotSales] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [data, setData] = useState<DebriefData>({
    contactName: '', contactCompany: '', dealTitle: '', outcome: 'neutral',
    stageUpdate: '', nextAction: '', nextDate: '', notes: '',
    hasReceipt: false, receiptAmount: 0, receiptCategory: 'meals', receiptDescription: '',
  })

  const update = (fields: Partial<DebriefData>) => setData({ ...data, ...fields })

  const submitDebrief = async () => {
    setSaving(true)
    // Add activity to CRM
    await fetch('/api/crm', {
      method: 'POST', headers: hdrs(),
      body: JSON.stringify({
        action: 'add-activity',
        contactId: '', // would match by name in production
        type: 'meeting',
        description: `Post-meeting debrief: ${data.contactName} at ${data.contactCompany}. Outcome: ${data.outcome}. ${data.notes}`,
        metadata: { outcome: data.outcome, nextAction: data.nextAction, nextDate: data.nextDate },
        createdBy: getEmail(),
      }),
    })

    // Submit receipt if applicable
    if (data.hasReceipt && data.receiptAmount > 0) {
      await fetch('/api/reimbursements', {
        method: 'POST', headers: hdrs(),
        body: JSON.stringify({
          action: 'upload-receipt',
          description: data.receiptDescription || `Meeting expense — ${data.contactCompany}`,
          amount: data.receiptAmount,
          category: data.receiptCategory,
          submittedBy: getEmail(),
        }),
      })
    }

    setSaving(false)
    setSaved(true)
  }

  const OUTCOME_CONFIG = {
    positive: { color: 'border-emerald-500/30 bg-emerald-500/5', text: 'text-emerald-400', label: 'Positive — moving forward' },
    neutral: { color: 'border-amber-500/30 bg-amber-500/5', text: 'text-amber-400', label: 'Neutral — needs follow-up' },
    negative: { color: 'border-rose-500/30 bg-rose-500/5', text: 'text-rose-400', label: 'Negative — at risk' },
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="text-3xl mb-2">{'\uD83C\uDF99\uFE0F'}</div>
        <h1 className="text-xl font-bold">Field Debrief</h1>
        <p className="text-sm text-gray-500 mt-1">Quick post-meeting capture</p>
      </div>

      {/* ====== STEP: INITIAL ====== */}
      {step === 'initial' && !notSales && !saved && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-2xl p-6 text-center space-y-5">
          <div className="text-lg font-medium">Who did you just meet with?</div>
          <div className="flex flex-col gap-3">
            <button onClick={() => setStep('who')}
              className="w-full py-4 bg-blue-500/10 border border-blue-500/20 rounded-xl text-blue-400 font-medium hover:bg-blue-500/20 transition-all text-lg">
              {'\uD83E\uDD1D'} It was a sales meeting
            </button>
            <button onClick={() => setNotSales(true)}
              className="w-full py-3 bg-white/5 border border-white/10 rounded-xl text-gray-400 hover:bg-white/10 transition-all">
              Not a sales call
            </button>
          </div>
        </div>
      )}

      {notSales && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-2xl p-6 text-center">
          <div className="text-3xl mb-3">{'\uD83D\uDC4D'}</div>
          <div className="font-medium">Got it. Standing down.</div>
          <div className="text-sm text-gray-500 mt-1">No debrief needed.</div>
          <button onClick={() => { setNotSales(false); setStep('initial') }}
            className="mt-4 text-xs text-blue-400 hover:text-blue-300">Start over</button>
        </div>
      )}

      {/* ====== STEP: WHO ====== */}
      {step === 'who' && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-2xl p-6 space-y-4">
          <div className="text-sm font-semibold">Contact Details</div>
          <input value={data.contactName} onChange={e => update({ contactName: e.target.value })}
            placeholder="Contact name" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm" autoFocus />
          <input value={data.contactCompany} onChange={e => update({ contactCompany: e.target.value })}
            placeholder="Company" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm" />
          <input value={data.dealTitle} onChange={e => update({ dealTitle: e.target.value })}
            placeholder="Deal / opportunity name (optional)" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm" />
          <button onClick={() => setStep('outcome')} disabled={!data.contactName}
            className="w-full py-3 bg-blue-500 text-white rounded-xl font-medium disabled:opacity-40">Next</button>
        </div>
      )}

      {/* ====== STEP: OUTCOME ====== */}
      {step === 'outcome' && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-2xl p-6 space-y-4">
          <div className="text-sm font-semibold">How did it go?</div>
          <div className="space-y-2">
            {(['positive', 'neutral', 'negative'] as const).map(o => (
              <button key={o} onClick={() => { update({ outcome: o }); setStep('next_steps') }}
                className={'w-full py-4 rounded-xl border transition-all text-left px-4 ' +
                  (data.outcome === o ? OUTCOME_CONFIG[o].color : 'border-white/5 hover:border-white/10')}>
                <span className={'font-medium ' + OUTCOME_CONFIG[o].text}>{OUTCOME_CONFIG[o].label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ====== STEP: NEXT STEPS ====== */}
      {step === 'next_steps' && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-2xl p-6 space-y-4">
          <div className="text-sm font-semibold">What happens next?</div>
          <select value={data.stageUpdate} onChange={e => update({ stageUpdate: e.target.value })}
            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm">
            <option value="">Pipeline stage update (optional)</option>
            <option value="discovery">Move to Discovery</option>
            <option value="proposal">Move to Proposal</option>
            <option value="negotiation">Move to Negotiation</option>
            <option value="closed_won">Closed Won!</option>
            <option value="closed_lost">Closed Lost</option>
          </select>
          <input value={data.nextAction} onChange={e => update({ nextAction: e.target.value })}
            placeholder="Next action (e.g., Send proposal by Friday)" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm" />
          <input type="date" value={data.nextDate} onChange={e => update({ nextDate: e.target.value })}
            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm" />
          <button onClick={() => setStep('notes')}
            className="w-full py-3 bg-blue-500 text-white rounded-xl font-medium">Next</button>
        </div>
      )}

      {/* ====== STEP: NOTES ====== */}
      {step === 'notes' && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-2xl p-6 space-y-4">
          <div className="text-sm font-semibold">Key takeaways?</div>
          <textarea value={data.notes} onChange={e => update({ notes: e.target.value })}
            placeholder="What did you learn? Any personal details? Objections raised? Buying signals?"
            rows={5} className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm resize-none" autoFocus />
          <button onClick={() => setStep('receipt')}
            className="w-full py-3 bg-blue-500 text-white rounded-xl font-medium">Next</button>
        </div>
      )}

      {/* ====== STEP: RECEIPT ====== */}
      {step === 'receipt' && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-2xl p-6 space-y-4">
          <div className="text-sm font-semibold">Any expenses to log?</div>
          <div className="flex gap-3">
            <button onClick={() => { update({ hasReceipt: true }); }}
              className={'flex-1 py-3 rounded-xl border transition-all ' + (data.hasReceipt ? 'border-amber-500/30 bg-amber-500/5 text-amber-400' : 'border-white/5 text-gray-400 hover:border-white/10')}>
              Yes
            </button>
            <button onClick={() => { update({ hasReceipt: false }); setStep('summary') }}
              className={'flex-1 py-3 rounded-xl border transition-all ' + (!data.hasReceipt ? 'border-blue-500/30 bg-blue-500/5 text-blue-400' : 'border-white/5 text-gray-400 hover:border-white/10')}>
              No expenses
            </button>
          </div>
          {data.hasReceipt && (
            <div className="space-y-3 pt-2">
              <input value={data.receiptDescription} onChange={e => update({ receiptDescription: e.target.value })}
                placeholder="What was it for?" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm" />
              <div className="flex gap-3">
                <input type="number" value={data.receiptAmount || ''} onChange={e => update({ receiptAmount: parseFloat(e.target.value) || 0 })}
                  placeholder="Amount ($)" className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm" />
                <select value={data.receiptCategory} onChange={e => update({ receiptCategory: e.target.value })}
                  className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm">
                  <option value="meals">Meals</option><option value="travel">Travel</option>
                  <option value="lodging">Lodging</option><option value="supplies">Supplies</option>
                  <option value="mileage">Mileage</option><option value="other">Other</option>
                </select>
              </div>
              <button onClick={() => setStep('summary')}
                className="w-full py-3 bg-blue-500 text-white rounded-xl font-medium">Review</button>
            </div>
          )}
        </div>
      )}

      {/* ====== STEP: SUMMARY ====== */}
      {step === 'summary' && !saved && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-2xl p-6 space-y-4">
          <div className="text-sm font-semibold">Debrief Summary</div>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between py-1 border-b border-white/[0.03]">
              <span className="text-gray-500">Contact</span>
              <span className="font-medium">{data.contactName} at {data.contactCompany}</span>
            </div>
            {data.dealTitle && <div className="flex justify-between py-1 border-b border-white/[0.03]">
              <span className="text-gray-500">Deal</span><span>{data.dealTitle}</span>
            </div>}
            <div className="flex justify-between py-1 border-b border-white/[0.03]">
              <span className="text-gray-500">Outcome</span>
              <span className={OUTCOME_CONFIG[data.outcome].text}>{data.outcome}</span>
            </div>
            {data.stageUpdate && <div className="flex justify-between py-1 border-b border-white/[0.03]">
              <span className="text-gray-500">Stage Update</span><span className="text-blue-400">{data.stageUpdate.replace('_', ' ')}</span>
            </div>}
            {data.nextAction && <div className="flex justify-between py-1 border-b border-white/[0.03]">
              <span className="text-gray-500">Next Action</span><span>{data.nextAction}</span>
            </div>}
            {data.notes && <div className="py-1 border-b border-white/[0.03]">
              <span className="text-gray-500 text-xs">Notes:</span>
              <p className="text-gray-300 mt-1">{data.notes}</p>
            </div>}
            {data.hasReceipt && <div className="flex justify-between py-1">
              <span className="text-gray-500">Expense</span>
              <span className="font-mono">${data.receiptAmount.toFixed(2)} ({data.receiptCategory})</span>
            </div>}
          </div>
          <button onClick={submitDebrief} disabled={saving}
            className="w-full py-3 bg-emerald-500 text-white rounded-xl font-medium hover:bg-emerald-600 disabled:opacity-50">
            {saving ? 'Saving...' : 'Submit Debrief'}
          </button>
          <button onClick={() => setStep('notes')} className="w-full py-2 text-xs text-gray-500 hover:text-white">Go back</button>
        </div>
      )}

      {/* ====== SAVED ====== */}
      {saved && (
        <div className="bg-[#0A0E15] border border-emerald-500/20 rounded-2xl p-8 text-center">
          <div className="text-4xl mb-3">{'\u2705'}</div>
          <h2 className="text-lg font-bold text-emerald-400">Debrief Saved</h2>
          <p className="text-sm text-gray-400 mt-2">CRM updated. {data.hasReceipt ? 'Expense added to reimbursement batch.' : ''}</p>
          <button onClick={() => { setSaved(false); setStep('initial'); setData({ contactName: '', contactCompany: '', dealTitle: '', outcome: 'neutral', stageUpdate: '', nextAction: '', nextDate: '', notes: '', hasReceipt: false, receiptAmount: 0, receiptCategory: 'meals', receiptDescription: '' }) }}
            className="mt-4 px-6 py-2 bg-white/5 text-gray-400 rounded-lg text-sm hover:bg-white/10">New Debrief</button>
        </div>
      )}

      {/* Progress */}
      {!notSales && !saved && step !== 'initial' && (
        <div className="flex justify-center gap-1.5">
          {['who', 'outcome', 'next_steps', 'notes', 'receipt', 'summary'].map((s, i) => (
            <div key={s} className={'w-2 h-2 rounded-full transition-all ' +
              (s === step ? 'bg-blue-400 scale-125' : ['who', 'outcome', 'next_steps', 'notes', 'receipt', 'summary'].indexOf(step) > i ? 'bg-blue-400/40' : 'bg-white/10')} />
          ))}
        </div>
      )}
    </div>
  )
}
