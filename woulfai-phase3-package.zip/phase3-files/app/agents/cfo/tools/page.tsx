'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'

function getEmail() {
  try { return JSON.parse(localStorage.getItem('woulfai_session') || '{}')?.user?.email || 'admin' } catch { return 'admin' }
}
const hdrs = () => ({ 'x-admin-email': getEmail(), 'Content-Type': 'application/json' })

export default function CFOToolsPage() {
  const [tab, setTab] = useState<'scanner' | 'reimbursements'>('scanner')
  const [toast, setToast] = useState<string | null>(null)
  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 3000) }

  // ====== DOCUMENT SCANNER STATE ======
  const [scanning, setScanning] = useState(false)
  const [scanResult, setScanResult] = useState<any>(null)
  const [scannedDocs, setScannedDocs] = useState<any[]>([])
  const fileRef = useRef<HTMLInputElement>(null)

  const loadScans = async () => {
    const res = await fetch('/api/documents', { method: 'POST', headers: hdrs(), body: JSON.stringify({ action: 'list-scans' }) })
    const data = await res.json()
    setScannedDocs(data.documents || [])
  }

  const handleScan = async (file: File) => {
    setScanning(true)
    setScanResult(null)
    const reader = new FileReader()
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1] || ''
      const res = await fetch('/api/documents', {
        method: 'POST', headers: hdrs(),
        body: JSON.stringify({ action: 'scan', fileContent: base64, filename: file.name }),
      })
      const data = await res.json()
      setScanResult(data)
      setScanning(false)
      showToast('Document scanned successfully')
      loadScans()
    }
    reader.readAsDataURL(file)
  }

  const approveInvoice = async (docId: string) => {
    await fetch('/api/documents', { method: 'POST', headers: hdrs(), body: JSON.stringify({ action: 'approve-invoice', documentId: docId }) })
    showToast('Invoice approved')
    loadScans()
  }

  // ====== REIMBURSEMENTS STATE ======
  const [batches, setBatches] = useState<any[]>([])
  const [reimbLoading, setReimbLoading] = useState(true)

  const loadBatches = async () => {
    setReimbLoading(true)
    const res = await fetch('/api/reimbursements', { headers: { 'x-admin-email': getEmail() } })
    const data = await res.json()
    setBatches(data.batches || [])
    setReimbLoading(false)
  }

  const approveBatch = async (batchId: string) => {
    await fetch('/api/reimbursements', { method: 'POST', headers: hdrs(), body: JSON.stringify({ action: 'approve', batchId }) })
    showToast('Batch approved')
    loadBatches()
  }

  const rejectBatch = async (batchId: string) => {
    const reason = prompt('Rejection reason:')
    if (reason === null) return
    await fetch('/api/reimbursements', { method: 'POST', headers: hdrs(), body: JSON.stringify({ action: 'reject', batchId, reason }) })
    showToast('Batch rejected')
    loadBatches()
  }

  useEffect(() => { loadScans(); loadBatches() }, [])

  const CATEGORY_COLORS: Record<string, string> = {
    travel: 'text-blue-400 bg-blue-500/10', meals: 'text-amber-400 bg-amber-500/10',
    lodging: 'text-violet-400 bg-violet-500/10', supplies: 'text-emerald-400 bg-emerald-500/10',
    mileage: 'text-cyan-400 bg-cyan-500/10', other: 'text-gray-400 bg-gray-500/10',
  }

  return (
    <div className="max-w-[1200px] mx-auto space-y-5">
      {toast && <div className="fixed top-4 right-4 z-50 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm px-4 py-2 rounded-lg">{toast}</div>}

      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold">CFO Intelligence Tools</h1>
          <p className="text-sm text-gray-500 mt-1">Document scanning, contract analysis, and expense management</p>
        </div>
        <div className="flex gap-2">
          <Link href="/agents/cfo" className="px-3 py-1.5 text-xs text-gray-500 hover:text-white bg-white/5 rounded-lg">CFO Dashboard</Link>
          <Link href="/agents/cfo/manage" className="px-3 py-1.5 text-xs text-gray-500 hover:text-white bg-white/5 rounded-lg">Write-Back</Link>
        </div>
      </div>

      <div className="flex gap-2">
        <button onClick={() => setTab('scanner')}
          className={'px-4 py-2 rounded-lg text-sm font-medium transition-all ' + (tab === 'scanner' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5')}>
          Document Scanner
        </button>
        <button onClick={() => setTab('reimbursements')}
          className={'px-4 py-2 rounded-lg text-sm font-medium transition-all ' + (tab === 'reimbursements' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5')}>
          Reimbursements {batches.filter(b => b.status === 'pending').length > 0 &&
            <span className="ml-1.5 px-1.5 py-0.5 bg-rose-500/20 text-rose-400 text-[10px] font-mono rounded">{batches.filter(b => b.status === 'pending').length}</span>}
        </button>
      </div>

      {/* ============================================================ */}
      {/* DOCUMENT SCANNER */}
      {/* ============================================================ */}
      {tab === 'scanner' && (
        <div className="space-y-4">
          {/* Upload Zone */}
          <div className="bg-[#0A0E15] border-2 border-dashed border-amber-500/20 rounded-xl p-8 text-center hover:border-amber-500/40 transition-all cursor-pointer"
            onClick={() => fileRef.current?.click()}>
            <input ref={fileRef} type="file" accept=".pdf,.png,.jpg,.jpeg" className="hidden"
              onChange={e => e.target.files?.[0] && handleScan(e.target.files[0])} />
            {scanning ? (
              <div>
                <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                <div className="text-sm text-amber-400">Scanning document with AI...</div>
                <div className="text-xs text-gray-500 mt-1">Extracting terms, values, and line items</div>
              </div>
            ) : (
              <div>
                <div className="text-3xl mb-3">{'\uD83D\uDCC4'}</div>
                <div className="text-sm font-medium">Drop a contract, invoice, or T&amp;C document</div>
                <div className="text-xs text-gray-500 mt-1">PDF, PNG, or JPG — AI will extract terms and auto-draft an invoice</div>
              </div>
            )}
          </div>

          {/* Trump Rule Info */}
          <div className="bg-amber-500/5 border border-amber-500/10 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <span className="text-lg">{'\u2696\uFE0F'}</span>
              <div>
                <div className="text-sm font-semibold text-amber-400">Contract Trump Rule</div>
                <div className="text-xs text-gray-400 mt-1">
                  If a customer contract specifies terms that differ from our standard T&amp;Cs, the <span className="text-amber-300 font-medium">customer contract always wins</span>.
                  If no contract exists, we default to <span className="text-white font-mono">"Due Upon Ordering"</span>.
                </div>
              </div>
            </div>
          </div>

          {/* Scan Result */}
          {scanResult && (
            <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Extraction Results</h3>
                {scanResult.trumpRuleApplied && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-400">{'\u2696\uFE0F'} Customer Terms Applied</span>
                )}
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-white/[0.02] border border-white/5 rounded-lg p-3">
                  <div className="text-[10px] text-gray-500 font-mono uppercase">Vendor</div>
                  <div className="text-sm font-medium mt-1">{scanResult.extracted?.vendorName}</div>
                </div>
                <div className="bg-white/[0.02] border border-white/5 rounded-lg p-3">
                  <div className="text-[10px] text-gray-500 font-mono uppercase">Contract Value</div>
                  <div className="text-sm font-mono font-bold mt-1">${scanResult.extracted?.contractValue?.toLocaleString()}</div>
                </div>
                <div className="bg-white/[0.02] border border-white/5 rounded-lg p-3">
                  <div className="text-[10px] text-gray-500 font-mono uppercase">Payment Terms</div>
                  <div className="text-sm font-medium mt-1 text-amber-400">{scanResult.finalPaymentTerms}</div>
                </div>
                <div className="bg-white/[0.02] border border-white/5 rounded-lg p-3">
                  <div className="text-[10px] text-gray-500 font-mono uppercase">Date</div>
                  <div className="text-sm mt-1">{scanResult.extracted?.contractDate}</div>
                </div>
              </div>

              {/* Conflicts */}
              {scanResult.extracted?.conflictsWithStandard?.length > 0 && (
                <div className="bg-rose-500/5 border border-rose-500/10 rounded-lg p-3">
                  <div className="text-xs font-semibold text-rose-400 mb-2">{'\u26A0\uFE0F'} Standard T&amp;C Conflicts (Customer Contract Wins)</div>
                  {scanResult.extracted.conflictsWithStandard.map((c: any, i: number) => (
                    <div key={i} className="flex items-center gap-3 py-1 text-xs">
                      <span className="text-gray-500 w-32">{c.field}</span>
                      <span className="text-gray-600 line-through">{c.standard}</span>
                      <span className="text-gray-400">{'\u2192'}</span>
                      <span className="text-amber-400 font-medium">{c.contract}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Line Items */}
              {scanResult.extracted?.lineItems?.length > 0 && (
                <div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Extracted Line Items</div>
                  <table className="w-full text-sm">
                    <thead><tr className="text-[10px] text-gray-500 uppercase border-b border-white/5">
                      <th className="text-left py-2">Description</th><th className="text-right py-2">Qty</th>
                      <th className="text-right py-2">Unit Price</th><th className="text-right py-2">Total</th>
                    </tr></thead>
                    <tbody>
                      {scanResult.extracted.lineItems.map((l: any, i: number) => (
                        <tr key={i} className="border-b border-white/[0.03]">
                          <td className="py-2 text-gray-300">{l.description}</td>
                          <td className="py-2 text-right font-mono">{l.quantity}</td>
                          <td className="py-2 text-right font-mono">${l.unitPrice?.toLocaleString()}</td>
                          <td className="py-2 text-right font-mono font-bold">${(l.quantity * l.unitPrice).toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="flex gap-3 pt-3 border-t border-white/5">
                <button onClick={() => approveInvoice(scanResult.id)}
                  className="px-4 py-2 bg-emerald-500 text-white rounded-lg text-sm font-medium hover:bg-emerald-600">
                  Approve &amp; Create in Odoo
                </button>
                <button onClick={() => { setScanResult(null) }}
                  className="px-4 py-2 bg-white/5 text-gray-400 rounded-lg text-sm hover:bg-white/10">
                  Dismiss
                </button>
              </div>
            </div>
          )}

          {/* Previous Scans */}
          {scannedDocs.length > 0 && (
            <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
              <h3 className="text-sm font-semibold mb-3">Previous Scans</h3>
              <div className="space-y-2">
                {scannedDocs.map((doc: any) => (
                  <div key={doc.id} className="flex items-center justify-between py-2 border-b border-white/[0.03] last:border-0">
                    <div>
                      <div className="text-sm">{doc.filename}</div>
                      <div className="text-[10px] text-gray-500 font-mono">{doc.extracted?.vendorName} — ${doc.extracted?.contractValue?.toLocaleString()}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      {doc.trumpRuleApplied && <span className="text-[9px] text-amber-400 font-mono">TRUMP</span>}
                      <span className={'text-[10px] font-mono px-2 py-0.5 rounded ' +
                        (doc.draftInvoice?.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400' :
                         doc.draftInvoice?.status === 'rejected' ? 'bg-rose-500/10 text-rose-400' : 'bg-amber-500/10 text-amber-400')}>
                        {doc.draftInvoice?.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============================================================ */}
      {/* REIMBURSEMENTS */}
      {/* ============================================================ */}
      {tab === 'reimbursements' && (
        <div className="space-y-4">
          {/* Summary */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-gradient-to-br from-amber-500/10 to-amber-500/5 border border-amber-500/20 rounded-xl p-4">
              <div className="text-[10px] text-gray-400 uppercase tracking-wider font-mono mb-1">Pending Review</div>
              <div className="text-2xl font-bold text-amber-400">${batches.filter(b => b.status === 'pending').reduce((s: number, b: any) => s + b.totalAmount, 0).toFixed(2)}</div>
              <div className="text-xs text-gray-500 mt-1">{batches.filter(b => b.status === 'pending').length} batches</div>
            </div>
            <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/20 rounded-xl p-4">
              <div className="text-[10px] text-gray-400 uppercase tracking-wider font-mono mb-1">Approved</div>
              <div className="text-2xl font-bold text-emerald-400">${batches.filter(b => b.status === 'approved').reduce((s: number, b: any) => s + b.totalAmount, 0).toFixed(2)}</div>
              <div className="text-xs text-gray-500 mt-1">{batches.filter(b => b.status === 'approved').length} batches</div>
            </div>
            <div className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border border-blue-500/20 rounded-xl p-4">
              <div className="text-[10px] text-gray-400 uppercase tracking-wider font-mono mb-1">All-Time Total</div>
              <div className="text-2xl font-bold">${batches.reduce((s: number, b: any) => s + b.totalAmount, 0).toFixed(2)}</div>
              <div className="text-xs text-gray-500 mt-1">{batches.length} total batches</div>
            </div>
          </div>

          {/* Batch List */}
          {reimbLoading ? (
            <div className="flex items-center justify-center py-10">
              <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : batches.map((batch: any) => (
            <div key={batch.id} className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="flex items-center gap-3">
                    <h3 className="font-medium">{batch.submittedBy}</h3>
                    <span className="text-xs text-gray-500 font-mono">{batch.batchMonth}</span>
                    <span className={'text-[10px] font-mono px-2 py-0.5 rounded ' +
                      (batch.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400' :
                       batch.status === 'rejected' ? 'bg-rose-500/10 text-rose-400' :
                       batch.status === 'paid' ? 'bg-blue-500/10 text-blue-400' : 'bg-amber-500/10 text-amber-400')}>
                      {batch.status}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 mt-0.5">{batch.items.length} receipts</div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-mono font-bold">${batch.totalAmount.toFixed(2)}</div>
                  {batch.status === 'pending' && (
                    <div className="flex gap-2 mt-2">
                      <button onClick={() => approveBatch(batch.id)}
                        className="px-3 py-1 bg-emerald-500 text-white rounded text-xs hover:bg-emerald-600">Approve</button>
                      <button onClick={() => rejectBatch(batch.id)}
                        className="px-3 py-1 bg-rose-500/10 text-rose-400 rounded text-xs hover:bg-rose-500/20">Reject</button>
                    </div>
                  )}
                </div>
              </div>

              {/* Receipt Items */}
              <div className="border-t border-white/5 pt-3 space-y-2">
                {batch.items.map((item: any) => (
                  <div key={item.id} className="flex items-center justify-between py-1.5">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <span className={'text-[10px] font-mono px-1.5 py-0.5 rounded ' + (CATEGORY_COLORS[item.category] || CATEGORY_COLORS.other)}>
                        {item.category}
                      </span>
                      <span className="text-sm text-gray-300 truncate">{item.description}</span>
                    </div>
                    <div className="flex items-center gap-4 flex-shrink-0">
                      <span className="text-xs text-gray-500 font-mono">{item.date}</span>
                      <span className="text-sm font-mono font-bold">${item.amount.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>

              {batch.approvedBy && (
                <div className="mt-2 pt-2 border-t border-white/5 text-[10px] text-gray-500">
                  Approved by {batch.approvedBy} on {new Date(batch.approvedAt).toLocaleDateString()}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
