import { NextRequest, NextResponse } from 'next/server';

const ADMINS = ['steve@woulfgroup.com', 'stevemacurdy@gmail.com', 'admin'];
function isAuth(req: NextRequest) {
  const e = req.headers.get('x-admin-email');
  return e && ADMINS.includes(e.toLowerCase());
}

// ============================================================================
// STANDARD T&Cs — These are the defaults. Customer contracts TRUMP these.
// If NO contract exists → "Due Upon Ordering"
// ============================================================================
const STANDARD_TERMS = {
  paymentTerms: 'Due Upon Ordering',
  lateFee: '1.5% per month',
  currency: 'USD',
  warranty: '30 days',
  cancellationNotice: '30 days written notice',
};

interface ExtractedTerms {
  vendorName: string;
  contractDate: string;
  contractValue: number;
  paymentTerms: string;
  lineItems: { description: string; quantity: number; unitPrice: number }[];
  specialConditions: string[];
  conflictsWithStandard: { field: string; standard: string; contract: string }[];
  appliedTerms: string; // 'customer_contract' | 'standard' | 'due_upon_ordering'
}

// Analyze document with OpenAI
async function analyzeDocument(base64Content: string, filename: string): Promise<ExtractedTerms> {
  const OPENAI_KEY = process.env.OPENAI_API_KEY;

  if (!OPENAI_KEY) {
    // Return mock extraction for demo
    return {
      vendorName: 'Extracted Corp (Demo)',
      contractDate: new Date().toISOString().split('T')[0],
      contractValue: 15000,
      paymentTerms: 'Net 30',
      lineItems: [
        { description: 'Enterprise License — Annual', quantity: 1, unitPrice: 12000 },
        { description: 'Implementation Fee', quantity: 1, unitPrice: 3000 },
      ],
      specialConditions: ['Auto-renewal at end of term', '90-day termination notice required'],
      conflictsWithStandard: [
        { field: 'Payment Terms', standard: 'Due Upon Ordering', contract: 'Net 30' },
        { field: 'Cancellation Notice', standard: '30 days written notice', contract: '90-day termination notice' },
      ],
      appliedTerms: 'customer_contract',
    };
  }

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `You are a contract analysis AI. Extract key commercial terms from documents.
Our STANDARD terms are: ${JSON.stringify(STANDARD_TERMS)}
TRUMP RULE: If the customer contract specifies different terms, the CUSTOMER CONTRACT wins.
If no contract exists, default to "Due Upon Ordering."
Return ONLY valid JSON.`,
          },
          {
            role: 'user',
            content: `Analyze this document (filename: ${filename}). The content is base64-encoded.
Extract: vendor name, contract date, total value, payment terms, line items, special conditions.
Flag any conflicts with our standard T&Cs.

Return JSON:
{
  "vendorName": "",
  "contractDate": "",
  "contractValue": 0,
  "paymentTerms": "",
  "lineItems": [{"description":"","quantity":1,"unitPrice":0}],
  "specialConditions": [],
  "conflictsWithStandard": [{"field":"","standard":"","contract":""}],
  "appliedTerms": "customer_contract or standard or due_upon_ordering"
}

Document content (first 4000 chars of base64): ${base64Content.substring(0, 4000)}`,
          },
        ],
        temperature: 0.3,
        max_tokens: 1000,
      }),
    });
    const data = await res.json();
    const text = data.choices?.[0]?.message?.content || '';
    const clean = text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch (err) {
    console.error('Document analysis failed:', err);
    return {
      vendorName: 'Unknown (Extraction Failed)',
      contractDate: new Date().toISOString().split('T')[0],
      contractValue: 0,
      paymentTerms: STANDARD_TERMS.paymentTerms,
      lineItems: [],
      specialConditions: [],
      conflictsWithStandard: [],
      appliedTerms: 'due_upon_ordering',
    };
  }
}

// In-memory store for scanned documents
let scannedDocuments: any[] = [];

export async function POST(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });

  const body = await request.json();

  switch (body.action) {
    case 'scan': {
      if (!body.fileContent || !body.filename) {
        return NextResponse.json({ error: 'fileContent (base64) and filename required' }, { status: 400 });
      }

      const extracted = await analyzeDocument(body.fileContent, body.filename);

      // Apply Trump Rule
      let finalTerms = STANDARD_TERMS.paymentTerms;
      if (extracted.appliedTerms === 'customer_contract' && extracted.paymentTerms) {
        finalTerms = extracted.paymentTerms; // Customer contract wins
      } else if (extracted.appliedTerms === 'due_upon_ordering' || !extracted.paymentTerms) {
        finalTerms = 'Due Upon Ordering'; // No contract → default
      }

      const doc = {
        id: 'doc-' + Date.now(),
        filename: body.filename,
        scannedAt: new Date().toISOString(),
        extracted,
        finalPaymentTerms: finalTerms,
        trumpRuleApplied: extracted.appliedTerms === 'customer_contract',
        draftInvoice: {
          partnerId: body.partnerId || null,
          partnerName: extracted.vendorName,
          lines: extracted.lineItems,
          totalValue: extracted.contractValue,
          paymentTerms: finalTerms,
          status: 'draft',
        },
      };

      scannedDocuments.push(doc);
      return NextResponse.json(doc);
    }

    case 'list-scans': {
      return NextResponse.json({ documents: scannedDocuments });
    }

    case 'approve-invoice': {
      const docIdx = scannedDocuments.findIndex(d => d.id === body.documentId);
      if (docIdx === -1) return NextResponse.json({ error: 'Document not found' }, { status: 404 });

      // In production, this would call the Odoo createInvoice API
      scannedDocuments[docIdx].draftInvoice.status = 'approved';
      scannedDocuments[docIdx].draftInvoice.approvedAt = new Date().toISOString();
      scannedDocuments[docIdx].draftInvoice.approvedBy = request.headers.get('x-admin-email');

      return NextResponse.json({
        message: 'Invoice approved and ready for Odoo sync',
        document: scannedDocuments[docIdx],
      });
    }

    case 'reject-invoice': {
      const docIdx = scannedDocuments.findIndex(d => d.id === body.documentId);
      if (docIdx === -1) return NextResponse.json({ error: 'Document not found' }, { status: 404 });
      scannedDocuments[docIdx].draftInvoice.status = 'rejected';
      scannedDocuments[docIdx].draftInvoice.rejectedReason = body.reason || '';
      return NextResponse.json({ document: scannedDocuments[docIdx] });
    }

    default:
      return NextResponse.json({ error: 'Unknown action. Use: scan, list-scans, approve-invoice, reject-invoice' }, { status: 400 });
  }
}
