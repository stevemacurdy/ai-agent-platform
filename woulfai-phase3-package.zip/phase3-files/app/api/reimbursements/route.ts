import { NextRequest, NextResponse } from 'next/server';

const ADMINS = ['steve@woulfgroup.com', 'stevemacurdy@gmail.com', 'admin'];
function isAuth(req: NextRequest) {
  const e = req.headers.get('x-admin-email');
  return e && ADMINS.includes(e.toLowerCase());
}

interface ReceiptItem {
  id: string;
  description: string;
  amount: number;
  category: 'travel' | 'meals' | 'lodging' | 'supplies' | 'mileage' | 'other';
  date: string;
  receiptImage: string; // base64 or URL
  ocrData: any;
  submittedBy: string;
  submittedAt: string;
}

interface ReimbursementBatch {
  id: string;
  batchMonth: string; // '2026-02'
  submittedBy: string;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  items: ReceiptItem[];
  totalAmount: number;
  approvedBy: string | null;
  approvedAt: string | null;
  notes: string;
}

let batches: ReimbursementBatch[] = [
  {
    id: 'rb-1', batchMonth: '2026-01', submittedBy: 'Marcus Williams', status: 'approved',
    items: [
      { id: 'ri-1', description: 'Client lunch — James Patterson (Logicorp)', amount: 87.50, category: 'meals', date: '2026-01-10', receiptImage: '', ocrData: { merchant: 'The Capital Grille', tax: 7.23, tip: 15.00 }, submittedBy: 'Marcus Williams', submittedAt: '2026-01-11T09:00:00Z' },
      { id: 'ri-2', description: 'Uber to Logicorp office', amount: 34.20, category: 'travel', date: '2026-01-10', receiptImage: '', ocrData: { merchant: 'Uber', pickup: '100 Main St', dropoff: '500 Commerce Dr' }, submittedBy: 'Marcus Williams', submittedAt: '2026-01-11T09:05:00Z' },
      { id: 'ri-3', description: 'Hotel — GreenLeaf Supply visit', amount: 189.00, category: 'lodging', date: '2026-01-14', receiptImage: '', ocrData: { merchant: 'Hampton Inn', nights: 1 }, submittedBy: 'Marcus Williams', submittedAt: '2026-01-15T08:00:00Z' },
    ],
    totalAmount: 310.70, approvedBy: 'Steve Macurdy', approvedAt: '2026-01-20T16:00:00Z', notes: '',
  },
  {
    id: 'rb-2', batchMonth: '2026-02', submittedBy: 'Sarah Chen', status: 'pending',
    items: [
      { id: 'ri-4', description: 'Flight to NYC — Pinnacle Group demo', amount: 342.00, category: 'travel', date: '2026-01-08', receiptImage: '', ocrData: { merchant: 'Delta Airlines', flight: 'DL 1247', route: 'SFO→JFK' }, submittedBy: 'Sarah Chen', submittedAt: '2026-01-09T07:00:00Z' },
      { id: 'ri-5', description: 'Dinner with Maria Santos team', amount: 156.80, category: 'meals', date: '2026-01-08', receiptImage: '', ocrData: { merchant: 'Nobu Downtown', tax: 13.20, tip: 28.00 }, submittedBy: 'Sarah Chen', submittedAt: '2026-01-09T07:10:00Z' },
      { id: 'ri-6', description: 'Taxi JFK→Manhattan', amount: 62.00, category: 'travel', date: '2026-01-08', receiptImage: '', ocrData: { merchant: 'NYC Yellow Cab' }, submittedBy: 'Sarah Chen', submittedAt: '2026-01-09T07:15:00Z' },
    ],
    totalAmount: 560.80, approvedBy: null, approvedAt: null, notes: '',
  },
  {
    id: 'rb-3', batchMonth: '2026-02', submittedBy: 'Marcus Williams', status: 'pending',
    items: [
      { id: 'ri-7', description: 'Mileage — GreenLeaf factory visit (85 miles)', amount: 55.25, category: 'mileage', date: '2026-02-05', receiptImage: '', ocrData: { miles: 85, rate: 0.65 }, submittedBy: 'Marcus Williams', submittedAt: '2026-02-06T09:00:00Z' },
      { id: 'ri-8', description: 'Office supplies for demo kit', amount: 43.99, category: 'supplies', date: '2026-02-08', receiptImage: '', ocrData: { merchant: 'Staples', items: ['presentation folders', 'USB drives'] }, submittedBy: 'Marcus Williams', submittedAt: '2026-02-09T10:00:00Z' },
    ],
    totalAmount: 99.24, approvedBy: null, approvedAt: null, notes: '',
  },
];

// OCR receipt extraction (uses OpenAI or returns mock)
async function ocrReceipt(base64Image: string): Promise<any> {
  const OPENAI_KEY = process.env.OPENAI_API_KEY;
  if (!OPENAI_KEY) {
    return {
      merchant: 'Auto-Detected Merchant',
      date: new Date().toISOString().split('T')[0],
      total: 0,
      tax: 0,
      category: 'other',
      items: [],
      confidence: 0.85,
    };
  }

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'Extract receipt data. Return ONLY JSON: {"merchant":"","date":"YYYY-MM-DD","total":0,"tax":0,"category":"meals|travel|lodging|supplies|mileage|other","items":[],"confidence":0.0}' },
          { role: 'user', content: `OCR this receipt image (base64): ${base64Image.substring(0, 2000)}` },
        ],
        temperature: 0.2,
        max_tokens: 500,
      }),
    });
    const data = await res.json();
    const text = data.choices?.[0]?.message?.content || '';
    return JSON.parse(text.replace(/```json|```/g, '').trim());
  } catch {
    return { merchant: 'Unknown', date: new Date().toISOString().split('T')[0], total: 0, tax: 0, category: 'other', items: [], confidence: 0 };
  }
}

export async function GET(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const { searchParams } = new URL(request.url);
  const view = searchParams.get('view');

  if (view === 'pending') {
    return NextResponse.json({ batches: batches.filter(b => b.status === 'pending') });
  }
  if (view === 'summary') {
    const pending = batches.filter(b => b.status === 'pending');
    const approved = batches.filter(b => b.status === 'approved');
    return NextResponse.json({
      pendingCount: pending.length,
      pendingTotal: pending.reduce((s, b) => s + b.totalAmount, 0),
      approvedCount: approved.length,
      approvedTotal: approved.reduce((s, b) => s + b.totalAmount, 0),
      allTimePaid: batches.filter(b => b.status === 'paid').reduce((s, b) => s + b.totalAmount, 0),
    });
  }
  return NextResponse.json({ batches });
}

export async function POST(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const body = await request.json();

  switch (body.action) {
    case 'upload-receipt': {
      const ocrResult = await ocrReceipt(body.receiptImage || '');
      const item: ReceiptItem = {
        id: 'ri-' + Date.now(),
        description: body.description || ocrResult.merchant || 'Receipt',
        amount: body.amount || ocrResult.total || 0,
        category: body.category || ocrResult.category || 'other',
        date: body.date || ocrResult.date || new Date().toISOString().split('T')[0],
        receiptImage: body.receiptImage || '',
        ocrData: ocrResult,
        submittedBy: body.submittedBy || 'Admin',
        submittedAt: new Date().toISOString(),
      };

      // Find or create current month batch
      const month = new Date().toISOString().substring(0, 7);
      let batch = batches.find(b => b.batchMonth === month && b.submittedBy === item.submittedBy && b.status === 'pending');
      if (!batch) {
        batch = { id: 'rb-' + Date.now(), batchMonth: month, submittedBy: item.submittedBy, status: 'pending', items: [], totalAmount: 0, approvedBy: null, approvedAt: null, notes: '' };
        batches.push(batch);
      }
      batch.items.push(item);
      batch.totalAmount = batch.items.reduce((s, i) => s + i.amount, 0);

      return NextResponse.json({ item, batch, ocrData: ocrResult });
    }

    case 'approve': {
      const idx = batches.findIndex(b => b.id === body.batchId);
      if (idx === -1) return NextResponse.json({ error: 'Batch not found' }, { status: 404 });
      batches[idx].status = 'approved';
      batches[idx].approvedBy = request.headers.get('x-admin-email') || 'Admin';
      batches[idx].approvedAt = new Date().toISOString();
      batches[idx].notes = body.notes || '';
      return NextResponse.json({ batch: batches[idx] });
    }

    case 'reject': {
      const idx = batches.findIndex(b => b.id === body.batchId);
      if (idx === -1) return NextResponse.json({ error: 'Batch not found' }, { status: 404 });
      batches[idx].status = 'rejected';
      batches[idx].notes = body.reason || '';
      return NextResponse.json({ batch: batches[idx] });
    }

    case 'mark-paid': {
      const idx = batches.findIndex(b => b.id === body.batchId);
      if (idx === -1) return NextResponse.json({ error: 'Batch not found' }, { status: 404 });
      batches[idx].status = 'paid';
      return NextResponse.json({ batch: batches[idx] });
    }

    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
