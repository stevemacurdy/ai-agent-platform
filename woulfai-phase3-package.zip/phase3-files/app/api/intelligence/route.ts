import { NextRequest, NextResponse } from 'next/server';

const ADMINS = ['steve@woulfgroup.com', 'stevemacurdy@gmail.com', 'admin'];
function isAuth(req: NextRequest) {
  const e = req.headers.get('x-admin-email');
  return e && ADMINS.includes(e.toLowerCase());
}

// AI Personality Profiling via OpenAI
async function analyzePersonality(contact: any, activities: any[]): Promise<any> {
  const OPENAI_KEY = process.env.OPENAI_API_KEY;
  if (!OPENAI_KEY) return generateFallbackProfile(contact, activities);

  const activitySummary = activities.slice(0, 10).map(a =>
    `[${a.type}] ${a.description} (by ${a.createdBy}, ${a.createdAt})`
  ).join('\n');

  const prompt = `You are a sales intelligence analyst. Based on the following contact information and interaction history, generate a JSON personality profile.

CONTACT:
Name: ${contact.name}
Title: ${contact.title} at ${contact.company}
Bio Notes: ${contact.bioNotes || 'None'}
Source: ${contact.source}
Total Revenue: $${contact.totalRevenue}
Lifetime Value: $${contact.lifetimeValue}

INTERACTION HISTORY:
${activitySummary || 'No interactions recorded yet.'}

Return ONLY valid JSON with this structure:
{
  "personalityType": "one of: Analytical, Driver, Expressive, Amiable",
  "buyingStyle": "2-3 sentence description of how they make purchasing decisions",
  "communicationPreference": "email/slack/phone/in-person",
  "decisionSpeed": "fast/moderate/slow",
  "riskTolerance": "high/medium/low",
  "doList": ["5 specific things the salesman SHOULD do"],
  "dontList": ["5 specific things the salesman should NEVER do"],
  "negotiationTips": "2-3 sentences on how to negotiate with this person",
  "relationshipStrength": "strong/growing/new/at-risk",
  "nextBestAction": "The single most important next step",
  "keyMotivators": ["3 things that drive their decisions"],
  "objectionPredictions": ["3 likely objections and how to handle them"]
}`;

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });
    const data = await res.json();
    const text = data.choices?.[0]?.message?.content || '';
    const clean = text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch (err) {
    console.error('OpenAI personality analysis failed:', err);
    return generateFallbackProfile(contact, activities);
  }
}

// Fallback when no OpenAI key
function generateFallbackProfile(contact: any, activities: any[]) {
  const hasMultipleDeals = contact.lifetimeValue > 20000;
  const meetingCount = activities.filter((a: any) => a.type === 'meeting').length;
  const isDataDriven = (contact.bioNotes || '').toLowerCase().includes('data') || (contact.bioNotes || '').toLowerCase().includes('roi');
  const isFastMover = (contact.bioNotes || '').toLowerCase().includes('fast') || (contact.bioNotes || '').toLowerCase().includes('quick');
  const isCautious = (contact.bioNotes || '').toLowerCase().includes('cautious') || (contact.bioNotes || '').toLowerCase().includes('slow');

  return {
    personalityType: isDataDriven ? 'Analytical' : isFastMover ? 'Driver' : isCautious ? 'Amiable' : 'Expressive',
    buyingStyle: isFastMover
      ? 'Makes decisions quickly when presented with clear ROI. Prefers concise proposals over lengthy documentation.'
      : isCautious
      ? 'Requires extensive validation and proof before committing. Expects detailed documentation and references.'
      : 'Balanced decision-maker who values both relationships and data. Responds well to case studies.',
    communicationPreference: (contact.bioNotes || '').includes('Slack') ? 'slack' : (contact.bioNotes || '').includes('in-person') ? 'in-person' : 'email',
    decisionSpeed: isFastMover ? 'fast' : isCautious ? 'slow' : 'moderate',
    riskTolerance: isFastMover ? 'high' : isCautious ? 'low' : 'medium',
    doList: [
      isDataDriven ? 'Lead with ROI numbers and concrete metrics' : 'Build personal rapport before pitching',
      hasMultipleDeals ? 'Reference their positive history with us' : 'Start with a small pilot program',
      'Research their company news before every call',
      (contact.bioNotes || '').includes('golf') ? 'Suggest a golf meeting for relationship building' : 'Find shared personal interests',
      'Send a follow-up within 24 hours of every interaction',
    ],
    dontList: [
      isFastMover ? 'Never waste their time with unnecessary details' : 'Never rush the decision process',
      isCautious ? 'Never make claims without data to back them up' : 'Never be overly formal or rigid',
      'Never bad-mouth competitors directly',
      'Never skip the agreed-upon follow-up',
      (contact.bioNotes || '').includes('board') ? 'Never bypass them to reach the board directly' : 'Never assume they are the sole decision maker',
    ],
    negotiationTips: isFastMover
      ? 'Come with a strong opening offer. They respect confidence. Be ready to close in one meeting.'
      : isCautious
      ? 'Prepare a phased approach. Offer a trial period. Bring references from similar companies.'
      : 'Balance relationship warmth with clear business value. Multi-touch approach works best.',
    relationshipStrength: hasMultipleDeals ? 'strong' : meetingCount > 2 ? 'growing' : activities.length > 0 ? 'new' : 'at-risk',
    nextBestAction: hasMultipleDeals
      ? 'Schedule upsell conversation for additional agents'
      : meetingCount === 0
      ? 'Book initial discovery call this week'
      : 'Send personalized follow-up with relevant case study',
    keyMotivators: [
      isDataDriven ? 'Measurable ROI and cost savings' : 'Innovation and competitive advantage',
      'Operational efficiency gains',
      isCautious ? 'Risk mitigation and proven track record' : 'Speed to value and quick wins',
    ],
    objectionPredictions: [
      { objection: 'Price is too high', response: 'Focus on total cost of ownership and ROI timeline' },
      { objection: 'Need to evaluate alternatives', response: hasMultipleDeals ? 'Highlight switching costs and our track record' : 'Offer a side-by-side comparison framework' },
      { objection: 'Need internal approval', response: 'Offer to present directly to decision-makers or provide executive summary' },
    ],
  };
}

// Reality Potential Score (AI-calculated)
function calculateRealityScore(contact: any, deals: any[], activities: any[]): {
  score: number; factors: { label: string; value: number; max: number }[];
} {
  const closedDeals = deals.filter((d: any) => d.stage === 'closed_won');
  const openDeals = deals.filter((d: any) => !d.stage.startsWith('closed'));
  const recentActivity = activities.filter((a: any) => {
    const d = new Date(a.createdAt);
    const now = new Date();
    return (now.getTime() - d.getTime()) < 30 * 24 * 60 * 60 * 1000;
  });

  const factors = [
    { label: 'Revenue History', value: Math.min(closedDeals.length * 15, 30), max: 30 },
    { label: 'Engagement Recency', value: Math.min(recentActivity.length * 5, 20), max: 20 },
    { label: 'Pipeline Momentum', value: Math.min(openDeals.reduce((s: number, d: any) => s + d.probability, 0) / Math.max(openDeals.length, 1) * 0.25, 25), max: 25 },
    { label: 'Relationship Depth', value: Math.min(activities.length * 2, 15), max: 15 },
    { label: 'Lifetime Value Signal', value: contact.lifetimeValue > 40000 ? 10 : contact.lifetimeValue > 10000 ? 6 : 3, max: 10 },
  ];

  return { score: Math.min(99, Math.round(factors.reduce((s, f) => s + f.value, 0))), factors };
}

export async function GET(request: NextRequest) {
  if (!isAuth(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  const { searchParams } = new URL(request.url);
  const contactId = searchParams.get('contactId');
  const action = searchParams.get('action') || 'profile';

  if (!contactId) return NextResponse.json({ error: 'contactId required' }, { status: 400 });

  // Fetch contact data from CRM API (internal call)
  const baseUrl = request.nextUrl.origin;
  const email = request.headers.get('x-admin-email') || '';
  const crmRes = await fetch(`${baseUrl}/api/crm?action=contact&id=${contactId}`, {
    headers: { 'x-admin-email': email },
  });
  const crmData = await crmRes.json();
  if (!crmData.contact) return NextResponse.json({ error: 'Contact not found' }, { status: 404 });

  switch (action) {
    case 'profile': {
      const personality = await analyzePersonality(crmData.contact, crmData.activities || []);
      const reality = calculateRealityScore(crmData.contact, crmData.deals || [], crmData.activities || []);
      return NextResponse.json({ personality, realityScore: reality, contact: crmData.contact });
    }
    case 'score': {
      const reality = calculateRealityScore(crmData.contact, crmData.deals || [], crmData.activities || []);
      return NextResponse.json({ realityScore: reality });
    }
    default:
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
