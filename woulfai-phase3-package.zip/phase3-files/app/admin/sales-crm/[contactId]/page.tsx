'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useParams } from 'next/navigation'

function getEmail() {
  try { return JSON.parse(localStorage.getItem('woulfai_session') || '{}')?.user?.email || 'admin' } catch { return 'admin' }
}
const hdrs = () => ({ 'x-admin-email': getEmail(), 'Content-Type': 'application/json' })

async function crmGet(action: string, params: Record<string, string> = {}) {
  const qs = new URLSearchParams({ action, ...params }).toString()
  return (await fetch('/api/crm?' + qs, { headers: hdrs() })).json()
}
async function crmPost(data: any) {
  return (await fetch('/api/crm', { method: 'POST', headers: hdrs(), body: JSON.stringify(data) })).json()
}
async function intelGet(contactId: string) {
  return (await fetch('/api/intelligence?action=profile&contactId=' + contactId, { headers: hdrs() })).json()
}

const STAGE_COLORS: Record<string, string> = {
  prospecting: 'text-gray-400 bg-gray-500/10', discovery: 'text-blue-400 bg-blue-500/10',
  proposal: 'text-violet-400 bg-violet-500/10', negotiation: 'text-amber-400 bg-amber-500/10',
  closed_won: 'text-emerald-400 bg-emerald-500/10', closed_lost: 'text-rose-400 bg-rose-500/10',
}
const ACT_ICONS: Record<string, string> = {
  meeting: '\uD83E\uDD1D', call: '\uD83D\uDCDE', email: '\uD83D\uDCE7',
  note: '\uD83D\uDCDD', stage_change: '\u27A1\uFE0F', document: '\uD83D\uDCC4',
}
const PERSONALITY_COLORS: Record<string, string> = {
  Analytical: 'from-blue-500/20 to-cyan-500/20 border-blue-500/30',
  Driver: 'from-rose-500/20 to-amber-500/20 border-rose-500/30',
  Expressive: 'from-violet-500/20 to-pink-500/20 border-violet-500/30',
  Amiable: 'from-emerald-500/20 to-teal-500/20 border-emerald-500/30',
}

export default function ContactProfilePage() {
  const { contactId } = useParams() as { contactId: string }
  const [contact, setContact] = useState<any>(null)
  const [deals, setDeals] = useState<any[]>([])
  const [activities, setActivities] = useState<any[]>([])
  const [intel, setIntel] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [intelLoading, setIntelLoading] = useState(false)
  const [tab, setTab] = useState<'intel' | 'deals' | 'activity' | 'edit'>('intel')
  const [toast, setToast] = useState<string | null>(null)
  const [newAct, setNewAct] = useState({ type: 'note', description: '', dealId: '' })
  const [drilldown, setDrilldown] = useState<{ title: string; items: any[] } | null>(null)

  const load = async () => {
    setLoading(true)
    const data = await crmGet('contact', { id: contactId })
    setContact(data.contact); setDeals(data.deals || []); setActivities(data.activities || [])
    setLoading(false)
  }

  const loadIntel = async () => {
    setIntelLoading(true)
    const data = await intelGet(contactId)
    setIntel(data)
    setIntelLoading(false)
  }

  useEffect(() => { load().then(loadIntel) }, [contactId])

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 3000) }

  const addActivity = async () => {
    if (!newAct.description) return
    await crmPost({ action: 'add-activity', contactId, ...newAct })
    setNewAct({ type: 'note', description: '', dealId: '' })
    showToast('Activity logged'); load()
  }

  const saveContact = async () => {
    const updates: any = {}
    ;['name', 'email', 'phone', 'title', 'bioNotes'].forEach(f => {
      const el = document.getElementById('edit-' + f) as HTMLInputElement | HTMLTextAreaElement
      if (el) updates[f] = el.value
    })
    await crmPost({ action: 'update-contact', contactId, updates })
    showToast('Contact updated'); setTab('intel'); load().then(loadIntel)
  }

  if (loading || !contact) return (
    <div className="flex items-center justify-center py-20">
      <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  const totalDealValue = deals.reduce((s: number, d: any) => s + d.value, 0)
  const closedRevenue = deals.filter((d: any) => d.stage === 'closed_won').reduce((s: number, d: any) => s + d.value, 0)
  const openPipeline = deals.filter((d: any) => !d.stage.startsWith('closed')).reduce((s: number, d: any) => s + d.value, 0)
  const score = intel?.realityScore?.score || 0
  const personality = intel?.personality

  return (
    <div className="max-w-[1200px] mx-auto space-y-5">
      {toast && <div className="fixed top-4 right-4 z-50 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm px-4 py-2 rounded-lg">{toast}</div>}

      {/* Drilldown Modal */}
      {drilldown && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setDrilldown(null)}>
          <div className="bg-[#0D1117] border border-white/10 rounded-2xl w-full max-w-2xl max-h-[80vh] overflow-y-auto p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg">{drilldown.title}</h3>
              <button onClick={() => setDrilldown(null)} className="text-gray-500 hover:text-white text-xl">&times;</button>
            </div>
            <table className="w-full text-sm">
              <thead><tr className="text-[10px] text-gray-500 uppercase border-b border-white/5">
                <th className="text-left py-2">Item</th><th className="text-right py-2">Amount</th><th className="text-right py-2">Date</th><th className="text-right py-2">Status</th>
              </tr></thead>
              <tbody>
                {drilldown.items.map((item: any, i: number) => (
                  <tr key={i} className="border-b border-white/[0.03]">
                    <td className="py-2 text-gray-300">{item.title}</td>
                    <td className="py-2 text-right font-mono">${item.value?.toLocaleString()}</td>
                    <td className="py-2 text-right text-gray-500 text-xs">{item.date}</td>
                    <td className="py-2 text-right"><span className={'text-[10px] px-1.5 py-0.5 rounded ' + (STAGE_COLORS[item.stage] || '')}>{item.stage?.replace('_', ' ')}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="mt-3 pt-3 border-t border-white/5 text-right text-sm font-mono font-bold">
              Total: ${drilldown.items.reduce((s: number, i: any) => s + (i.value || 0), 0).toLocaleString()}
            </div>
          </div>
        </div>
      )}

      <Link href="/admin/sales-crm" className="text-sm text-gray-500 hover:text-white flex items-center gap-1">&larr; Back to CRM</Link>

      {/* ================================================================ */}
      {/* HEADER */}
      {/* ================================================================ */}
      <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-6">
        <div className="flex items-start gap-5">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500/20 to-violet-500/20 border border-white/10 flex items-center justify-center text-xl font-bold text-blue-300 flex-shrink-0">
            {contact.name.split(' ').map((n: string) => n[0]).join('')}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold">{contact.name}</h1>
            <p className="text-gray-400 mt-0.5">{contact.title} at {contact.company}</p>
            <div className="flex items-center gap-4 mt-2 flex-wrap">
              <span className="text-xs text-gray-500 font-mono">{contact.email}</span>
              <span className="text-xs text-gray-500">{contact.phone}</span>
              {contact.linkedinUrl && <a href={'https://' + contact.linkedinUrl} target="_blank" rel="noreferrer" className="text-xs text-blue-400 hover:text-blue-300">LinkedIn</a>}
              {contact.twitterUrl && <span className="text-xs text-gray-500">{contact.twitterUrl}</span>}
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            <div className={'text-4xl font-bold ' + (score >= 70 ? 'text-emerald-400' : score >= 40 ? 'text-amber-400' : 'text-rose-400')}>{score}</div>
            <div className="text-[10px] text-gray-500 font-mono">Reality Score</div>
          </div>
        </div>

        {/* TRACEABLE KPIs — each one is clickable */}
        <div className="grid grid-cols-4 gap-3 mt-5">
          <button onClick={() => setDrilldown({ title: 'All Deals', items: deals.map((d: any) => ({ title: d.title, value: d.value, date: d.expectedClose, stage: d.stage })) })}
            className="bg-white/[0.02] border border-white/5 rounded-lg p-3 text-center hover:border-blue-500/30 transition-all cursor-pointer group">
            <div className="text-lg font-bold group-hover:text-blue-400">${totalDealValue.toLocaleString()}</div>
            <div className="text-[10px] text-gray-500 font-mono">Total Deal Value <span className="text-blue-400/0 group-hover:text-blue-400/100 transition-all">click</span></div>
          </button>
          <button onClick={() => setDrilldown({ title: 'Closed Revenue', items: deals.filter((d: any) => d.stage === 'closed_won').map((d: any) => ({ title: d.title, value: d.value, date: d.closedAt?.split('T')[0] || d.expectedClose, stage: d.stage })) })}
            className="bg-white/[0.02] border border-white/5 rounded-lg p-3 text-center hover:border-emerald-500/30 transition-all cursor-pointer group">
            <div className="text-lg font-bold text-emerald-400">${closedRevenue.toLocaleString()}</div>
            <div className="text-[10px] text-gray-500 font-mono">Closed Revenue</div>
          </button>
          <button onClick={() => setDrilldown({ title: 'Open Pipeline', items: deals.filter((d: any) => !d.stage.startsWith('closed')).map((d: any) => ({ title: d.title, value: d.value, date: d.expectedClose, stage: d.stage })) })}
            className="bg-white/[0.02] border border-white/5 rounded-lg p-3 text-center hover:border-violet-500/30 transition-all cursor-pointer group">
            <div className="text-lg font-bold">${openPipeline.toLocaleString()}</div>
            <div className="text-[10px] text-gray-500 font-mono">Open Pipeline</div>
          </button>
          <div className="bg-white/[0.02] border border-white/5 rounded-lg p-3 text-center">
            <div className="text-lg font-bold">{activities.length}</div>
            <div className="text-[10px] text-gray-500 font-mono">Interactions</div>
          </div>
        </div>
      </div>

      {/* TABS */}
      <div className="flex gap-2">
        {(['intel', 'deals', 'activity', 'edit'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={'px-4 py-2 rounded-lg text-sm font-medium transition-all ' +
              (tab === t ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5')}>
            {t === 'intel' ? '\uD83E\uDDE0 Intelligence' : t === 'deals' ? '\uD83D\uDCB0 Deals' : t === 'activity' ? '\uD83D\uDCAC Activity' : '\u270F\uFE0F Edit'}
          </button>
        ))}
      </div>

      {/* ================================================================ */}
      {/* INTELLIGENCE TAB */}
      {/* ================================================================ */}
      {tab === 'intel' && (
        <div className="space-y-4">
          {intelLoading ? (
            <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-8 text-center">
              <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <div className="text-sm text-gray-400">Analyzing personality and generating insights...</div>
            </div>
          ) : personality ? (
            <>
              {/* Personality Card */}
              <div className={'bg-gradient-to-br border rounded-xl p-6 ' + (PERSONALITY_COLORS[personality.personalityType] || PERSONALITY_COLORS.Analytical)}>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-[10px] text-gray-400 uppercase tracking-wider font-mono mb-1">AI Personality Profile</div>
                    <h3 className="text-xl font-bold">{personality.personalityType}</h3>
                  </div>
                  <div className="flex gap-3">
                    <div className="text-center">
                      <div className="text-sm font-mono font-bold">{personality.decisionSpeed}</div>
                      <div className="text-[9px] text-gray-400">Decision Speed</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-mono font-bold">{personality.riskTolerance}</div>
                      <div className="text-[9px] text-gray-400">Risk Tolerance</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-mono font-bold">{personality.communicationPreference}</div>
                      <div className="text-[9px] text-gray-400">Prefers</div>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-gray-300">{personality.buyingStyle}</p>
                <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2">
                  <span className={'text-[10px] font-mono px-2 py-0.5 rounded ' +
                    (personality.relationshipStrength === 'strong' ? 'bg-emerald-500/20 text-emerald-300' :
                     personality.relationshipStrength === 'growing' ? 'bg-blue-500/20 text-blue-300' :
                     personality.relationshipStrength === 'new' ? 'bg-amber-500/20 text-amber-300' : 'bg-rose-500/20 text-rose-300')}>
                    {personality.relationshipStrength} relationship
                  </span>
                </div>
              </div>

              {/* Do / Don't Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-[#0A0E15] border border-emerald-500/20 rounded-xl p-5">
                  <h4 className="text-sm font-semibold text-emerald-400 mb-3">\u2705 DO — Selling Playbook</h4>
                  <div className="space-y-2">
                    {personality.doList?.map((item: string, i: number) => (
                      <div key={i} className="flex items-start gap-2 text-sm text-gray-300">
                        <span className="text-emerald-400 mt-0.5 flex-shrink-0">{i + 1}.</span>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-[#0A0E15] border border-rose-500/20 rounded-xl p-5">
                  <h4 className="text-sm font-semibold text-rose-400 mb-3">\u26D4 DON'T — Avoid These</h4>
                  <div className="space-y-2">
                    {personality.dontList?.map((item: string, i: number) => (
                      <div key={i} className="flex items-start gap-2 text-sm text-gray-300">
                        <span className="text-rose-400 mt-0.5 flex-shrink-0">{i + 1}.</span>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Negotiation + Next Action + Score Breakdown */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
                  <h4 className="text-sm font-semibold mb-3">\uD83C\uDFAF Next Best Action</h4>
                  <p className="text-sm text-blue-300 font-medium">{personality.nextBestAction}</p>
                  <div className="mt-4">
                    <h5 className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Key Motivators</h5>
                    {personality.keyMotivators?.map((m: string, i: number) => (
                      <div key={i} className="text-xs text-gray-400 py-1">\u2022 {m}</div>
                    ))}
                  </div>
                </div>

                <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
                  <h4 className="text-sm font-semibold mb-3">\uD83E\uDD1D Negotiation Tips</h4>
                  <p className="text-sm text-gray-400">{personality.negotiationTips}</p>
                  <div className="mt-4">
                    <h5 className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Predicted Objections</h5>
                    {personality.objectionPredictions?.map((o: any, i: number) => (
                      <div key={i} className="mb-2">
                        <div className="text-xs text-amber-400 font-medium">"{typeof o === 'string' ? o : o.objection}"</div>
                        <div className="text-[10px] text-gray-500 mt-0.5">{typeof o === 'string' ? '' : o.response}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
                  <h4 className="text-sm font-semibold mb-3">\uD83D\uDCCA Reality Score Breakdown</h4>
                  <div className="space-y-3">
                    {intel?.realityScore?.factors?.map((f: any, i: number) => (
                      <div key={i}>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-400">{f.label}</span>
                          <span className="font-mono text-gray-300">{Math.round(f.value)}/{f.max}</span>
                        </div>
                        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-violet-500 transition-all"
                            style={{ width: (f.value / f.max * 100) + '%' }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bio Notes */}
              <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
                <h4 className="text-sm font-semibold mb-3">\uD83D\uDCCB Personality &amp; Bio Notes</h4>
                <p className="text-sm text-gray-400 leading-relaxed whitespace-pre-wrap">{contact.bioNotes || 'No notes yet.'}</p>
                <div className="mt-3 pt-3 border-t border-white/5 flex gap-4 text-xs text-gray-500">
                  <span>Source: <span className="text-gray-300">{contact.source}</span></span>
                  <span>Since: <span className="text-gray-300">{contact.createdAt}</span></span>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5 text-center text-gray-500 text-sm">
              Intelligence unavailable. <button onClick={loadIntel} className="text-blue-400 hover:text-blue-300">Retry</button>
            </div>
          )}
        </div>
      )}

      {/* ================================================================ */}
      {/* DEALS TAB (with traceability) */}
      {/* ================================================================ */}
      {tab === 'deals' && (
        <div className="space-y-3">
          {deals.map((deal: any) => {
            const dealActivities = activities.filter((a: any) => a.dealId === deal.id)
            return (
              <div key={deal.id} className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-medium">{deal.title}</h3>
                    <div className="flex items-center gap-3 mt-1">
                      <span className={'text-[10px] font-mono px-2 py-0.5 rounded ' + (STAGE_COLORS[deal.stage] || '')}>{deal.stage.replace('_', ' ')}</span>
                      <span className="text-xs text-gray-500">{deal.assignedTo}</span>
                      <span className="text-xs text-gray-500">Close: {deal.expectedClose}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-mono font-bold">${deal.value.toLocaleString()}</div>
                    <div className="text-[10px] text-gray-500 font-mono">{deal.probability}%</div>
                  </div>
                </div>
                {deal.notes && <p className="text-xs text-gray-400 mb-3 italic">{deal.notes}</p>}
                <div className="border-t border-white/5 pt-3">
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Timeline ({dealActivities.length})</div>
                  {dealActivities.length > 0 ? dealActivities.map((act: any) => (
                    <div key={act.id} className="flex items-start gap-2 py-1.5">
                      <span className="text-xs">{ACT_ICONS[act.type] || '\uD83D\uDCCC'}</span>
                      <span className="text-xs text-gray-400 flex-1">{act.description}</span>
                      <span className="text-[10px] text-gray-600 font-mono">{new Date(act.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                    </div>
                  )) : <div className="text-xs text-gray-600">No activities</div>}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* ================================================================ */}
      {/* ACTIVITY TAB */}
      {/* ================================================================ */}
      {tab === 'activity' && (
        <div className="space-y-4">
          <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
            <h3 className="text-sm font-semibold mb-3">Log Activity</h3>
            <div className="flex gap-3">
              <select value={newAct.type} onChange={e => setNewAct({...newAct, type: e.target.value})}
                className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm w-32">
                <option value="note">Note</option><option value="call">Call</option>
                <option value="email">Email</option><option value="meeting">Meeting</option>
                <option value="document">Document</option>
              </select>
              <input value={newAct.description} onChange={e => setNewAct({...newAct, description: e.target.value})}
                placeholder="What happened?" className="flex-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm"
                onKeyDown={e => e.key === 'Enter' && addActivity()} />
              <button onClick={addActivity} disabled={!newAct.description}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 disabled:opacity-40">Log</button>
            </div>
          </div>
          <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-5">
            <h3 className="text-sm font-semibold mb-3">Complete Timeline</h3>
            <div className="space-y-3">
              {activities.map((act: any) => {
                const deal = deals.find((d: any) => d.id === act.dealId)
                return (
                  <div key={act.id} className="flex gap-3 py-2 border-b border-white/[0.03] last:border-0">
                    <div className="text-lg">{ACT_ICONS[act.type] || '\uD83D\uDCCC'}</div>
                    <div className="flex-1">
                      <div className="text-sm text-gray-300">{act.description}</div>
                      <div className="flex items-center gap-3 mt-1 flex-wrap">
                        <span className="text-[10px] text-gray-500">{act.createdBy}</span>
                        {deal && <span className="text-[10px] text-blue-400 font-mono">{deal.title}</span>}
                        <span className="text-[10px] text-gray-600 font-mono">{new Date(act.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                        {act.metadata?.duration && <span className="text-[10px] text-gray-600">{act.metadata.duration}</span>}
                        {act.metadata?.location && <span className="text-[10px] text-gray-600">{act.metadata.location}</span>}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* ================================================================ */}
      {/* EDIT TAB */}
      {/* ================================================================ */}
      {tab === 'edit' && (
        <div className="bg-[#0A0E15] border border-white/5 rounded-xl p-6 max-w-2xl">
          <h3 className="font-semibold mb-4">Edit Contact</h3>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><label className="text-[10px] text-gray-500 uppercase tracking-wider">Name</label>
                <input id="edit-name" defaultValue={contact.name} className="w-full mt-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" /></div>
              <div><label className="text-[10px] text-gray-500 uppercase tracking-wider">Title</label>
                <input id="edit-title" defaultValue={contact.title} className="w-full mt-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="text-[10px] text-gray-500 uppercase tracking-wider">Email</label>
                <input id="edit-email" defaultValue={contact.email} className="w-full mt-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" /></div>
              <div><label className="text-[10px] text-gray-500 uppercase tracking-wider">Phone</label>
                <input id="edit-phone" defaultValue={contact.phone} className="w-full mt-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm" /></div>
            </div>
            <div><label className="text-[10px] text-gray-500 uppercase tracking-wider">Bio / Personality Notes</label>
              <textarea id="edit-bioNotes" defaultValue={contact.bioNotes} rows={5}
                className="w-full mt-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm resize-none" /></div>
            <button onClick={saveContact} className="w-full py-2.5 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600">Save Changes</button>
          </div>
        </div>
      )}
    </div>
  )
}
