const fs = require('fs');
const path = require('path');

console.log('');
console.log('  ╔══════════════════════════════════════════════════════════╗');
console.log('  ║  WoulfAI Phase 3: Intelligence + Voice + Documents      ║');
console.log('  ║  AI Profiling, OCR Scanner, Reimbursements, Debrief     ║');
console.log('  ╚══════════════════════════════════════════════════════════╝');
console.log('');

const BASE = path.join(__dirname, 'phase3-files');
let installed = 0;

function install(src, dest) {
  try {
    const srcPath = path.join(BASE, src);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(srcPath, dest);
    const lines = fs.readFileSync(dest, 'utf8').split('\n').length;
    console.log('  + ' + dest + ' (' + lines + ' lines)');
    installed++;
  } catch(e) {
    console.log('  ! ' + src + ': ' + e.message);
  }
}

console.log('API Routes:');
install('app/api/intelligence/route.ts', 'app/api/intelligence/route.ts');
install('app/api/documents/route.ts', 'app/api/documents/route.ts');
install('app/api/reimbursements/route.ts', 'app/api/reimbursements/route.ts');
console.log('');

console.log('UI Pages:');
install('app/admin/sales-crm/[contactId]/page.tsx', 'app/admin/sales-crm/[contactId]/page.tsx');
install('app/agents/cfo/tools/page.tsx', 'app/agents/cfo/tools/page.tsx');
install('app/sales/debrief/page.tsx', 'app/sales/debrief/page.tsx');
console.log('');

// Patch sidebar
console.log('Sidebar:');
try {
  let layout = fs.readFileSync('app/admin/layout.tsx', 'utf8');
  let changed = false;
  if (!layout.includes('cfo/tools')) {
    if (layout.includes('CFO Console')) {
      layout = layout.replace(
        /(\{[^}]*label:\s*['"]CFO Console['"][^}]*\}),?/,
        "$1,\n    { id: 'cfo-tools', label: 'Doc Scanner', href: '/agents/cfo/tools', icon: '\uD83D\uDCC4' },\n    { id: 'debrief', label: 'Field Debrief', href: '/sales/debrief', icon: '\uD83C\uDF99\uFE0F' },"
      );
      changed = true;
    }
  }
  if (changed) {
    fs.writeFileSync('app/admin/layout.tsx', layout);
    console.log('  ~ app/admin/layout.tsx (Doc Scanner + Field Debrief added)');
  } else {
    console.log('  o Sidebar already up to date');
  }
} catch(e) {
  console.log('  ! Sidebar: ' + e.message);
}

console.log('');
console.log('  ────────────────────────────────────────');
console.log('  Installed: ' + installed + ' files');
console.log('  ────────────────────────────────────────');
console.log('');
console.log('  New routes:');
console.log('    /admin/sales-crm/[id]       Enhanced 360: AI personality, Do/Don\'t, traceability');
console.log('    /agents/cfo/tools           Document Scanner + Reimbursement Manager');
console.log('    /sales/debrief              Voice-First Field Debrief (mobile-friendly)');
console.log('    /api/intelligence            AI personality profiling + Reality Score');
console.log('    /api/documents               PDF scan, OCR, Trump Rule, auto-invoice');
console.log('    /api/reimbursements           Receipt OCR, monthly batches, approval');
console.log('');
console.log('  SQL: Run 003_phase3_intelligence.sql in Supabase');
console.log('  Then: npm run dev');
console.log('');
